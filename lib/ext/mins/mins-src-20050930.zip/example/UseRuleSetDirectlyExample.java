/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  University of Innsbruck, Austria
 *   
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package example;

import org.deri.mins.*;
import org.deri.mins.api.DBInterface;
import org.deri.mins.api.EEDBInterface;
import org.deri.mins.builtins.*;
import org.deri.mins.terms.*;

/**
 * Interface or class description
 * 
 * <pre>
 *  Created on Jun 28, 2005
 *  Committed by $Author$
 *  $Source$,
 * </pre>
 * 
 * @author Holger Lausen (holger.lausen@deri.org)
 * @version $Revision$ $Date$
 */
public class UseRuleSetDirectlyExample {

    public UseRuleSetDirectlyExample() {
        super();
    }

    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        UseRuleSetDirectlyExample i = new UseRuleSetDirectlyExample();
        i.test();
    }

    public void test() throws Exception {
        Builtin[] buildInList = new Builtin[] {
        new Builtin("Add", 3, new Add()),
        new Builtin("evaluable_", 2, new Evaluable()),
        new Builtin("unify", 2, new Equal()),
        new Builtin("isNum", 1, new IsNum()),
        new Builtin("isString", 1, new IsString()),
        new Builtin("isConst", 1, new IsConst()),
        new Builtin("less", 2, new Less()),
        new Builtin("lessorequal", 2, new Lessorequal()),
        new Builtin("greater", 2, new Greater()),
        new Builtin("greaterorequal", 2, new Greaterorequal()),
        new Builtin("between", 3, new org.deri.mins.builtins.Between()),
        new Builtin("starts", 2, new org.deri.mins.builtins.Starts()),
        new Builtin("ends", 2, new org.deri.mins.builtins.Ends()),
        new Builtin("lives", 2, new org.deri.mins.builtins.Lives()) };

        BuiltinConfig builtInConfig = new BuiltinConfig(buildInList);
        DBInterface db = new DB(); // facts stored in RAM
        EEDBInterface rs = new RuleSet(builtInConfig, db);

        // add fact p1(c1,c2)
        Term c1 = new ConstTerm(1);
        Term c2 = new ConstTerm(2);
        GroundAtom atom = new GroundAtom(new Term[] { c1, c2});
        System.out.println("Adding Fact: p1-"+atom);
        rs.addFact(1, atom);
        rs.addFact(4, atom);

        // add rule p2(X0,X1) :- p1(X0,X1) 
        Body body1 = new Body(1, false, 
                new Term[] { new Variable(0), new Variable(1) });
        Head head = new Head(2, 
                new Term[] { new Variable(0), new Variable(1) });
        Rule rule = new Rule(new Head[] {head}, new Body[] {body1});
        System.out.println("Adding Rule: "+rule);
        rs.addRule(rule);

        // add query <- p2(X0,X1)
        Body body = new Body(2, false,
                new Term[] { new Variable(0), new Variable(1) });
        Rule query = new Rule(null, new Body[] { body });
        System.out.println("Adding Query: "+rule);
        rs.addRule(query);

        System.out.println("Evaluation...");
        /* 0: Naive Evaluation (only stratifight prorgams)<BR> 
         * 1: Dynamic Filtering Evaluation (only stratifight prorgams)<BR> 
         * 2: Wellfounded Evaluation with alternating fixed point (juergen says works)<BR> 
         * 3: Wellfounded Evaluation (juergen says probably buggy!) */
        int evalMethod = 0;
        rs.setEvaluationMethod(evalMethod);

        rs.evalQueries();

        Substitution substitutions = rs.getSubstitution(query);
        java.util.Enumeration enm1 = substitutions.elements();
        while (enm1.hasMoreElements()) {
            GroundAtom a = (GroundAtom) enm1.nextElement();
            for (int i = 0; i < a.terms.length; i++) {
                System.out.print("X" + i + " = " + a.terms[i]);
                if (i < a.terms.length - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println();
        }
    }
}