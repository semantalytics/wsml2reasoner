/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: Recompiler.java

 Version: 1.0

 Purpose:

 History:

 */

import java.io.IOException;
import java.io.RandomAccessFile;

public class Recompiler {
    public static int STRINGSTART = 100000;

    public String strings[];

    public String predicates[];

    public String functions[];

    public void readSymTab(RandomAccessFile f) throws IOException {
        int anzfsyms, anzstrings, anzpsyms;
        String s;
        int i;
        int index, index1;
        int symbol;
        String str;
        int arity;
        int len;

        s = f.readLine();
        anzfsyms = wandle(s);
        functions = new String[anzfsyms];
        s = f.readLine();
        anzstrings = wandle(s);
        strings = new String[anzstrings];
        s = f.readLine();
        anzpsyms = wandle(s);
        predicates = new String[anzpsyms];

        for (i = 0; i < anzfsyms; i++) {
            s = f.readLine();

            index = s.indexOf(' ');
            symbol = wandle(s.substring(0, index));
            index1 = s.indexOf(' ', index + 1);
            // System.out.println(s); System.out.print(" ");
            // System.out.print(index); System.out.print(" ");
            // System.out.println(index1);
            arity = wandle(s.substring(index + 1, index1));
            str = s.substring(index1 + 1);
            functions[symbol] = str;
            // FSymbols.searchAndInsert(str,arity);
        }

        for (i = 0; i < anzstrings; i++) {
            s = f.readLine();
            index = s.indexOf(' ');
            symbol = wandle(s.substring(0, index));
            if (i != symbol)
                System.out.println("error in reading symbol table");
            index1 = s.indexOf(' ', index + 1);
            // System.out.print(s); System.out.print(" ");
            // System.out.print(index); System.out.print(" ");
            // System.out.println(index1);
            len = wandle(s.substring(index + 1, index1));
            str = s.substring(index1 + 1);
            while (str.length() < len - 1) {
                str = str + "\n" + f.readLine();
            }
            s = str.replace((char) 13, ' ');
            strings[symbol] = s;
        }

        for (i = 0; i < anzpsyms; i++) {
            s = f.readLine();
            index = s.indexOf(' ');
            symbol = wandle(s.substring(0, index));
            index1 = s.indexOf(' ', index + 1);
            // System.out.print(s); System.out.print(" ");
            // System.out.print(index); System.out.print(" ");
            // System.out.println(index1);
            arity = wandle(s.substring(index + 1, index1));
            str = s.substring(index1 + 1);
            // PSymbols.searchAndInsert(str,arity);
            predicates[symbol] = str;

        }

    }

    int wandle(String s) {
        Integer zahl = new Integer(0);
        try {
            zahl = new Integer(s);
        } catch (NumberFormatException p) {
            System.out.println("number expected");
        }
        return zahl.intValue();
    }
}
