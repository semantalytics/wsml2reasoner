/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.operations;

import org.deri.mins.*;
import org.deri.mins.terms.Variable;

/*

 Name: Atoms.java

 Version: 2.0

 Purpose: a container for atoms with appropriate access data structures
 (AVL trees)

 History:

 */

public class Filtering extends Operation {
    public Filtering(Atoms R1, int ix1[], Atoms R2, int ix2[], Atoms D, Atom T,
            long Time) {
        super(R1, ix1, R2, ix2, Time);
        this.D = D;
        D.tuples2 = null;
        this.T = T;
        // System.out.println(T.toString());
        comp1 = new CompareAtoms(ix1, ix2);
        comp2 = new CompareAtoms(ix2, ix1);
    }

    public void op(GroundAtom t1, GroundAtom t2) {
        int i;
        GroundAtom f;
        GroundAtom ins;
        Variable v;
        boolean res = true;
        Atom t = (Atom) t1;
        res = t.Match(t2);
        t.ClearVariables();
        if (res) {
            res = T.Match(t2);
            if (res) {
                f = new GroundAtom(D.stellen);
                for (v = T.variables, i = 0; v != null; v = v.next, i++)
                    f.terms[i] = v.subsby;
                ins = D.Insert(f);
                t2.Supports(ins);
                ins.cycle = T.cycle;
                if (ins == f) {
                    f.next2 = D.tuples2;
                    D.tuples2 = f;
                }
            }
        }
        T.ClearVariables();
        if (t.lasttouched < timestamp) {
            t.next2 = R1.tuples2;
            R1.tuples2 = t;
            t.lasttouched = timestamp;
        }
        if (t2.lasttouched < timestamp) {
            t2.next2 = R2.tuples2;
            R2.tuples2 = t2;
            t2.lasttouched = timestamp;
        }
    }
}
