/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.operations;

import org.deri.mins.*;
import org.deri.mins.terms.Variable;

/*

 Name: Atoms.java

 Version: 2.0

 Purpose: a container for atoms with appropriate access data structures
 (AVL trees)

 History:

 */

class Unification extends Operation {

    public Unification(Atoms R1, int ix1[], Atoms R2, int ix2[], Atoms D, long T) {
        super(R1, ix1, R2, ix2, T);
        this.D = D;
        D.tuples2 = null;
        comp1 = new CompareAtoms(ix1, ix2);
        comp2 = new CompareAtoms(ix2, ix1);
    }

    public void op(GroundAtom t1, GroundAtom t2) {
        int i;
        Atom f, ins;
        Variable v;
        boolean res = true;
        boolean del;
        Atom t1n = (Atom) t1;
        Atom t2n = (Atom) t2;
        res = (t1n).Unify(t2n);
        if (res) {
            f = new Atom(D.stellen);
            for (v = t1n.variables, i = 0; v != null; v = v.next, i++)
                if (v.subsby != null)
                    f.terms[i] = v.subsby;
                else
                    f.terms[i] = v;
            ins = (Atom) D.Insert(f);
            del = ins.deleted;
            t2n.Supports(ins);
            if (ins == f) {
                f.next2 = D.tuples2;
                D.tuples2 = f;
            }
        }
        t1n.ClearVariables();
        t2n.ClearVariables();
        if (t1n.lasttouched < timestamp) {
            t1n.next2 = R1.tuples2;
            R1.tuples2 = t1n;
            t1n.lasttouched = timestamp;
        }
        if (t2n.lasttouched < timestamp) {
            t2n.next2 = R2.tuples2;
            R2.tuples2 = t2n;
            t2n.lasttouched = timestamp;
        }
    }
}
