/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.operations;

import org.deri.mins.GroundAtom;
import org.deri.mins.terms.Term;
import org.deri.mins.terms.Variable;


/*

 Name: Atoms.java

 Version: 2.0

 Purpose: a container for atoms with appropriate access data structures
 (AVL trees)

 History:

 */

/*
 * class CompareAtoms extends Comparison { int index1[] = null; int index2[] =
 * null; public CompareAtoms(int ix1[], int ix2[]) { index1 = ix1; index2 = ix2; }
 * protected int cmp(Term t1, Term t2) { int i,res = 0; if (t1.ground &&
 * t2.ground) { res = t1.Compare(t2); System.out.println(res); } else if ((t1
 * instanceof Variable) || (t2 instanceof Variable)) res = 2; else { if
 * ((t1.type() != t2.type()) || (t1.anzpars() != t2.anzpars())) { res =
 * t1.CompareTypes(t2); } else { res = t1.CompareFlat(t2); if (res == 0) { for
 * (i = 0; (i < t1.anzpars()) && ((res == 0)||(res==2)); i++) res =
 * cmp(t1.pars[i],t2.pars[i]); } } } return res; } public int Compare(Object t1,
 * Object t2) { int i = 0, res = 0; for(i = 0; (index1[i] != -1) && ((res ==
 * 0)||(res==2)); i++) { res =
 * cmp(((GroundAtom)t1).terms[index1[i]],((GroundAtom)t2).terms[index2[i]]); }
 * return res; } }
 */

public class CompareAtoms extends Comparison {
    int index1[] = null;

    int index2[] = null;

    public CompareAtoms(int ix1[], int ix2[]) {
        index1 = ix1;
        index2 = ix2;
    }

    protected int cmp(Term t1, Term t2) {
        int i, res = 0;
        if (t1.ground && t2.ground) {
            res = t1.Compare(t2);
        }
        else if ((t1 instanceof Variable) || (t2 instanceof Variable))
            res = 2;
        else {
            if ((t1.type() != t2.type()) || (t1.anzpars() != t2.anzpars())) {
                res = t1.CompareTypes(t2);
            }
            else {
                // res = t1.CompareEqual(t2);
                res = t1.compareFlat(t2);
                if (res == 0) {
                    for (i = 0; (i < t1.anzpars()) && (res == 0); i++)
                        res = cmp(t1.pars[i], t2.pars[i]);
                    if (res == 2) {
                        for (; (i < t1.anzpars()) && ((res == 2) || (res == 0)); i++)
                            res = cmp(t1.pars[i], t2.pars[i]);
                        if ((res == 2) || (res == 0))
                            return 2;
                        else
                            return -2;
                    }
                    else
                        return res;
                }
            }
        }

        return res;
    }

    public int Compare(Object t1, Object t2) {
        int i = 0, res = 0;
        for (i = 0; (index1[i] != -1) && (res == 0); i++) {
            res = cmp(((GroundAtom) t1).terms[index1[i]],
                    ((GroundAtom) t2).terms[index2[i]]);
        }

        if (res == 2) {
            for (; (index1[i] != -1) && ((res == 2) || (res == 0)); i++)
                res = cmp(((GroundAtom) t1).terms[index1[i]],
                        ((GroundAtom) t2).terms[index2[i]]);
            if ((res == 2) || (res == 0))
                res = 2;
            else
                res = -2;
        }
        /*
         * printatom((GroundAtom)t1,index1); System.out.print(" ");
         * printatom((GroundAtom)t2,index2); System.out.print(" ");
         * System.out.println(res);
         */
        return res;
    }

    public void printatom(GroundAtom t, int ix[]) {
        int i;
        for (i = 0; (i < ix.length) && (ix[i] != -1); i++) {
            System.out.print(t.terms[ix[i]].toString());
            if ((i < ix.length - 1) && (ix[i + 1] != -1))
                System.out.print(",");
        }
    }
}
