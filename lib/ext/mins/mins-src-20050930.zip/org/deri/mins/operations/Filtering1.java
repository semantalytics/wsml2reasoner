/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.operations;

import org.deri.mins.*;

/*

 Name: Atoms.java

 Version: 2.0

 Purpose: a container for atoms with appropriate access data structures
 (AVL trees)

 History:

 */

public class Filtering1 extends Operation {
    public Filtering1(Atoms R1, int ix1[], Atoms R2, int ix2[], Atoms D,
            long Time) {
        super(R1, ix1, R2, ix2, Time);
        this.D = D;
        D.tuples2 = null;
        comp1 = new CompareAtoms(ix1, ix2);
        comp2 = new CompareAtoms(ix2, ix1);
    }

    public void op(GroundAtom t1, GroundAtom t2) {
        GroundAtom ins;
        boolean res = true;
        GroundAtom f;
        int i;

        Atom t = (Atom) t1;

        res = t.Match(t2);
        t.ClearVariables();
        if (res) {
            f = new GroundAtom(D.stellen);
            for (i = 0; i < D.stellen; i++)
                f.terms[i] = t2.terms[i];
            ins = D.Insert(f);
        }
        if (t.lasttouched < timestamp) {
            t.next2 = R1.tuples2;
            R1.tuples2 = t;
            t.lasttouched = timestamp;
        }
        if (t2.lasttouched < timestamp) {
            t2.next2 = R2.tuples2;
            R2.tuples2 = t2;
            t2.lasttouched = timestamp;
        }
    }
}
