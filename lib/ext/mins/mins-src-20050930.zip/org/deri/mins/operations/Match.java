/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.operations;

import org.deri.mins.*;
import org.deri.mins.terms.Variable;

/*

 Name: Atoms.java

 Version: 2.0

 Purpose: a container for atoms with appropriate access data structures
 (AVL trees)

 History:

 */

public class Match extends SearchOperation {
    public Match(Atoms R, Atom T, Atoms D, long Time) {
        super(R, T, D, Time);
    }

    public void op(GroundAtom t, GroundAtom t2) {
        int i;
        GroundAtom f;
        GroundAtom ins;
        Variable v;
        boolean res = true;
        Atom T = (Atom) t2;
        res = (T).Match(t);
        if (res) {
            // flag = true;
            f = new GroundAtom(D.stellen);
            for (v = (T).variables, i = 0; v != null; v = v.next, i++)
                if (v.subsby != null)
                    f.terms[i] = v.subsby;
                else
                    f.terms[i] = new Variable(v.symbol);
            ins = D.Insert(f);
            (t).Supports(ins);
            if (ins == f) {
                f.next2 = D.tuples2;
                D.tuples2 = f;
            }
        }
        (T).ClearVariables();
        // (t).ClearVariables();
        if (t.lasttouched < timestamp) {
            t.next2 = R1.tuples2;
            R1.tuples2 = t;
            t.lasttouched = timestamp;
        }
    }
}
