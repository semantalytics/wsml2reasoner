/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.operations;

import org.deri.mins.*;

public abstract class Operation {
    int debuglevel = 0;

    public long timestamp;

    Comparison comp1, comp2;

    Atoms R1, R2, D = null;

    IndexEnumeration enm1, enm2, enm3;

    int dindex1[], dindex2[], index1[], index2[];

    Atom T;

    static int no = 0;

    public Operation(Atoms R1, int index1[], Atoms R2, int index2[], long T) {
        this.R1 = R1;
        this.R2 = R2;
        this.timestamp = T;
        this.index1 = index1;
        this.index2 = index2;
        R1.tuples2 = null;
        R2.tuples2 = null;
        no++;
        if (debuglevel > 0) {
            System.out.println("Operation: ");
            System.out.println(no);
        }
    }

    public abstract void op(GroundAtom b1, GroundAtom b2);

    public void Operate() {
        IndexNode ix1, ix2;
        GroundAtom b1, b2, start1 = null, start2 = null;
        int praedikat;

        if (debuglevel > 1) {
            System.out.println("Indices:");
            printindex(index1);
            System.out.print("    ");
            printindex(index2);
            System.out.println();
            System.out.println("Source1:");
            R1.print(System.out);
            System.out.println();
            System.out.println("Source2:");
            R2.print(System.out);
            System.out.println();
        }

        if ((R1.anztuples > 0) && (R2.anztuples > 0)) {
            ix1 = R1.getindex(index1);
            ix2 = R2.getindex(index2);

            /*
             * if(no==532) { ((AVLTree)ix1.avl).print();
             * ((AVLTree)ix2.avl).print(); }
             */

            enm1 = (IndexEnumeration) ix1.avl.elements();
            enm1.setComparisonMethod(comp1);
            enm2 = (IndexEnumeration) ix2.avl.elements();
            enm2.setComparisonMethod(comp2);

            if (ix1.avl.NoElements() > ix2.avl.NoElements()) {
                start2 = (GroundAtom) enm2.nextElement();
                enm1.positionToElement(start2);
                start1 = (GroundAtom) enm1.nextElement();
            }
            else {
                start1 = (GroundAtom) enm1.nextElement();
                enm2.positionToElement(start1);
                start2 = (GroundAtom) enm2.nextElement();
            }

            /*
             * start1 = (GroundAtom)enm1.nextElement(); start2 =
             * (GroundAtom)enm2.nextElement();
             */
            while ((start1 != null) && (start2 != null)) {

                praedikat = comp1.Compare(start1, start2);
                // printatom(start1,index1); System.out.print(" ");
                // printatom(start2,index2); System.out.print(" ");
                // System.out.println(praedikat);

                switch (praedikat) {
                case 0:
                case -2:
                case 2:
                    if ((praedikat == 0) || (praedikat == 2))
                        op(start1, start2);

                    // System.out.println("---------------------");

                    enm3 = (IndexEnumeration) enm2.clone();
                    while (enm2.hasMoreElements()
                            && ((praedikat == 2) || (praedikat == -2) || (praedikat == 0))) {

                        b2 = (GroundAtom) enm2.nextElement();
                        praedikat = comp1.Compare(start1, b2);
                        // printatom(start1,index1); System.out.print(" ");
                        // printatom(b2,index2); System.out.print(" ");
                        // System.out.println(praedikat);

                        if ((praedikat == 2) || (praedikat == 0))
                            op(start1, b2);
                    }
                    // System.out.println("---------------------");
                    start1 = (GroundAtom) enm1.nextElement();
                    enm2 = (IndexEnumeration) enm3.clone();
                    break;
                case -1:
                    start1 = (GroundAtom) enm1.nextGreaterElement(start2);
                    break;
                case 1:
                    start2 = (GroundAtom) enm2.nextGreaterElement(start1);
                    break;
                }
            }
        }
        if (debuglevel > 1) {
            System.out.println("Destination:");
            if (D != null) {
                D.print(System.out);
                System.out.println();
            }
        }
    }

    public void printatom(GroundAtom t, int ix[]) {
        int i;
        for (i = 0; (i < ix.length) && (ix[i] != -1); i++) {
            System.out.print(t.terms[ix[i]].toString());
            if ((i < ix.length - 1) && (ix[i + 1] != -1))
                System.out.print(",");
        }
    }

    public void printindex(int ix[]) {
        int i;
        for (i = 0; (i < ix.length) && (ix[i] != -1); i++) {
            System.out.print(ix[i]);
            if ((i < ix.length - 1) && (ix[i + 1] != -1))
                System.out.print(",");
        }
    }
}
