/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.operations;

import org.deri.mins.*;

/*

 Name: Atoms.java

 Version: 2.0

 Purpose: a container for atoms with appropriate access data structures
 (AVL trees)

 History:

 */

public class MatchJoin extends Operation {

    public MatchJoin(Atoms R1, int ix1[], Atoms R2, int ix2[], Atoms D,
            int dx[], long T) {
        super(R1, ix1, R2, ix2, T);
        this.dindex2 = dx;
        this.D = D;
        D.tuples2 = null;
        comp1 = new CompareAtoms(ix1, ix2);
        comp2 = new CompareAtoms(ix2, ix1);
    }

    public void op(GroundAtom t1, GroundAtom t2) {
        int i;
        Atom f;
        GroundAtom ins;
        // Variable v;
        boolean res = true;
        Atom t = (Atom) t1;
        if (t.variables == null)
            t.Variables();
        for (i = 0; (index1[i] != -1) && res; i++)
            res = t.terms[index1[i]].Match((t2).terms[index2[i]]) && res;
        if (res) {
            f = new Atom(D.stellen);
            for (i = 0; i < D.stellen; i++)
                f.terms[i] = null;
            for (i = 0; index1[i] != -1; i++)
                f.terms[index1[i]] = t2.terms[index2[i]];
            for (i = 0; i < t.terms.length; i++)
                if (f.terms[i] == null)
                    f.terms[i] = t.terms[i];
            for (i = 0; i < dindex2.length; i++) {
                if (dindex2[i] != -1) {
                    f.terms[dindex2[i]] = t2.terms[i];
                    f.MarkVar(dindex2[i]);
                }
            }
            // f.mark = (t1).mark | (t2).mark;
            f.mark = t.mark;
            f.and = true;
            ins = D.Insert(f);
            if (ins != f)
                ((Atom) ins).mark |= f.mark;
            t2.Supports(ins);
            t1.Supports(ins);
            if (ins == f) {
                f.next2 = D.tuples2;
                D.tuples2 = f;
            }
        }
        t.ClearVariables();
        if (t.lasttouched < timestamp) {
            t.next2 = R1.tuples2;
            R1.tuples2 = t;
            t.lasttouched = timestamp;
        }
        if (t2.lasttouched < timestamp) {
            t2.next2 = R2.tuples2;
            R2.tuples2 = t2;
            t2.lasttouched = timestamp;
        }
    }
}
