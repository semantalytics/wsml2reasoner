/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.operations;

import org.deri.mins.Atoms;
import org.deri.mins.GroundAtom;

/*

 Name: Atoms.java

 Version: 2.0

 Purpose: a container for atoms with appropriate access data structures
 (AVL trees)

 History:

 */

public class Join extends Operation {
    public Join(Atoms R1, int ix1[], Atoms R2, int ix2[], Atoms D, int dx1[],
            int dx2[], long T) {
        super(R1, ix1, R2, ix2, T);
        dindex1 = dx1;
        dindex2 = dx2;
        this.D = D;
        comp1 = new CompareGroundAtoms(ix1, ix2);
        comp2 = new CompareGroundAtoms(ix2, ix1);
    }

    public void op(GroundAtom t1, GroundAtom t2) {
        int i;
        GroundAtom t;
        GroundAtom ins;
        t = new GroundAtom(D.stellen);
        for (i = 0; i < R1.stellen; i++)
            if (dindex1[i] != -1)
                t.terms[dindex1[i]] = t1.terms[i]; // t.Copy(dindex1[i],t1,i);
        for (i = 0; i < R2.stellen; i++)
            if (dindex2[i] != -1)
                t.terms[dindex2[i]] = t2.terms[i]; // t.Copy(dindex2[i],t2,i);
        ins = D.Insert(t);
        if (ins != t)
            t = null;
        (t1).Supports(ins);
        (t2).Supports(ins);
        if (t1.lasttouched != timestamp) {
            t1.next2 = R1.tuples2;
            R1.tuples2 = t1;
            t1.lasttouched = timestamp;
        }
        if (t2.lasttouched != timestamp) {
            t2.next2 = R2.tuples2;
            R2.tuples2 = t2;
            t2.lasttouched = timestamp;
        }
    }
}
