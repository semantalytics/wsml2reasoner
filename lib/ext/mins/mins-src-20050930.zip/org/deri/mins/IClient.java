/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: IClient.java

 Version: 1.0

 Purpose:

 History:

 */

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

// import com.ontoprise.parser.SParseError;
// import com.ontoprise.parser.SParser;

public class IClient extends Thread {
    public static int no = 0;

    public static int num = 0;

    int n = 0;

    Socket socket = null;

    DataInputStream is = null;

    PrintStream os = null;

    int port = 1236;

    Head head;

    Rule rule;

    // SParser spars;

    Atoms filter;

    RuleSet rs;

    Atoms B;

    String host;

    public IClient(Rule r, Head h, RuleSet rs) {
        no++;
        n = num++;
        r.evaluating = true;
        r.stoppedevaluating = false;
        rule = r;
        this.port = r.port;
        this.host = r.host;
        // spars = new SParser(null);
        // System.out.print("running IClient no "); System.out.println(n);
        head = h;
        this.rs = rs;
        filter = r.heads[0].adddown;
        r.heads[0].adddown = new Atoms(filter.stellen);
        // filter = h.adddown;
        // h.adddown = new Atoms(filter.stellen);
        // filter = new Atoms(h.adddown.stellen);
        // filter.Union(h.adddown);
        // h.adddown.Clear();
        B = new Atoms(h.up.stellen);
        this.setPriority(Thread.NORM_PRIORITY);
        // System.out.println("DBAccess");
        /*
         * System.out.println("Filterterme:"); filter.print(System.out);
         * System.out.println("-------------------------------------");
         */
        this.start();
        // this.run();
    }

    public void run() {
        // System.out.print("running IClient no "); System.out.println(n);

        // Initialize the sockets and streams
        while (true) {
            try {
                InetAddress ina = InetAddress.getByName(host);
                socket = new Socket(ina, port);
                break;

            } catch (IOException e) {
                // System.err.println("Exception: couldn't connect to database"
                // + e.getMessage());
            }
        }
        try {
            is = new DataInputStream(socket.getInputStream());
            os = new PrintStream(socket.getOutputStream(), true);
        } catch (IOException e) {
            System.err.println("Exception: couldn't create stream to database"
                    + e.getMessage());
        }

        // Process user input and server responses
        try {
            String inLine;
            Fact f;
            GroundAtom a, b;
            // os.println(n);
            filter.internalize(os, rule.heads[0].symbol);
            os.println("stop");
            os.flush();
            // System.out.println("Ergebnisse: ");
            while ((inLine = is.readLine()) != null) {
                // System.out.print("inline: "); System.out.println(inLine);
                if (inLine.length() > 0) {
                    throw new UnsupportedOperationException(
                            "due to refactogin and loosing parser...");
                    // if (inLine.equals("stop"))
                    // break;
                    // spars.ParseString(inLine);
                    // try {
                    // f = spars.fact();
                    // b = new Atom(f.terms);
                    // a = B.Insert(b);
                    // // f.print(System.out); System.out.println();
                    // // System.out.println(r.hrelation.stellen);
                    // } catch (SParseError e) {
                    // f = null;
                    // }
                }
            }
            // Cleanup
            os.close();
            is.close();
            socket.close();
        } catch (IOException e) {
            System.err.println("I/O error: " + e.toString());
        }
        rule.heads[0].up.UnionAndSelected(B, rule.heads[0].addup);
        rule.stoppedevaluating = true;
        rule.evaluating = false;
        if (head.addup.anztuples > 0)
            rs.insertqueue(rule);
        no--;

        // System.out.println("Ergebnisse: ");
        // rule.heads[0].addup.print(System.out);

        // System.out.print("terminating IClient no "); System.out.println(n);
        // System.out.println("=================================================");

    }
}
