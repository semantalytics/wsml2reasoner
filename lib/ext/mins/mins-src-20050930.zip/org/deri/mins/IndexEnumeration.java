/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: IndexEnumeration.java

 Version: 1.1

 Purpose: Interface for enumerating elements of an index (see IndexInterface)

 History:

 */

import java.util.NoSuchElementException;

import org.deri.mins.operations.Comparison;


public interface IndexEnumeration {

    /**
     * Delivers a clone of the Enumeration and by this way stores the internal
     * state
     */
    public Object clone();

    /** Are there more elements available? */
    public boolean hasMoreElements();

    /**
     * Give the next element. Throws NoSuchElementException if no further
     * element is available. Equal elements appear in one sequence
     */
    public Object nextElement() throws NoSuchElementException;

    /**
     * Give the first next element greater or equal than o. Returns null if no
     * greater element is available
     */
    public Object nextGreaterElement(Object o) throws NoSuchElementException;

    /**
     * Position enumeration to the first element equal to o or if it does not
     * exist to the next existing element
     */
    public void positionToElement(Object o);

    public void print();

    /** Indrocues a new comparison method for the next method nextGreaterElement */
    public void setComparisonMethod(Comparison c);
}
