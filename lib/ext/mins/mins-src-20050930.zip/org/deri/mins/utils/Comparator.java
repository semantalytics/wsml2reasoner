/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.utils;

/*

 Name: Comparator.java

 Version: 1.0

 Purpose:

 History:

 */

/*
 File: Comparator.java


 Taken by Stefan.Decker@aifb.uni-karlsruhe.de

 Originally written by Doug Lea and released into the public domain. 
 Thanks for the assistance and support of Sun Microsystems Labs, Agorics 
 Inc, Loral, and everyone contributing, testing, and using this code.

 History:
 Date     Who                What
 24Sep95  dl@cs.oswego.edu   Create from collections.java  working file

 */

//package collections;
/**
 * Comparator is an interface for any class possessing an element comparison
 * method.
 * 
 * @author Doug Lea
 * @version 0.93
 *          <P>
 *          For an introduction to this package see <A HREF="index.html">
 *          Overview </A>.
 */

public interface Comparator {

    /**
     * Compare two Objects with respect to ordering. Typical implementations
     * first cast their arguments to particular types in order to perform
     * comparison
     * 
     * @param fst
     *            first argument
     * @param snd
     *            second argument
     * @return a negative number if fst is less than snd; a positive number if
     *         fst is greater than snd; else 0
     */
    public int compare(Object fst, Object snd);
}
