/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

import org.deri.mins.terms.Term;

/*

 Name: Head.java

 Version: 1.0

 Purpose:

 History:

 */

public class Head extends RuleAtom {
    // Kopfatom

    public Head(int sym, Term[] terme) {
        // sym = Pr�dikatsymbol,terme = Feld von anz Termen
        super(sym, terme);
        up = new Atoms(terms.length);
        addup = new Atoms(terms.length);
        down = new Atoms(anzvars);
        adddown = new Atoms(anzvars);
    }

    public boolean Up(Atoms brel, int bindex[]) {
        // Substituiert die Variablen im Kopfatom durch die Zeilen der Relation
        // brel und fuegt die
        // entstandenen Grundatome in die Relation up ein
        int oldnum, newnum;
        oldnum = up.anztuples;
        up.Substitute(this, brel, bindex);
        newnum = up.anztuples;
        return oldnum != newnum;
    }
}
