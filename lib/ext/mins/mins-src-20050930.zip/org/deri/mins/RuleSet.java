/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*



 Version: 1.7

 Purpose: the kernel of the inference engine,
 container for rules and queries, 
 represents the system graph,
 contains all methods concerning the system graph, i.e. adding rules, etc.
 contains the optimization and evaluation methods

 History: constant propagation improved (jan)
 optimize2 reimplemented (jan)
 search for strong components in rule graph implemented (jan)
 cache is now freed correctly in ClearRuleSet (jan)
 deleting rules now cuts the ATMS edges and retracts results of the rules (jan)
 poor mans rule optimizer realized (jan)
 poor mans rule optimizer now evaluates some rules in database only (jan)
 methods InferOn and InferOff added (jan)
 */

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Stack;
import java.util.Vector;

import org.deri.mins.api.DBInterface;
import org.deri.mins.api.EEDBInterface;
import org.deri.mins.builtins.BuiltinConfig;
import org.deri.mins.terms.*;

public class RuleSet implements DBInterface, EEDBInterface {
    public int debuglevel = 0; // ein h�herer debuglevel produziert mehr

    // debuginformation

    public Rule rules = null; // Zeiger auf Liste von Regeln

    public int anzrules = 0; // Anzahl von Regeln

    int maxpreds = 0; // maximales Pr�dikatsymbol

    Rule facts[] = null; // Feld von Regeln f�r Fakten

    Head heads[] = null; // Feld von Kopfatomen

    Body bodies[] = null; // Feld von Rumpfatomen

    int increment = 200; // dynamische Erweiterung der Felder facts, heads,

    // bodies um incr

    Rule strata[] = null; // Anordnung der Regeln nach strata

    Rule evalstrata[] = null; // Strata, die noch evaluiert werden m�ssen

    Rule queries = null; // Liste von Queries

    int maxstratum = 0; // maximales Stratum

    int startstratum = 0; // Stratum an dem die Top-Down Evaluierung beginnt

    int evalmethod = 3; // Gibt die Evaluierungsmethode an: 0: Naiv, 1:

    // Dynamisch, 2: wellfounded dynamisch

    Rule evalqueue = null; // Warteschlange zur Evaluierung bei wellfounded

    Rule lastqueue = null; // letzter in Warteschlange

    boolean optimized = false; // Terme von unten nach oben durchpropagiert

    boolean writeonly = false; // Flag, dass nur eine Datei geschrieben wird

    PrintStream ffacts, frules; // Dateien, in die geschrieben wird

    // SParser spars = null; // Parser zum Einlesen des internen Formats

    DBInterface db; // Datenbank in der die Fakten liegen

    boolean evalfinished = true; // gibt an, ob gepagte Evaluierung beendet

    // ist

    Rule builtinrules[] = null; // rules for the used builtins

    Vector newrules; // rules inserted since last rollbackpoint

    Vector newfacts; // facts inserted since last rollbackpoint

    boolean rollback = false; // rollback enabled

    boolean infer = true; // rules are used for inferencing

    int dfbi = 0;

    Stack scc = new Stack();

    int stratum = 0;

    int minstratum = maxstratum + 1;

    int dir = -1;

    public static final int STRINGSTART = 100000;

    /**
     * Constructs a ruleset which may contain facts, rules and queries. A
     * ruleset provides all to evaluate a set of queries posed to the set of
     * facts and rules. The available builtin predicates are given by "bltns".
     * The location where the facts are stored is given by "database". This
     * location may either be a real database like "mysql" or all facts are held
     * in RAM using the class "DB". This is configured in SimpleEvaluatorConfig
     */
    public RuleSet(BuiltinConfig bltns, DBInterface database) {
        maxpreds = increment - 1;
        facts = new Rule[increment];
        heads = new Head[increment];
        bodies = new Body[increment];
        queries = null;
        db = database;
        // spars = new SParser(bltns);
        newrules = new Vector();
        newfacts = new Vector();
        builtinrules = new Rule[bltns.getBuiltinNumber()];
    }

    private void addbuiltinrule(int sym, int len, BuiltinFunc f) {
        // inserts a rule for a builtin
        Head heads[];
        Body bodies[];
        Rule r;
        Term termsh[], termsb[];
        int i;
        if (builtinrules[sym] == null) {
            termsh = new Term[len];
            termsb = new Term[len];
            for (i = 0; i < len; i++) {
                termsh[i] = new Variable(i);
                termsb[i] = new Variable(i);
            }
            heads = new Head[1];
            heads[0] = new Head(sym, termsh);
            bodies = new Body[1];
            bodies[0] = new BuiltinBody(sym, false, termsb, f);
            // Erzeugung der Regel
            r = new Rule(heads, bodies);
            r.builtin = true;
            builtinrules[sym] = r;
            addRule(r, false);
        }
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#AddFact(int, org.deri.mins.GroundAtom)
     */
    public void addFact(int sym, GroundAtom fact) {
        // F�gt ein einzelnes Faktum zu den externen Fakten hinzu
        Fact f;
        GroundAtom inserted;
        if (debuglevel >= 2) {
            System.out.println("->AddFact");
            System.out.print("p" + Integer.toString(sym) + "(");
            fact.print();
            System.out.println(").");
        }

        if (writeonly) {
            fact.internalize(ffacts, sym);
            ffacts.println("");
        }
        else {
            fact.symbol = sym;
            // Einf�gen des Faktums in die Datenbank
            // db.AddFact(sym,fact);
            addfactrule(sym, fact.terms.length);
            if (rollback) {
                inserted = facts[sym].heads[0].up.Insert(fact);
                if (inserted != fact) {
                    if (inserted.deleted) {
                        inserted.deleted = false;
                        inserted.Enable();
                    }
                }
                else {
                    facts[sym].heads[0].addup.Insert(fact);
                    insertqueue(facts[sym]);
                }
                newfacts.addElement(inserted);
            }
            else
                db.addFact(sym, fact);
        }
    }

    private void addfactrule(int sym, int len) {
        Head f;
        Head heads[];
        Rule r;
        Term terms[];
        int i;
        // falls noetig RuleSet erweitern
        checksym(sym);
        if (facts[sym] == null) {
            // noch keine Faktenregel dieses Pr�dikatsymbols vorhanden
            // Erzeugen einer neuen Regel dieses Symbols
            terms = new Term[len];
            for (i = 0; i < len; i++)
                terms[i] = new Variable(i);
            f = new Head(sym, terms);
            // Erzeugung der Regel ohne Rumpf
            heads = new Head[1];
            heads[0] = f;
            r = new Rule(heads, null);
            r.facts = true;
            facts[sym] = r;
            // addRule(r);
            addRule(r, false);
        }
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#AddFacts(int, org.deri.mins.Atoms)
     */
    public void addFacts(int sym, Atoms facts) {
        GroundAtom f;
        f = facts.First();
        while (f != null) {
            addFact(sym, f);
            f = facts.Next();
        }
    }

    /*
     * protected void AddBaseRule(Rule r) { Head h; Body b; Body bodies[];
     * Filter c; bodies = new Body[1]; b = new Body(r.heads[0].symbol, false,
     * r.heads[0].terms); bodies[0] = b; r.bodies = bodies; h = new
     * Head(r.heads[0].symbol,r.heads[0].terms); c = new Filter(h,r.bodies[0]);
     * c.filter = new Atoms(r.bodies[0].terms.length); c.addfilter = new
     * Atoms(r.bodies[0].terms.length); c.checkterms = false; b.adddown =
     * r.heads[0].adddown; b.down = r.heads[0].down; addRule(r,false);
     * r.anzbodies = 1; }
     */

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#AddRule(org.deri.mins.Rule)
     */
    public void addRule(Rule r) {
        int i;
        if ((r.anzbodies == 0) && (r.anzvars == 0)) {
            for (i = 0; i < r.anzheads; i++) {
                addFact(r.heads[i].symbol, new GroundAtom(r.heads[i].terms));
            }
        }
        else {
            if (writeonly) {
                r.internalize(frules);
                frules.println();
            }
            else {
                if (r.anzheads == 0) {
                    // Query
                    r.next4 = queries;
                    r.last4 = null;
                    if (queries != null)
                        queries.last4 = r;
                    queries = r;
                }
                addRule(r, true);
                if (rollback)
                    newrules.addElement(r);
            }
        }
    }

    private void addRule(Rule r, boolean recurs) {
        int i, j;
        boolean unifiable;
        Filter c;

        r.next2 = null; // Verzeigerung f�r Straten

        // Pr�dikatsymbole der Regel in RuleSet eintragen
        for (i = 0; i < r.anzbodies; i++)
            checksym(r.bodies[i].symbol);
        for (i = 0; i < r.anzheads; i++)
            checksym(r.heads[i].symbol);

        // Builtin Regeln und Faktenregeln erzeugen
        if (!r.builtin) {
            for (i = 0; i < r.anzbodies; i++) {
                if (r.bodies[i].builtin) {
                    addbuiltinrule(r.bodies[i].symbol,
                            r.bodies[i].terms.length,
                            ((BuiltinBody) r.bodies[i]).func);
                    r.bodies[i].builtin = false;
                }
                else {
                    addfactrule(r.bodies[i].symbol, r.bodies[i].terms.length);
                }
            }
        }

        // Eintragen der Regel in die Liste aller Regeln
        r.next1 = rules;
        if (rules != null)
            rules.last1 = r;
        rules = r;
        anzrules++;
        r.no = anzrules;

        // Regel in Systemgraph einf�gen

        if (!recurs) {
            // alle K�pfe mit den Rumpfatomen der Regel verbinden
            connectToBodies(r);
            // alle R�mpfe mit den Kopfatomen der Regel verbinden
            connectToHeads(r);
        }

        // Eintragen der Rumpfatome in die Liste aller Rumpfatome
        for (i = 0; i < r.anzbodies; i++) {
            r.bodies[i].next = bodies[r.bodies[i].symbol];
            if (bodies[r.bodies[i].symbol] != null)
                bodies[r.bodies[i].symbol].last = r.bodies[i];
            bodies[r.bodies[i].symbol] = r.bodies[i];
        }
        // Eintragen der Kopfatome in die Liste aller Kopfatome
        for (i = 0; i < r.anzheads; i++) {
            r.heads[i].next = heads[r.heads[i].symbol];
            if (heads[r.heads[i].symbol] != null)
                heads[r.heads[i].symbol].last = r.heads[i];
            heads[r.heads[i].symbol] = r.heads[i];
        }
        if (recurs) {
            // alle K�pfe mit den Rumpfatomen der Regel verbinden
            connectToBodies(r);
            // alle R�mpfe mit den Kopfatomen der Regel verbinden
            connectToHeads(r);
        }

    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#AddRule(java.lang.String, org.deri.mins.Rule)
     */

    public void addRule(String s, Rule r) {
        addRule(r);
        r.ruletext = s;
    }

    private void checksym(int sym) {
        // neues Pr�dikatsymbol
        // falls noetig RuleSet erweitern
        if (sym > maxpreds)
            extendRuleSet(sym);
    }

    private void clearruleset() {
        // L�sche alle Zwischenergebnisse der Evaluierung ohne die
        // Zwischenergebnisse der Negation
        // Wird zur Evaluierung der wellfounded Semantics f�r den Alternativen
        // Fixpunkt ben�tigt
        Rule r;
        Filter c;
        int i;
        for (r = rules; r != null; r = r.next1) {
            if (!r.facts)
                r.ClearRule1();
            for (i = 0; i < r.anzbodies; i++)
                for (c = r.bodies[i].filter; c != null; c = c.nexthead) {
                    c.filter = new Atoms(c.filter.stellen);
                    c.addfilter = new Atoms(c.addfilter.stellen);
                }
            for (i = 0; i < r.anzheads; i++)
                for (c = r.heads[i].filter; c != null; c = c.nextbody) {
                    c.filter = new Atoms(c.filter.stellen);
                    c.addfilter = new Atoms(c.addfilter.stellen);
                }
        }

    }

    /** Deletes all cashed intermediate results and frees memory */
    public void ClearRuleSet() {
        // L�sche alle Zwischenergebnisse der Evaluierung
        // Query q;
        Rule r;
        Filter c;
        int i;
        for (r = rules; r != null; r = r.next1) {
            r.ClearRule();
            for (i = 0; i < r.anzbodies; i++)
                for (c = r.bodies[i].filter; c != null; c = c.nexthead) {
                    c.filter = new Atoms(c.filter.stellen);
                    c.addfilter = new Atoms(c.addfilter.stellen);
                }
            for (i = 0; i < r.anzheads; i++)
                for (c = r.heads[i].filter; c != null; c = c.nextbody) {
                    c.filter = new Atoms(c.filter.stellen);
                    c.addfilter = new Atoms(c.addfilter.stellen);
                }
        }

    }

    private void clearTermSets() {
        Rule r;
        int i, j;
        for (r = rules; r != null; r = r.next1) {
            if (!r.external && !r.facts) {
                for (i = 0; i < r.anzbodies; i++) {
                    for (j = 0; j < r.bodies[i].termsets.length; j++) {
                        r.bodies[i].termsets[j] = null;
                        r.bodies[i].changets[j] = false;
                        r.bodies[i].btermsets[j] = null;
                        r.bodies[i].changebts[j] = false;
                    }
                }
            }
        }
        // TermSet.printstatistics();
    }

    /** Deletes the propagated terms created by optimization 1 and optimization 2 */
    public void ClearTermSets() {
        Rule r;
        int i, j;
        Filter c;
        for (r = rules; r != null; r = r.next1) {
            if (!r.external && !r.facts) {
                for (i = 0; i < r.anzbodies; i++) {
                    for (j = 0; j < r.bodies[i].termsets.length; j++) {
                        r.bodies[i].termsets[j] = null;
                        r.bodies[i].changets[j] = false;
                        r.bodies[i].btermsets[j] = null;
                        r.bodies[i].changebts[j] = false;
                    }
                }
            }
            for (i = 0; i < r.anzheads; i++) {
                for (c = r.heads[i].filter; c != null; c = c.nextbody) {
                    for (j = 0; j < c.termsets.length; j++) {
                        c.termsets[j] = null;
                    }
                }
            }
        }
        optimized = false;
    }

    private void connectToBodies(Rule r) {
        // Kopfatome der Regel r mit passenden Rumpfatomen
        // aller Regeln verbinden
        int i;
        Body b;
        boolean unifiable;
        Filter c;
        i = 0;
        for (i = 0; i < r.anzheads; i++) {
            for (b = bodies[r.heads[i].symbol]; b != null; b = (Body) b.next) {
                unifiable = r.heads[i].Unify(b);
                r.heads[i].ClearVariables();
                b.ClearVariables();
                if (unifiable) {
                    c = new Filter(r.heads[i], b);
                    // connect(c,r.heads[i],b);
                    c.filter = new Atoms(b.terms.length);
                    c.addfilter = new Atoms(b.terms.length);
                }
            }
        }
    }

    private void connectToHeads(Rule r) {
        // die Rumpfatome der Regel r mit allen passenden Kopfatomen
        // aller Regeln verbinden
        int i;
        Head h;
        Filter c;
        boolean unifiable;
        for (i = 0; i < r.anzbodies; i++) {
            for (h = heads[r.bodies[i].symbol]; h != null; h = (Head) h.next) {
                if (!h.rule.facts) {
                    unifiable = h.Unify(r.bodies[i]);
                    h.ClearVariables();
                    r.bodies[i].ClearVariables();
                }
                else
                    unifiable = true;
                if (unifiable) {
                    c = new Filter(h, r.bodies[i]);
                    c.filter = new Atoms(r.bodies[i].terms.length);
                    c.addfilter = new Atoms(r.bodies[i].terms.length);
                }
            }
        }
    }

    private Rule createQuery(int praedikatsymbol) {
        Rule query = null;
        Term[] terms;
        Body[] bodies;
        int j;

        if (heads[praedikatsymbol] != null) {
            terms = new Term[heads[praedikatsymbol].terms.length];
            for (j = 0; j < heads[praedikatsymbol].terms.length; j++) {
                terms[j] = new Variable(j);
            }
            bodies = new Body[1];
            bodies[0] = new Body(praedikatsymbol, false, terms);
            query = new Rule(null, bodies);
        }
        return query;
    }

    private void DBAccess(DBInterface db, Rule r) {
        Atoms A;
        Filter c;
        if (debuglevel >= 2)
            System.out.println("DBAccess:");

        if (r.heads[0].adddown.anztuples > 0) {
            A = db.getFacts(r.heads[0].symbol, r.heads[0].adddown);
            if (A != null) {
                r.heads[0].up.Union(A);
                r.heads[0].addup.UnionSelected(r.heads[0].up);
                if (debuglevel >= 2) {
                    A.print(System.out);
                }
            }
        }
        r.heads[0].adddown = new Atoms(r.heads[0].adddown.stellen);
    }

    private void DBAccessNaive(DBInterface db, Rule r) {
        Atoms A, F;
        GroundAtom B;
        F = new Atoms(r.heads[0].terms.length);
        B = F.Insert(r.heads[0]);
        A = db.getFacts(r.heads[0].symbol, F);
        if (A != null) {
            r.heads[0].up = A;
        }
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#DeleteFact(int, org.deri.mins.GroundAtom)
     */
    public void deleteFact(int sym, GroundAtom fact) {
        if (debuglevel >= 2) {
            System.out.println("->DeleteFact");
            System.out.print("p" + Integer.toString(sym) + "(");
            fact.print();
            System.out.println(").");
        }
        GroundAtom a;
        db.deleteFact(sym, fact);
        a = facts[sym].heads[0].up.Search(fact);
        if (a != null) {
            a.Retract();
            facts[sym].heads[0].up.Delete(a);
            facts[sym].heads[0].addup.Delete(a);
        }

    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#DeleteRule(org.deri.mins.Rule)
     */
    public void deleteRule(Rule r) {
        int i;
        Body b;
        Head h;
        // System.out.println("->DeleteRule"); System.out.println(r.toString());
        if ((r.anzbodies == 0) && (r.anzvars == 0)) {
            for (i = 0; i < r.anzheads; i++) {
                deleteFact(r.heads[i].symbol, r.heads[i]);
            }
        }
        else {
            if (r.anzheads == 0) {
                // Query l�schen
                if (queries == r) {
                    queries = r.next4;
                    if (r.next4 != null)
                        r.next4.last4 = null;
                }
                else {
                    r.last4.next4 = r.next4;
                    if (r.next4 != null)
                        r.next4.last4 = r.last4;
                }
            }
            // L�schen aus der Liste aller Regeln
            if (rules == r) {
                rules = r.next1;
                if (rules != null)
                    rules.last1 = null;
            }
            else {
                r.last1.next1 = r.next1;
                if (r.next1 != null)
                    r.next1.last1 = r.last1;
            }
            anzrules--;

            // Regel aus Systemgraph l�schen
            // Verbindungen der K�pfe mit den Rumpfatomen l�sen
            disconnectFromBodies(r);
            // Verbindungen der R�mpfe mit den Kopfatomen der Regeln l�sen
            disconnectFromHeads(r);

            // L�schen der Rumpfatome aus der Liste aller Rumpfatome
            for (i = 0; i < r.anzbodies; i++) {
                b = r.bodies[i];
                if (bodies[r.bodies[i].symbol] == b) {
                    bodies[r.bodies[i].symbol] = (Body) b.next;
                    if (b.next != null)
                        b.next.last = null;
                }
                else {
                    b.last.next = b.next;
                    if (b.next != null)
                        b.next.last = b.last;
                }
            }

        }

        // L�schen der Kopfatome aus der Liste aller Kopfatome
        for (i = 0; i < r.anzheads; i++) {
            h = r.heads[i];
            if (heads[r.heads[i].symbol] == h) {
                heads[r.heads[i].symbol] = (Head) h.next;
                if (h.next != null)
                    h.next.last = null;
            }
            else {
                h.last.next = h.next;
                if (h.next != null)
                    h.next.last = h.last;
            }
        }
        // Regel aus Stratum l�schen
        if (r.next2 != null) {
            if (strata[r.stratum] == r) {
                strata[r.stratum] = r.next2;
                if (r.next2 != null)
                    r.next2.last2 = null;
            }
            else {
                r.last2.next2 = r.next2;
                if (r.next2 != null)
                    r.next2.last2 = r.last2;
            }
            r.next2 = null;
            r.stratum = 0;
        }
        // L�schen aus der Liste der Queries
        if (queries == r)
            queries = r.next4;
        if (r.last4 != null)
            r.last4.next4 = r.next4;
        // L�schen der Zwischenergebnisse
        r.ClearRule();

    }

    private void dfscc(RuleAtom v) {
        /*
         * Bestimmung starker Zusammenhangskomponenten Algorithmus nach Ottmann,
         * Widmayer
         */
        RuleAtom vstrich, u;
        Rule r;
        Filter c;
        int i;
        boolean nocycle = false;
        v.visited = true;
        dfbi++;
        v.dfbi = dfbi;
        v.q = dfbi;
        scc.push(v);
        v.stacked = true;
        if (v instanceof Head) {
            for (c = ((Head) v).filter; c != null; c = c.nextbody) {
                vstrich = c.body;
                if (!vstrich.visited) {
                    dfscc(vstrich);
                    if (vstrich.q < v.q)
                        v.q = vstrich.q;
                }
                else if ((vstrich.dfbi < v.dfbi) && vstrich.stacked)
                    if (vstrich.dfbi < v.q)
                        v.q = vstrich.dfbi;
            }
        }
        else if (v instanceof Body) {
            for (i = 0; i < ((Body) v).rule.anzheads; i++) {
                vstrich = ((Body) v).rule.heads[i];
                if (!vstrich.visited) {
                    dfscc(vstrich);
                    if (vstrich.q < v.q)
                        v.q = vstrich.q;
                }
                else if ((vstrich.dfbi < v.dfbi) && vstrich.stacked)
                    if (vstrich.dfbi < v.q)
                        v.q = vstrich.dfbi;
            }
        }

        if (v.q == v.dfbi) {
            nocycle = ((RuleAtom) scc.peek() == v);
            // if (!nocycle) System.out.println("strong component:");
            do {
                u = (RuleAtom) scc.pop();
                u.stacked = false;
                // if (!nocycle) {u.print(System.out); System.out.print(" / ");
                // System.out.println(u.rule.toString()); System.out.println();}
                if (!nocycle)
                    u.cycle = true;
            } while (u != v);
            // System.out.println();
        }
    }

    private void disconnectFromBodies(Rule r) {
        // Verbindungen zwischen Kopfatomen von r und den Rumpfatomen aller
        // Regeln l�sen
        int i;
        // Head h;
        Filter c, c1 = null;
        for (i = 0; i < r.anzheads; i++) {
            // Zur�ckziehen der Regelergebnisse
            r.heads[i].up.Retract();
            for (c = r.heads[i].filter; c != null; c = c1) {
                c1 = c.nextbody;
                c.Unlink();
            }
        }
    }

    private void disconnectFromHeads(Rule r) {
        // Verbindungen zwischen Rumpfatomen von r und
        // den Kopfatomen aller Regeln l�sen
        int i;
        // Head h;
        Filter c, c1 = null;
        for (i = 0; i < r.anzbodies; i++) {
            r.bodies[i].up.Mark(1);
            for (c = r.bodies[i].filter; c != null; c = c1) {
                c.head.up.CutATMS();
                c1 = c.nexthead;
                c.Unlink();
            }
            r.bodies[i].up.Mark(0);
        }
    }

    private int DynamicFiltering() {
        // Volles Dynamisches Filtern mit Sideways Passing
        Filter f;
        Rule r;
        int i; // j, oldanz;
        // TermSet ts;
        boolean change = false, changedown = false, changeup = false;
        int lines = 0;
        int oldanz;

        stratum = startstratum;
        do {
            // change = false;
            // Propagieren von Fakten nach oben, Konstanten nach unten, Sideways
            // Passing
            r = evalstrata[stratum];
            if (r != null) {
                evalstrata[stratum] = r.next3;
                r.next3 = null;
                r.toeval = false;
                if (infer || r.facts || r.builtin || (r.anzheads == 0)) {
                    // Evaluierung
                    if (!r.facts && !r.external) {
                        change = r.DynamicFiltering();
                        oldanz = r.addhrel.anztuples;
                        if (change)
                            insertstratum(r);
                        if (r.heads == null) {
                            lines += r.addhrel.anztuples - oldanz;
                            // System.out.println(r.addhrel.anztuples - oldanz);
                        }

                    }

                    // Ergaenzen der Filter
                    for (i = 0; i < r.anzbodies; i++) {
                        if (r.bodies[i].adddown.anztuples > 0) {
                            for (f = r.bodies[i].filter; f != null; f = f.nexthead) {
                                changedown = false;
                                changedown = f.Down(optimized);
                                if (changedown && (f.head.rule != null)) {
                                    insertstratum(f.head.rule);
                                    if (f.head.rule.stratum < minstratum)
                                        minstratum = f.head.rule.stratum;
                                }
                                // change = change || changedown;

                            }
                            r.bodies[i].adddown = new Atoms(
                                    r.bodies[i].adddown.stellen);
                        }
                    }

                    // Zugriff auf Datenbank
                    if (r.facts) {
                        DBAccess(db, r);
                    }

                    // Propagierung der Evaluierungsergebnisse mit Filtern nach
                    // oben
                    for (i = 0; i < r.anzheads; i++) {
                        for (f = r.heads[i].filter; f != null; f = f.nextbody) {
                            changeup = f.Up();
                            if (((f.body.neg) && f.reduceDelay()) || changeup) {
                                insertstratum(f.body.rule);
                            }
                            // change = change || changeup;
                        }
                        r.heads[i].addup = new Atoms(r.heads[i].addup.stellen);
                        if (!(r.heads[i].up.anztuples > 0)) {
                            for (f = r.heads[i].filter; f != null; f = f.nextbody) {
                                if ((f.body.neg) && f.reduceDelay()) {
                                    insertstratum(f.body.rule);
                                }
                            }
                        }
                    }
                }
            }
            if (evalstrata[stratum] == null) {
                if ((dir == -1) && (stratum == minstratum)) {
                    dir = 1;
                    minstratum = maxstratum + 1;
                }
                else if (stratum > minstratum)
                    dir = -1;
                stratum += dir;
            }
        } while ((lines == 0) && ((stratum <= maxstratum) && (stratum >= 0)));
        evalfinished = true;
        return lines;
    }

    /*
     * Evaluates all queries which have been added to the ruleset public boolean
     * EvalQueries() { // Evaluiert alle mit AddQuery eingefuegten Queries
     * gemeinsam Rule q; // boolean inserted,change; switch (evalmethod) { case
     * 0: NaiveEval(); break; case 1: for(q = queries; q != null; q = q.next4) { //
     * dynamische Evaluierung starttuple(q); // F�ge Query in das entsprechende
     * Stratum ein q.next3 = evalstrata[q.stratum]; evalstrata[q.stratum] = q;
     * if (startstratum < q.stratum) startstratum = q.stratum; } //
     * SwitchFilters(); DynamicFiltering(); break; case 2: WellFoundedAF();
     * break; case 3: for(q = queries; q != null; q = q.next4) { starttuple(q);
     * insertqueue(q); } Filtering(); break; } }
     */

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#EvalQueries()
     */
    public boolean evalQueries() {
        if (evalmethod == 0 || evalmethod ==1) {
            Stratify();
        }
        Rule q;
        int lines = 0;
        if (evalfinished) {
            evalfinished = false;
            switch (evalmethod) {
            case 0:
                lines = NaiveEval();
                evalfinished = true;
                break;
            case 1:
                for (q = queries; q != null; q = q.next4) {
                    // dynamische Evaluierung
                    starttuple(q);
                    // F�ge Query in das entsprechende Stratum ein
                    q.next3 = evalstrata[q.stratum];
                    evalstrata[q.stratum] = q;
                    if (startstratum < q.stratum)
                        startstratum = q.stratum;
                }
                // SwitchFilters();
                lines = DynamicFiltering();
                break;
            case 2:
                lines = WellFoundedAF();
                evalfinished = true;
                break;
            case 3:
                for (q = queries; q != null; q = q.next4) {
                    starttuple(q);
                    insertqueue(q);
                }
                lines = Filtering();
                break;
            }
        }
        else {
            switch (evalmethod) {
            case 0:
                break;
            case 1:
                lines = DynamicFiltering();
                break;
            case 2:
                break;
            case 3:
                lines = Filtering();
                break;
            }

        }
        return !evalfinished;
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#EvalRule(org.deri.mins.Rule)
     */
    public int evalRule(Rule r) {
        return 0;
    }

    /** Evaluates only rule q and all dependent rules */
    private void evalrule(Rule q) {
        // Evaluiert alle mit AddQuery eingefuegten Queries gemeinsam
        // System.out.print("Evaluierungsmethode: ");
        // System.out.println(evalmethod);
        switch (evalmethod) {
        case 0:
            NaiveEval();
            break;
        case 1:
            // dynamische Evaluierung
            starttuple(q);
            // F�ge Query in das entsprechende Stratum ein
            q.next3 = evalstrata[q.stratum];
            evalstrata[q.stratum] = q;
            if (startstratum < q.stratum)
                startstratum = q.stratum;
            // SwitchFilters();
            DynamicFiltering();
            break;
        case 2:
            WellFoundedAF();
            break;
        case 3:
            starttuple(q);
            insertqueue(q);
            Filtering();
            break;
        }
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#EvaluationMethod(int)
     */
    public void setEvaluationMethod(int method) {
        // Umschalten der Evaluierungsmethoden
        this.evalmethod = method;
    }

    private void extendRuleSet(int index) {
        // erweitert die Felder factsext, factsint, bodies und heads, so dass
        // sie auch den Index 'index'
        // enthalten
        int len, i;
        Rule newfacts[];
        Body newbodies[];
        Head newheads[];
        len = maxpreds + 1;
        if (maxpreds < index) {
            while (len < index + 1)
                len += increment;
            newfacts = new Rule[len];
            newbodies = new Body[len];
            newheads = new Head[len];
            for (i = 0; i <= maxpreds; i++) {
                newfacts[i] = facts[i];
                newbodies[i] = bodies[i];
                newheads[i] = heads[i];

            }
            facts = newfacts;
            bodies = newbodies;
            heads = newheads;
        }
        maxpreds = len - 1;
    }

    private int Filtering() {
        // Volles Dynamisches Filtern mit Sideways Passing
        // ATMS zur Berechnung des wellfounded models
        Filter f;
        Rule r;
        int i;
        boolean change = false, changedown = false, changeup = false;
        int lines = 0; // wieviele Antworten wurden bereits produziert
        int oldanz, oldsures;
        java.util.Enumeration enm;
        GroundAtom t;

        if (debuglevel > 0)
            System.out.println("-> wellfounded evaluation");

        do {
            change = false;
            // Propagieren von Fakten nach oben, Konstanten nach unten, Sideways
            // Passing
            r = getqueue();
            if (debuglevel > 0) {
                System.out.print(r.toString());
                System.out.println();
            }
            if (r != null
                    && (infer || r.facts || r.builtin || (r.anzheads == 0))) {
                // Propagierung der Konstanten und Evaluierung
                if (!r.facts && !r.external) {
                    oldsures = r.addhrel.suretuples;
                    oldanz = r.addhrel.anztuples;
                    change = r.DynamicFilteringWF();
                    /*
                     * if (change) { insertqueue(r); }
                     */
                    if (r.heads == null) {
                        lines += r.addhrel.suretuples - oldsures;
                        // r.addhrel.print(System.out);
                        // System.out.println(lines);
                    }

                }
                // Ergaenzen der Filter
                for (i = 0; i < r.anzbodies; i++) {
                    if (r.bodies[i].adddown.anztuples > 0) {
                        for (f = r.bodies[i].filter; f != null; f = f.nexthead) {
                            changedown = f.Down(optimized);
                            if (changedown && (f.head.rule != null)) {
                                insertqueue(f.head.rule);
                            }
                            // change = change || changedown;
                        }
                        r.bodies[i].adddown = new Atoms(
                                r.bodies[i].adddown.stellen);
                    }
                }
                // Zugriff auf externen InferenzServer
                if (r.external) {
                    XAccess(r);
                }
                // Zugriff auf Datenbank
                if (r.facts) {
                    DBAccess(db, r);
                }

                // Propagierung der Evaluierungsergebnisse mit Filtern nach oben
                for (i = 0; i < r.anzheads; i++) {
                    // System.out.println();
                    for (f = r.heads[i].filter; f != null; f = f.nextbody) {
                        changeup = f.Up();
                        if (changeup) {
                            insertqueue(f.body.rule);
                            // System.out.print("insertup1: ");
                            // System.out.println(f.body.rule.no);
                        }
                        // change = change || changeup;
                    }
                    r.heads[i].addup = new Atoms(r.heads[i].addup.stellen);
                }
            }
            if (IClient.no > 0) {
                // System.out.println(IClient.no);
                try {
                    Thread.yield();
                } catch (Exception x) {
                    System.out.println(x);
                    System.exit(-1);
                }
            }

            if (evalqueue == null) {
                // System.out.println("eins");
                for (r = rules; r != null; r = r.next1) {
                    if (r.waitingtuples > 0) {
                        // System.out.println("einsa");
                        // System.out.println("rule with waiting tuples");
                        insertqueue(r);
                    }
                }
            }

        } while ((lines == 0) && ((evalqueue != null) || (IClient.no > 0)));
        // System.out.println("zwei");
        if (evalqueue == null) {
            // System.out.println("drei");
            lines = 0;
            for (r = queries; r != null; r = r.next4) {
                enm = r.addhrel.elements();
                while (enm.hasMoreElements()) {
                    t = (GroundAtom) enm.nextElement();
                    t.sure = true;
                }
                lines += r.addhrel.anztuples;
            }
            evalfinished = true;
        }
        if (debuglevel > 0)
            System.out.println("<- wellfounded evaluation");
        return lines;
    }

    private void FilteringAF(int durchlauf) {
        // Volles Dynamisches Filtern mit Sideways Passing
        Filter f;
        Rule r;
        int i; // j, oldanz;
        boolean change = false, changedown = false, changeup = false;

        do {
            // change = false;
            // Propagieren von Fakten nach oben, Konstanten nach unten, Sideways
            // Passing
            r = getqueue();
            // System.out.println(r.no);

            if (r != null
                    && (infer || r.facts || r.builtin || (r.anzheads == 0))) {
                // Propagierung der Konstanten und Evaluierung
                change = false;
                if (!r.facts && !r.external) {
                    change = r.DynamicFiltering();
                    if (change)
                        insertqueue(r);
                }

                // Ergaenzen der Filter
                for (i = 0; i < r.anzbodies; i++) {
                    if (r.bodies[i].adddown.anztuples > 0) {
                        for (f = r.bodies[i].filter; f != null; f = f.nexthead) {
                            changedown = f.Down(optimized);
                            if (changedown) {
                                if (f.head.rule != null)
                                    insertqueue(f.head.rule);
                            }
                            // change = change || changedown;
                        }
                        r.bodies[i].adddown = new Atoms(
                                r.bodies[i].adddown.stellen);
                    }
                }

                // Zugriff auf Datenbank
                if (r.facts) {
                    DBAccess(db, r);
                }

                // Propagierung der Evaluierungsergebnisse mit Filtern nach oben
                for (i = 0; i < r.anzheads; i++) {
                    for (f = r.heads[i].filter; f != null; f = f.nextbody) {
                        changeup = f.Up(durchlauf);
                        if (((f.body.neg) && f.reduceDelay()) || changeup) {
                            insertqueue(f.body.rule);
                        }
                        // change = change || changeup;
                    }
                    r.heads[i].addup = new Atoms(r.heads[i].addup.stellen);
                    if (!(r.heads[i].up.anztuples > 0)) {
                        for (f = r.heads[i].filter; f != null; f = f.nextbody) {
                            if ((f.body.neg) && f.reduceDelay()) {
                                insertqueue(f.body.rule);
                            }
                        }
                    }
                }
            }
        } while (evalqueue != null);
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#GetFacts(int, org.deri.mins.Atoms)
     */
    public Atoms getFacts(int praedikatsymbol, Atoms filterterme) {
        Rule query;
        // Filter c;
        Substitution subs;

        if ((query = createQuery(praedikatsymbol)) != null) {
            query.drelation = filterterme;
            this.addRule(query);
            this.evalQueries();
            subs = this.getSubstitution(query);
            this.deleteRule(query);
            return subs;
        }
        else
            return null;
    }

    private synchronized Rule getqueue() {
        Rule r;
        r = evalqueue;
        if (r != null) {
            evalqueue = r.next3;
            r.toeval = false;
            r.next3 = null;
        }
        return r;
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#GetTerms(int, int)
     */
    public TermSet getTerms(int praedikatsymbol, int i) {
        Rule query;
        Filter c;
        TermSet ts;
        if ((query = createQuery(praedikatsymbol)) != null) {
            this.addRule(query);
            if (!optimized)
                this.Optimize2();
            ts = new TermSet();
            for (c = query.bodies[0].filter; c != null; c = c.nexthead) {
                if (c.termsets[i] != null)
                    ts.Union(c.termsets[i]);
            }
            this.deleteRule(query);
            return ts;
        }
        else {
            return new TermSet();
        }
    }

    TermSet getxterms(Rule r, int par) {
        Socket socket = null;
        DataInputStream is = null;
        PrintStream os = null;
        TermSet ts = new TermSet();

        // System.out.print("getxterms ");

        // Initialize the sockets and streams
        while (true) {
            try {
                InetAddress ina = InetAddress.getByName(r.host);
                socket = new Socket(ina, r.port);
                break;

            } catch (IOException e) {
                // System.err.println("Exception: couldn't connect to database"
                // + e.getMessage());
            }
        }
        try {
            is = new DataInputStream(socket.getInputStream());
            os = new PrintStream(socket.getOutputStream(), true);
        } catch (IOException e) {
            System.err.println("Exception: couldn't create stream to database"
                    + e.getMessage());
        }

        // Process user input and server responses
        try {
            String inLine;
            Term t;
            os.println("terms");
            os.println(r.heads[0].symbol);
            os.println(par);
            os.flush();
            // System.out.println("Ergebnisse: ");
            while ((inLine = is.readLine()) != null) {
                // System.out.print("inline: "); System.out.println(inLine);
                if (inLine.length() > 0) {
                    throw new UnsupportedOperationException(
                            "due to refactogin and loosing parser...");
                    // if (inLine.equals("stop"))
                    // break;
                    // spars.ParseString(inLine);
                    // try {
                    // t = spars.term();
                    // ts.Insert(t);
                    // } catch (SParseError e) {
                    // }
                }
            }
            // Cleanup
            os.close();
            is.close();
            socket.close();
        } catch (IOException e) {
            System.err.println("I/O error: " + e.toString());
        }
        return ts;
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#InferOff()
     */
    public void inferOff() {
        infer = false;
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#InferOn()
     */
    public void inferOn() {
        infer = true;
    }

    public synchronized void insertqueue(Rule r) {
        if (!r.toeval) {
            if (evalqueue == null) {
                evalqueue = r;
                lastqueue = r;
            }
            else {
                lastqueue.next3 = r;
                lastqueue = r;
            }
            r.toeval = true;
        }
    }

    private void insertstratum(Rule r) {
        if (!r.toeval) {
            r.next3 = evalstrata[r.stratum];
            evalstrata[r.stratum] = r;
            r.toeval = true;
        }
    }

    public boolean isEvaluable(Rule r) {
        return false;
    }

    /**
     * Returns the last evaluation results of a query.<br>
     * Returns a set of ground atoms which are <br>
     * substitutions of atom "body".
     */
    public Atoms LastResult(Rule q, int body) {
        // Ausgabe des Evaluierungsergebnisses als Menge von Grundatomen von
        // body
        Atoms r = new Atoms(q.bodies[body].terms.length);
        if (evalmethod == 0)
            r.Substitute(q.bodies[body], q.bodies[q.anzbodies - 1].brelation,
                    q.bodies[q.anzbodies - 1].bindex);
        else {
            r.Substitute(q.bodies[body], q.addhrel, q.hrelation.matchindex);
            q.addhrel = new Atoms(q.addhrel.stellen);
        }
        return r;
    }

    /**
     * Returns the last evaluation results of query q.<br>
     * The result is a set of variable substitutions of the variables<br>
     * in q.
     */
    public Substitution LastSubstitution(Rule q) {
        // gibt die durch die Evaluierung erzeugte Variablenssubstitution fuer
        // die query aus
        Substitution subs;
        java.util.Enumeration enm;
        GroundAtom t, anchor = null;
        int anzdels = 0;

        if (evalmethod == 0) {
            subs = new Substitution(q.bodies[q.anzbodies - 1].bindex,
                    q.bodies[q.anzbodies - 1].brelation.stellen);
            subs.Union(q.bodies[q.anzbodies - 1].brelation);
        }
        else {
            subs = new Substitution(q.hrelation.matchindex, q.hrelation.stellen);
            // System.out.println(q.addhrel.anztuples);
            // System.out.println(q.hrelation.anztuples);
            enm = q.addhrel.elements();
            while (enm.hasMoreElements()) {
                t = (GroundAtom) enm.nextElement();
                if (t.sure) {
                    subs.Insert(t);
                    t.next2 = anchor;
                    anchor = t;
                    anzdels++;
                }
            }

            if (anzdels == q.addhrel.anztuples)
                q.addhrel = new Atoms(q.addhrel.stellen);
            else {
                for (t = anchor; t != null; t = t.next2)
                    q.addhrel.Delete(t);
            }

            // subs.Union(q.addhrel);
        }
        return subs;
    }

    public static void main(String args[]) {
    }

    private void markrules(Rule r) {
        Filter f;
        int i;
        if (r.mark < 3) {
            r.mark = 3;
            if (r.heads != null) {
                for (i = 0; i < r.heads.length; i++) {
                    for (f = r.heads[i].filter; f != null; f = f.nextbody)
                        markrules(f.body.rule);
                }
            }
        }
    }

    private int NaiveEval() {
        // Naive Evaluierung der Regeln gemaess der Stratifizierung in strata
        // Head h;
        int i;
        Filter c;
        Rule q;
        Rule r;
        boolean change;
        int stratum = 0;
        int oldanz;
        int lines = 0;
        for (stratum = 0; stratum <= maxstratum; stratum++) {
            do {
                // Naive Evaluierung und Propagierung von Grundatomen nach oben
                change = false;
                for (r = strata[stratum]; r != null; r = r.next2) {
                    if (infer || r.facts || r.builtin || (r.anzheads == 0)) {
                        if (!r.external) {
                            if (!r.facts)
                                change = r.NaiveEval() || change;
                            else
                                DBAccessNaive(db, r);
                            // Propagierung von Grundatomen nach oben
                            for (i = 0; i < r.anzheads; i++) {
                                for (c = r.heads[i].filter; c != null; c = c.nextbody) {
                                    oldanz = c.body.up.anztuples;
                                    c.body.up.Match(c.body, c.head.up);
                                    change = change
                                            || (oldanz < c.body.up.anztuples);
                                }
                            }
                        }
                    }
                }
            } while (change);
        }
        for (q = queries; q != null; q = q.next4)
            lines += q.brelation.anztuples;
        evalfinished = true;
        return lines;
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#NextQuery(org.deri.mins.Rule)
     */
    public Rule nextQuery(Rule query) {
        // gibt die n�chste Query zur�ck, die erste query wird
        // durch query=null abgefragt
        if (query == null) {
            return queries;
        }
        else
            return query.next4;
    }

    private boolean nofunc(RuleAtom A) {
        int i;
        for (i = 0; i < A.terms.length; i++) {
            if (!(A.terms[i] instanceof Variable) && !(A.terms[i].ground))
                return false;
        }
        return true;
    }

    private boolean nofunction(Rule r) {
        int i;
        for (i = 0; i < r.heads.length; i++)
            if (!nofunc(r.heads[i]))
                return false;
        return true;
    }

    void optimize(boolean all) {
        Rule r;
        Filter c;
        int i, j, k, l;
        boolean changeup = false;
        int oldanz;
        boolean change = true, nullvalue;

        if (all) {
            for (r = rules; r != null; r = r.next1) {
                if (r.facts) {
                    // hole alle m�glichen Terme f�r das Argument i aus der
                    // Datenbank
                    for (i = 0; i < r.btermsets.length; i++) {
                        r.btermsets[i] = db.getTerms(r.heads[0].symbol, i);
                    }
                    // printtermsets(r);
                }
                if (r.external) {
                    // hole alle m�glichen Terme f�r das Argument i aus der
                    // externen Quelle
                    for (i = 0; i < r.btermsets.length; i++) {
                        r.btermsets[i] = getxterms(r, i);
                    }
                }
            }
        }
        while (change) {
            change = false;
            for (r = rules; r != null; r = r.next1) {
                if (!r.facts && !r.external && !r.builtin) {
                    change = r.TermEval();
                    // printtermsets(r);

                }
                for (i = 0; i < r.anzheads; i++) {
                    for (c = r.heads[i].filter; c != null; c = c.nextbody) {
                        for (j = 0; j < r.heads[i].terms.length; j++) {
                            changeup = false;
                            if (r.heads[i].terms[j].ground) {
                                if (c.termsets[j] == null)
                                    c.termsets[j] = new TermSet();
                                oldanz = c.termsets[j].anzterms;
                                c.termsets[j].Insert(r.heads[i].terms[j]);
                                changeup = (c.termsets[j].anzterms != oldanz);
                            }
                            else if (r.heads[i].terms[j] instanceof Variable) {
                                k = ((Variable) r.heads[i].terms[j]).symbol;
                                if (r.btermsets[k] != null) {
                                    if (c.termsets[j] == null)
                                        c.termsets[j] = new TermSet();
                                    oldanz = c.termsets[j].anzterms;
                                    c.termsets[j].Union(r.btermsets[k]);
                                    changeup = (c.termsets[j].anzterms != oldanz)
                                            || changeup;
                                }
                            }
                            if ((c.body.terms[j] instanceof Variable)
                                    && changeup) {
                                l = ((Variable) c.body.terms[j]).symbol;
                                if (c.body.termsets[l] == null)
                                    c.body.termsets[l] = new TermSet();
                                c.body.termsets[l].Union(c.termsets[j]);
                            }
                            change = change || changeup;
                        }
                    }
                }
            }
        }

        /*
         * Funktionen in K�pfen oder Builtinregeln schalten die
         * Konstantenpropagierung aus
         */
        change = true;
        while (change) {
            change = false;
            for (r = rules; r != null; r = r.next1) {
                for (i = 0; i < r.anzheads; i++) {
                    for (j = 0; j < r.heads[i].terms.length; j++) {
                        nullvalue = false;
                        if ((!r.heads[i].terms[j].ground && !(r.heads[i].terms[j] instanceof Variable))
                                || r.builtin) {
                            nullvalue = true;
                        }
                        else if (r.heads[i].terms[j] instanceof Variable) {
                            k = ((Variable) r.heads[i].terms[j]).symbol;
                            if (r.btermsets[k] == null)
                                nullvalue = true;
                        }
                        if (nullvalue) {
                            for (c = r.heads[i].filter; c != null; c = c.nextbody) {
                                if (c.termsets[j] != null)
                                    change = true;
                                c.termsets[j] = null;
                                if (c.body.terms[j] instanceof Variable) {
                                    l = ((Variable) c.body.terms[j]).symbol;
                                    if (c.body.rule.btermsets[l] != null)
                                        change = true;
                                    c.body.rule.btermsets[l] = null;
                                }
                            }
                        }
                    }
                }
            }
        }

        // Statistics();

        clearTermSets();
        optimized = true;

    }

    /** Propagates all constants within the rules through the system graph */
    public void Optimize1() {
        optimize(false);
    }

    /**
     * Propagates all constants within the rules and the facts through the
     * system graph. If there are too many facts this may need too much memory
     */
    public void Optimize2() {
        optimize(true);
    }

    /**
     * Poor mans rule optimizer. For some rules the extension is determined
     * which is stored in database. Afterwards the rules are deleted.
     */
    public void Optimize3() {
        Rule r;
        int i, s;
        int anz = 1;
        Filter f;
        // System.out.println("-> Optimize3");
        // Markierungen l�schen
        for (r = rules; r != null; r = r.next1)
            r.mark = 0;

        // markiere nicht evaluierbare Regeln und davon abh�ngige Regeln
        for (r = rules; r != null; r = r.next1)
            if ((r.mark == 0) && (r.heads != null) && !r.facts && !r.builtin)
                if (!db.isEvaluable(r) && !nofunction(r))
                    markrules(r);

        for (s = 0; s < anzrules; s++) {
            while (anz != 0) {
                anz = 0;
                for (r = strata[s]; r != null; r = r.next2) {
                    if ((r.mark < 3) && (r.heads != null) && !r.facts
                            && !r.builtin) {
                        if (db.isEvaluable(r)) {
                            // evaluate rule in database
                            anz += db.evalRule(r);
                            for (i = 0; i < r.heads.length; i++) {
                                addfactrule(r.heads[i].symbol,
                                        r.heads[i].terms.length);
                            }
                            r.mark = 1;
                        }
                        else if (nofunction(r)) {
                            // evaluate rule
                            evalrule(r);
                            for (i = 0; i < r.heads.length; i++) {
                                anz += r.heads[i].addup.anztuples;
                                addFacts(r.heads[i].symbol, r.heads[i].addup);
                            }
                            r.mark = 2;
                        }
                    }
                }
            }
        }
        for (r = rules; r != null; r = r.next1) {
            if ((r.mark == 1) || (r.mark == 2))
                deleteRule(r);
        }
        // Markierungen l�schen
        for (r = rules; r != null; r = r.next1)
            r.mark = 0;
        ClearRuleSet();
    }

    /**
     * Returns all the evaluation results of a query.<br>
     * Returns a set of ground atoms which are <br>
     * substitutions of atom "body".
     */
    public Atoms Result(Rule q, int body) {
        // Ausgabe des Evaluierungsergebnisses als Menge von Grundatomen von
        // body
        Atoms r = new Atoms(q.bodies[body].terms.length);
        if (evalmethod == 0)
            r.Substitute(q.bodies[body], q.bodies[q.anzbodies - 1].brelation,
                    q.bodies[q.anzbodies - 1].bindex);
        else
            r.Substitute(q.bodies[body], q.hrelation, q.hrelation.matchindex);
        return r;
    }

    /**
     * Deletes all rules and facts which have been added<br>
     * since last call of method "SetRollbackPoint.<br>
     * Does not work correctly together with poor mans rule optimizer<br>
     * (method "Optimize3()").
     */
    public void Rollback() {
        Rule r;
        GroundAtom a;
        java.util.Enumeration enm;
        // System.out.println("->Rollback");

        for (enm = newfacts.elements(); enm.hasMoreElements();) {
            a = (GroundAtom) enm.nextElement();
            a.deleted = true;
            // facts[a.symbol].heads[0].up.Delete(a);
            // facts[a.symbol].heads[0].addup.Delete(a);
            a.Retract();
            // DeleteFact(a.symbol,a);
        }
        for (enm = newrules.elements(); enm.hasMoreElements();) {
            r = (Rule) enm.nextElement();
            deleteRule(r);
        }
        rollback = false;
    }

    /**
     * All facts and rules which are added afterwards are recorded. <br>
     * Call of method "Rollback" then deletes these facts and rules.<br>
     * Does not work correctly together with poor mans rule optimizer<br>
     * (method "Optimize3()").
     */
    public void SetRollbackPoint() {
        // System.out.println("->SetRollbackPoint");
        newrules.removeAllElements();
        newfacts.removeAllElements();
        rollback = true;
    }

    private void starttuple(Rule q) {
        Atom a;
        int i;
        if (q.drelation.anztuples == 0) {
            a = new Atom(q.anzvars);
            for (i = 0; i < q.anzvars; i++)
                a.terms[i] = new Variable(i);
            a.Variables();
            a = (Atom) q.drelation.Insert(a);
        }
    }

    /**
     * Determines the strata of the rules. <br>
     * Returns false if rules are not stratifiable.
     */
    public boolean Stratify() {
        // Bestimmen der Strata der einzelnen Regeln und
        // Umsortierung der Regeln nach den Strata
        // Algorithmus nach Ullmann
        Rule r;
        // Filter c;
        // int i;
        boolean change = true;
        // Rule regeln[];
        maxstratum = 0;
        // int strat;
        while ((maxstratum <= anzrules) && change) {
            change = false;
            for (r = rules; r != null; r = r.next1) {
                if (!r.facts && !r.external)
                    change = stratum(r) || change;
                if (maxstratum < r.stratum)
                    maxstratum = r.stratum;
            }
        }
        // Einf�gen der Regeln in das Feld strata gem�� oben
        // berechneten Strata
        if (maxstratum <= anzrules) {
            strata = new Rule[maxstratum + 2];
            evalstrata = new Rule[maxstratum + 2];
            for (r = rules; r != null; r = r.next1) {
                r.next2 = strata[r.stratum];
                if (strata[r.stratum] != null)
                    strata[r.stratum].last2 = r;
                strata[r.stratum] = r;
            }
            strata[maxstratum + 1] = null;
            return true;
        }
        else
            return false;
    }

    private boolean stratum(Rule r) {
        // bestimmt das Stratum einer Regel in Abh�ngigkeit der Straten der
        // Rumpfatome
        Filter c;
        int i;
        int strat;
        boolean change = false;
        for (i = 0; i < r.anzbodies; i++) {
            for (c = r.bodies[i].filter; c != null; c = c.nexthead) {
                strat = c.head.rule.stratum;
                if (r.bodies[i].neg)
                    strat = strat + 1;
                if (r.stratum < strat) {
                    r.stratum = strat;
                    change = true;
                }
            }
        }
        return change;
    }

    /**
     * Determines the strong components of the system graph.<br>
     * Must be called before first evaluation using wellfounded evaluation.
     */
    public void StrongComponents() {
        Rule r;
        RuleAtom a;
        int i;
        dfbi = 0;
        for (r = rules; r != null; r = r.next1) {
            for (i = 0; i < r.anzbodies; i++) {
                r.bodies[i].visited = false;
                r.bodies[i].stacked = false;
            }
            for (i = 0; i < r.anzheads; i++) {
                r.heads[i].visited = false;
                r.heads[i].stacked = false;
            }
        }
        for (r = rules; r != null; r = r.next1) {
            if (r.facts)
                dfscc(r.heads[0]);
        }
    }

    /* (non-Javadoc)
     * @see org.deri.mins.EEDBInterface#Substitution(org.deri.mins.Rule)
     */
    public Substitution getSubstitution(Rule q) {
        // gibt die durch die Evaluierung erzeugte Variablenssubstitution fuer
        // die query aus
        Substitution subs;
        if (evalmethod == 0) {
            subs = new Substitution(q.bodies[q.anzbodies - 1].bindex,
                    q.bodies[q.anzbodies - 1].brelation.stellen);
            subs.Union(q.bodies[q.anzbodies - 1].brelation);
        }
        else {
            subs = new Substitution(q.hrelation.matchindex, q.hrelation.stellen);
            subs.Union(q.hrelation);
        }
        return subs;
    }

    private int WellFoundedAF() {
        boolean change = true; // inserted;
        Rule q, r;
        int durchlauf = 0;
        Atom a;
        int i, lines = 0;

        while ((change || (durchlauf % 2 == 1)) && (durchlauf < 20)) {
            clearruleset();
            evalqueue = null;
            lastqueue = null;
            for (q = queries; q != null; q = q.next4) {
                a = new Atom(q.anzvars);
                for (i = 0; i < q.anzvars; i++)
                    a.terms[i] = new Variable(i);
                a.Variables();
                a = (Atom) q.drelation.Insert(a);
                insertqueue(q);
            }
            FilteringAF(durchlauf);
            change = false;
            for (r = rules; r != null; r = r.next1) {
                change = r.Switch() || change;
            }
            durchlauf++;
        }
        for (q = queries; q != null; q = q.next4)
            lines += q.hrelation.anztuples;
        evalfinished = true;
        return lines;
    }

    private void XAccess(Rule r) {
        IClient xi;
        Filter c;
        c = r.bodies[0].filter;
        // c.Down(optimized);
        if (c.head.adddown.anztuples > 0)
            xi = new IClient(r, c.head, this);
        c.addfilter = new Atoms(c.addfilter.stellen);
    }
}