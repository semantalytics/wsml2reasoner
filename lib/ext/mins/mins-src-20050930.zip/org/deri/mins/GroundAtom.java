/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: GroundAtom.java

 Version: 1.3

 Purpose: represents a ground atom

 history: function internalize delivering a string of internal formal added (jan)
 ATMS changed to eliminate positive cycles (jan)
 CutATMS added (jan)
 */

import java.io.PrintStream;
import java.util.LinkedList;

import org.deri.mins.terms.Term;


public class GroundAtom {
    static long actmark = 0; // for cycle detection

    public long cyclemark = 0;

    public int mark = 0; // Markierung

    private static boolean debug = false;

    public static long no = 0;

    // Instanz repraesentiert ein GrundAtom
    // public int len = 0; Gr��e der Reihung, Anzahl Indices
    public GroundAtom next2 = null; // Verkettung von Tupeln

    public long lasttouched = 0; // Zeitstempel f�r letzten Touch

    public boolean deleted = false; // L�schmarke

    public Term terms[]; // Terme des Atoms

    public ATMS supported = null; // Verweise auf abhaengige Atome

    int no_supports = 0; // Anzahl Verweise auf dieses Atom

    int max_supports = 0;

    public boolean and = false; // f�r ATMS

    int symbol;

    // public static int actno = 0;
    public long num = 0;

    static LinkedList atmslist = null;

    public boolean cycle = false; // gibt an, ob sich das Atom in einem Zyklus

    // befindet

    public boolean sure = true; // atom may not become unknown

    public GroundAtom(Term t[]) {
        no++;
        num = no;
        int anz = 0;
        int i;
        if (t != null)
            anz = t.length;
        // this.len = anz;
        terms = new Term[anz];
        for (i = 0; i < anz; i++)
            terms[i] = t[i];
        // no = Atom.actno++;
    }

    /** Anz is the number of terms */
    public GroundAtom(int anz) {
        no++;
        num = no;
        // len = anz;
        terms = new Term[anz];
        // no = Atom.actno++;
        // hashit();
    }

    private void changeSupport(boolean pos, GroundAtom source) {
        if (debug) {
            System.out.print("-> changeSupport: ");
            this.print(System.out);
            System.out.println();
        }
        GroundAtom a;
        ATMS at;
        actmark++;
        atmslist = new LinkedList();
        changeSupport1(pos);
        while (atmslist.size() > 0) {
            a = (GroundAtom) atmslist.removeFirst();
            a.checkSupport();
        }
        atmslist = null;
    }

    private void changeSupport1(boolean pos) {
        if (debug) {
            System.out.print("-> changeSupport1(");
            System.out.print(pos);
            System.out.print(",");
            this.print(System.out);
            System.out.print("):");
            System.out.println(this.no_supports);
        }
        ATMS at;
        if (pos) {
            no_supports++;
            if (this.deleted) {
                if ((and && (no_supports >= max_supports))
                        || (!and && (no_supports > 0)) || cycle) {
                    if (!and && no_supports <= 0) {
                        atmslist.addLast(this);
                        if (debug) {
                            System.out.print("      Store:    ");
                            this.print();
                            System.out.println();
                        }
                    }

                    this.deleted = false;
                    if (debug) {
                        System.out.print("      Undelete: ");
                        this.print();
                        System.out.println();
                    }
                    if (this.cyclemark != actmark) {
                        this.cyclemark = actmark;
                        for (at = this.supported; at != null; at = at.next)
                            at.atom.changeSupport1(at.pos);
                    }
                }
            }
        }
        else {
            no_supports--;
            if (!this.deleted) {
                if (and || (no_supports <= 0) || cycle) {
                    if (!and && no_supports > 0) {
                        atmslist.addLast(this);
                        if (debug) {
                            System.out.print("      Store:  ");
                            this.print();
                            System.out.println();
                        }
                    }
                    this.deleted = true;
                    if (debug) {
                        System.out.print("      Delete: ");
                        this.print();
                        System.out.println();
                    }
                    if (this.cyclemark != actmark) {
                        this.cyclemark = actmark;
                        for (at = this.supported; at != null; at = at.next)
                            at.atom.changeSupport1(!at.pos);
                    }
                }
            }
        }
    }

    private void changeSupport2(boolean pos) {
        if (debug) {
            System.out.print("-> changeSupport2(");
            System.out.print(pos);
            System.out.print(",");
            this.print(System.out);
            System.out.print("):");
            System.out.println(this.no_supports);
        }
        ATMS at;
        if (pos) {
            no_supports++;
            if (this.deleted) {
                if ((and && (no_supports >= max_supports))
                        || (!and && (no_supports > 0))) {
                    this.deleted = false;
                    if (debug) {
                        System.out.print("      Undelete: ");
                        this.print();
                        System.out.println();
                    }
                    for (at = this.supported; at != null; at = at.next)
                        at.atom.changeSupport2(at.pos);
                }
            }
        }
        else {
            no_supports--;
            if (!this.deleted) {
                if (and || (!and && (no_supports <= 0))) {
                    this.deleted = true;
                    if (debug) {
                        System.out.print("      Delete: ");
                        this.print();
                        System.out.println();
                    }
                    for (at = this.supported; at != null; at = at.next)
                        at.atom.changeSupport2(!at.pos);
                }
            }
        }
    }

    private void checkSupport() {
        if (debug) {
            System.out.print("-> checkSupport: ");
            this.print(System.out);
            System.out.print(":");
            System.out.println(this.no_supports);
        }
        ATMS at;
        if (this.deleted) {
            if ((and && (no_supports >= max_supports))
                    || (!and && (no_supports > 0))) {
                this.deleted = false;
                if (debug) {
                    System.out.print("      Undelete: ");
                    this.print();
                    System.out.println();
                }
                for (at = this.supported; at != null; at = at.next)
                    at.atom.changeSupport2(at.pos);
            }
        }
        else {
            if (and || (!and && (no_supports <= 0))) {
                this.deleted = true;
                if (debug) {
                    System.out.print("      Delete: ");
                    this.print();
                    System.out.println();
                }
                for (at = this.supported; at != null; at = at.next)
                    at.atom.changeSupport2(!at.pos);
            }
        }
    }

    public int Compare(int i1, GroundAtom t2, int i2) {
        return terms[i1].Compare((t2).terms[i2]);
    }

    public int CompareAtoms(GroundAtom t) {
        // vergleicht zwei Tupel miteinander
        int i;
        int res = 0;
        for (i = 0; (i < terms.length) && (res == 0); i++)
            res = terms[i].Compare((t).terms[i]);
        return res;
    }

    /** Deletes edges in ATMS from this atom to all marked atoms */
    public void CutATMS() {
        ATMS h, hold = null;
        for (h = this.supported; h != null; h = h.next) {
            // falls angeh�ngtes Atom markiert ausketten aus Liste
            if (h.atom.mark > 0) {
                if (hold == null)
                    this.supported = h.next;
                else
                    hold.next = h.next;
            }
            hold = h;
        }
    }

    public void Disports(GroundAtom a) {
        ATMS h;
        if (!this.deleted) {
            for (h = this.supported; h != null; h = h.next) {
                if (!h.pos)
                    (h.atom).changeSupport(false, a);
            }
        }
    }

    public void Enable() {
        ATMS h;
        for (h = this.supported; h != null; h = h.next) {
            if (h.pos) {
                (h.atom).changeSupport(true, this);
            }
        }
    }

    public String internalize() {
        int i;
        String s;

        s = String.valueOf(terms.length);
        for (i = 0; i < terms.length; i++) {
            if (terms[i] != null)
                s = s + terms[i].internalize();
        }
        return s;
    }

    public void internalize(PrintStream p) {
        int i;
        p.print("l" + String.valueOf(terms.length));
        for (i = 0; i < terms.length; i++) {
            if (terms[i] != null)
                terms[i].internalize(p);
        }
    }

    public void internalize(PrintStream p, int sym) {
        int i;
        p.print("p" + String.valueOf(sym) + "l" + String.valueOf(terms.length));

        for (i = 0; i < terms.length; i++) {
            if (terms[i] != null)
                terms[i].internalize(p);
        }

    }

    public void negDependency(GroundAtom a) {
        ATMS h;
        for (h = this.supported; (h != null) && (h.atom != a); h = h.next)
            ;
        if (h == null) {
            h = new ATMS(a);
            h.pos = false;
            h.next = this.supported;
            this.supported = h;
            // a.changeSupport(false, this);
            // if (this.path())
            // System.out.println();
            // System.out.print(this.num); System.out.print("-!");
            // System.out.println(a.num);
        }
    }

    public void print() {
        int i;
        // Variable v;
        // System.out.print("lastchanged: "); System.out.print(lastchanged);
        for (i = 0; i < terms.length; i++) {
            if (terms[i] != null)
                terms[i].print(System.out);
            else
                System.out.print("null");
            if (i < terms.length - 1)
                System.out.print(",");
        }
        System.out.print(" : ");
        System.out.print(num);
        if (deleted)
            System.out.print(":del");
    }

    public void print(PrintStream p) {
        int i;
        // Variable v;
        // System.out.print("lastchanged: "); System.out.print(lastchanged);
        for (i = 0; i < terms.length; i++) {
            if (terms[i] != null)
                terms[i].print(p);
            else
                p.print("null");
            if (i < terms.length - 1)
                p.print(",");
        }
        p.print(" : ");
        p.print(num);
        if (deleted)
            p.print(":del");

    }

    public void print(PrintStream p, String pr[], String f[], String s[]) {
        int i;
        // Variable v;
        // System.out.println("Atom.print");
        // System.out.print("lastchanged: "); System.out.print(lastchanged);
        for (i = 0; i < terms.length; i++) {
            p.print("\""); // System.out.print("->");
            if (terms[i] != null)
                terms[i].print(p, pr, f, s);
            // if (terms[i] != null) terms[i].print(System.out,pr,f,s);
            else
                p.print("null");
            p.print("\""); // System.out.print("<-");
            if (i < terms.length - 1) {
                p.print(",");
                // System.out.print(",");
            }
        }
        // System.out.println();
        // System.out.print(" : "); System.out.print(no);
    }

    public void print(PrintStream p, int sym) {
        int i;
        // Variable v;
        p.print("p");
        p.print(sym);
        p.print("(");
        for (i = 0; i < terms.length; i++) {
            if (terms[i] != null)
                terms[i].print(p);
            else
                p.print("null");
            if (i < terms.length - 1)
                p.print(",");
        }
        p.print(")");
    }

    public void print(PrintStream p, int sym, String pr[], String f[],
            String s[]) {
        int i;
        // Variable v;
        p.print(pr[sym]);
        p.print("(");
        for (i = 0; i < terms.length; i++) {
            if (terms[i] != null)
                terms[i].print(p, pr, f, s);
            else
                p.print("null");
            if (i < terms.length - 1)
                p.print(",");
        }
        p.print(")");
    }

    public void Retract() {
        ATMS h;
        for (h = this.supported; h != null; h = h.next) {
            if (h.pos)
                (h.atom).changeSupport(false, this);
        }
    }

    /** Atom a is supported by this atom */
    public void Supports(GroundAtom a) {
        ATMS h;
        for (h = this.supported; (h != null) && (h.atom != a); h = h.next)
            ;
        if (h == null) {

            if (debug) {
                this.print(System.out);
                System.out.print(" -> ");
                a.print(System.out);
                System.out.println();
            }
            h = new ATMS(a);
            a.max_supports += 1;
            h.next = this.supported;
            this.supported = h;
            if (this.sure == false)
                a.sure = false;
            a.changeSupport(true, this);
            // if (a.max_supports < a.no_supports) a.max_supports =
            // a.no_supports;
            if (deleted) {
                a.changeSupport(false, this);
            }
        }
    }

    private void throwException() {
        try {
            throw new Exception();

        } catch (Exception e) {
            System.err.println("Exception: " + e);
            e.printStackTrace();
            System.exit(0);
        }
    }

    public String toString() {
        int i;
        String s = "";
        for (i = 0; i < terms.length; i++) {
            if (terms[i] != null)
                s += terms[i].toString();
            else
                s += "null";
            if (i < terms.length - 1)
                s += ",";
        }
        s += " : ";
        s += Long.toString(num);
        if (deleted)
            s += ":del";
        return s;
    }

    public String toString(String p, String pr[], String f[], String st[]) {
        int i;
        // Variable v;
        String s = p + "(";
        for (i = 0; i < terms.length; i++) {
            if (terms[i] != null)
                s = s.concat(terms[i].toString(pr, f, st));
            if (i < terms.length - 1)
                s = s.concat(",");
        }
        s = s.concat(")");
        return s;
    }
}
