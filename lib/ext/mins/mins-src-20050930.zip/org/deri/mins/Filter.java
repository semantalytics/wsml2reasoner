/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

import org.deri.mins.terms.TermSet;
import org.deri.mins.terms.Variable;

/*

 Name: Filter.java

 Version: 1.0

 Purpose: represents the filters in the system graph

 History: 
 */

public class Filter {
    // Kante des Systemgraphen, verbindet ein Bodyatom mit einem Headatom
    public Filter nexthead = null; // n�chstes Kopfatom, das mit dem Rumpfatom

    // body verbunden ist

    Filter lasthead = null; // doppelte Verzeigerung

    Filter nextbody = null; // n�chstes Rumpfatom, das mit dem Kopfatom head

    // verbunden ist

    Filter lastbody = null; // doppelte Verzeigerung

    public Head head = null; // Referenz auf Kopfatom

    Body body = null; // Referenz auf Rumpfatom

    Atoms filter = null; // Filteratome der Kante

    boolean on = true; // Filter an oder aus

    Atoms addfilter = null; // inkrementelle Bestimmung von Filtern

    boolean delayed = false; // Negation

    TermSet termsets[]; // Terme, die an den einzelnen Stellen auftreten k�nnen

    boolean checkterms = true; // Filtern der nach unten laufenden Atome

    boolean filterincremental = true;

    public Filter(Head h, Body b) {
        // Neuanlegen einer Verbindung zwischen Kopfatom h und Rumpfatom b
        head = h;
        body = b;
        nextbody = h.filter;
        if (h.filter != null)
            h.filter.lastbody = this;
        h.filter = this;
        nexthead = b.filter;
        if (b.filter != null) {
            b.filter.lasthead = this;
        }
        b.filter = this;
        b.no++;
        termsets = new TermSet[b.terms.length];
    }

    private boolean directmatch(GroundAtom a) {
        int i;
        for (i = 0; i < a.terms.length; i++) {
            if (!(a.terms[i] instanceof Variable))
                return false;
            else
                ((Variable) a.terms[i]).hsymbol = 0;
        }
        for (i = 0; i < a.terms.length; i++) {
            ((Variable) a.terms[i]).hsymbol++;
            if (((Variable) a.terms[i]).hsymbol > 1)
                return false;
        }
        return true;
    }

    boolean Down(boolean optimized) {
        // Propagierung von Termen durch den Filter nach unten
        int oldanz; // oldanz1;
        Atoms B;
        Atoms A;
        int i;
        // Atom t;
        boolean changedown = false;
        // int i;
        oldanz = filter.anztuples;
        B = body.adddown;
        if (on) {
            if (body.adddown.anztuples > 0) {

                if (optimized && checkterms) {
                    // Kopieren der Atome in addown
                    B = new Atoms(body.adddown.stellen);
                    B.Union(body.adddown);
                    oldanz = B.anztuples;
                    // L�schen von Filtertermen aufgrund der nach
                    // oben propagierten Terme

                    B.Select(termsets);
                    B.DeleteSelected();

                }

                // Filtersubsumption
                if (B.anztuples > 1)
                    B.Subsumption(B);
                filter.Subsumption(B);
                B.Subsumption(filter);

                /*
                 * // Filtergeneralisierung A = new Atoms(filter.stellen);
                 * A.Generalize(filter,B); filter.DeleteSelected();
                 * B.DeleteSelected(); B.Union(A);
                 */

            }
        }
        if ((head.rule == null) || (head.rule.facts)) {
            head.down.Union(B);
            head.adddown.UnionSelected(head.down);
            if (on) {
                // Einfuegen in Filter fuer Fakten (keine Unifikation noetig)
                // filter.UnionAndSelected(B,addfilter);
                oldanz = filter.anztuples;
                filter.Union(B);
                // filter.UnionSelected(head.down);
                if (filterincremental)
                    addfilter.UnionSelected(filter);
                changedown = oldanz < filter.anztuples;
            }
        }
        else {
            // Unifikation mit Kopfatom der Regel
            head.down.Unify(head, B);
            changedown = (head.down.tuples2 != null);
            head.adddown.UnionSelected(head.down);
            if (on) {
                // Ergaenzen des Filters
                // filter.UnionAndSelected(B,addfilter);
                // filter.Union(B);
                oldanz = filter.anztuples;
                filter.UnionSelected(B);
                if (filterincremental)
                    addfilter.UnionSelected(filter);
                changedown = (filter.anztuples > oldanz) || changedown;
            }
        }
        if (changedown) {
            if (body.neg && !delayed) {
                delayed = true;
                body.delays++;
                body.delayed = true;
            }
        }
        return changedown;
    }

    private boolean open(Atoms f) {
        GroundAtom a;
        int i;
        if (f.anztuples == 1) {
            f.SelectAll();
            a = f.tuples2;
            return directmatch(a);
        }
        return false;
    }

    boolean reduceDelay() {
        if (delayed) {
            delayed = false;
            body.delays--;
            if (body.delays == 0) {
                body.delayed = false;
                return true;
            }
        }
        return false;
    }

    public void Unlink() {
        // Verbindung zwischen Kopf- und Rumpfatom loesen
        if (head.filter == this)
            head.filter = nextbody;
        if (body.filter == this)
            body.filter = nexthead;
        if (lastbody != null)
            lastbody.nextbody = nextbody;
        if (nextbody != null)
            nextbody.lastbody = lastbody;
        if (lasthead != null)
            lasthead.nexthead = nexthead;
        if (nexthead != null)
            nexthead.lasthead = lasthead;
    }

    boolean Up() {
        boolean changeup = false;
        boolean dmatch = false;
        if (on) {
            if (filter.anztuples > 0) {
                // dmatch = directmatch(body);
                /*
                 * if (directmatch(body)) { System.out.println("1"); } if
                 * (open(filter)) { System.out.println("2"); }
                 */

                /*
                 * if (open(filter) && directmatch(body)) {
                 * body.up.Union(head.addup); body.addup.UnionSelected(body.up);
                 * System.out.println("2"); } else {
                 */

                if (filterincremental) {
                    if (addfilter.anztuples > 0) {
                        body.up.Filtering(body, addfilter, head.up);
                        changeup = (body.up.tuples2 != null);
                        body.addup.UnionSelected(body.up);
                        addfilter = new Atoms(addfilter.stellen);
                    }

                    if (head.addup.anztuples > 0) {
                        body.up.Filtering(body, filter, head.addup);
                        changeup = (body.up.tuples2 != null) || changeup;
                        body.addup.UnionSelected(body.up);
                    }
                }
                else {
                    body.up.Filtering(body, filter, head.up);
                    changeup = (body.up.tuples2 != null) || changeup;
                    body.addup.UnionSelected(body.up);
                }
            }
        }
        else {
            if (head.addup.anztuples > 0) {
                body.up.Match(body, head.addup);
                changeup = (body.up.tuples2 != null);
                body.addup.UnionSelected(body.up);
            }
            body.up.Match(body, head.up);
            changeup = (body.up.tuples2 != null);
            body.addup.UnionSelected(body.up);
        }
        return changeup;
    }

    /*
     * boolean Up() { boolean changeup = false; if (on) { if (filter.anztuples >
     * 0) { if (addfilter.anztuples > 0) {
     * body.up.Filtering(body,addfilter,head.up); changeup = (body.up.tuples2 !=
     * null); body.addup.UnionSelected(body.up); addfilter = new
     * Atoms(addfilter.stellen); } if (head.addup.anztuples > 0) {
     * body.up.Filtering(body,filter,head.addup); changeup = (body.up.tuples2 !=
     * null) || changeup; body.addup.UnionSelected(body.up); } } } else { if
     * (head.addup.anztuples > 0) { body.up.Match(body,head.addup); changeup =
     * (body.up.tuples2 != null); body.addup.UnionSelected(body.up); }
     * body.up.Match(body,head.up); changeup = (body.up.tuples2 != null);
     * body.addup.UnionSelected(body.up); } return changeup; }
     */

    boolean Up(int durchlauf) {
        boolean changeup = false;
        if (on) {
            if (filter.anztuples > 0) {
                if (addfilter.anztuples > 0) {
                    if (!body.neg || (head.rule.facts && (durchlauf == 0))) {
                        body.up.Filtering(body, addfilter, head.up);
                        changeup = (body.up.tuples2 != null);
                        body.addup.UnionSelected(body.up);
                        addfilter = new Atoms(addfilter.stellen);
                    }
                    else {
                        body.up1.Filtering(body, addfilter, head.up);
                        changeup = (body.up1.tuples2 != null);
                        addfilter = new Atoms(addfilter.stellen);
                    }
                }
                if (head.addup.anztuples > 0) {
                    if (!body.neg || (head.rule.facts && (durchlauf == 0))) {
                        body.up.Filtering(body, filter, head.addup);
                        changeup = (body.up.tuples2 != null) || changeup;
                        body.addup.UnionSelected(body.up);
                    }
                    else {
                        body.up1.Filtering(body, filter, head.addup);
                        changeup = (body.up1.tuples2 != null) || changeup;
                    }
                }
            }
        }
        else {
            if (!head.rule.facts) {
                if (head.addup.anztuples > 0) {
                    if (!body.neg || (head.rule.facts && (durchlauf == 0))) {
                        body.up.Match(body, head.addup);
                        changeup = (body.up.tuples2 != null);
                        body.addup.UnionSelected(body.up);
                    }
                    else {
                        body.up1.Match(body, head.addup);
                        changeup = (body.up.tuples2 != null);
                    }
                }
            }
            else {
                if (!body.neg || (head.rule.facts && (durchlauf == 0))) {
                    body.up.Match(body, head.up);
                    changeup = (body.up.tuples2 != null);
                    body.addup.UnionSelected(body.up);
                }
                else {
                    body.up1.Match(body, head.up);
                    changeup = (body.up1.tuples2 != null);
                }
            }
        }
        return changeup;
    }
}
