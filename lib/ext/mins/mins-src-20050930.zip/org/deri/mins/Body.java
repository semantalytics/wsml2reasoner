/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: Body.java

 Version: 1.0

 Purpose: represents rule bodies

 History:
 7.7.1999 Added isNegated method SDe

 */

import java.io.PrintStream;

import org.deri.mins.terms.Term;
import org.deri.mins.terms.TermSet;


public class Body extends RuleAtom {
    // Rumpfatom
    boolean neg; // negiert oder nicht

    Atoms up1 = null; // fuer alternierenden Fixpunkt bei negativen Atomen

    Atoms up2 = null; // fuer alternierenden Fixpunkt bei negativen Atomen

    int bindex[]; // the indices indicate the symbols of the variables, the

    // content the columns of the resulting relation

    int dindex[]; // number j at index i indicates that column i has to be

    // copied to column j in the resulting relation

    Atoms hrelation = null; // Down- und Sidewayspropagierung

    Atoms addhrel = null; // Berechnung bei Negation

    boolean builtin = false; // gibt an, ob es sich um ein Builtin-Atom

    // handelt

    int delays = 0; // Verz�gerung der Auswertung bei Negation

    boolean delayed = false;

    int anzfilters = 0;

    Atoms brelation = null; // inkrementelle Berechnung des joins �ber alle

    // Rumfpatome

    TermSet termsets[];

    boolean changets[];

    TermSet btermsets[];

    boolean changebts[];

    public Body(int sym, boolean negated, Term[] terms) {
        // sym = Pr�dikatsymbol, anz = Stelligkeit, negated = negiert, terms =
        // Feld von anz Termen
        super(sym, terms);
        neg = negated;
        up = new Atoms(anzvars);
        addup = new Atoms(anzvars);
        down = new Atoms(terms.length);
        adddown = new Atoms(terms.length);
        if (negated) {
            up1 = new Atoms(anzvars);
            up2 = new Atoms(anzvars);
        }
    }

    public void ClearRuleAtom() {
        // L�schen der Zwischenergebnisse der Evaluierung
        super.ClearRuleAtom();
        if (up1 != null)
            up1 = new Atoms(up1.stellen);
        if (up2 != null)
            up2 = new Atoms(up2.stellen);
        if (brelation != null)
            brelation = new Atoms(brelation.stellen);
        if (hrelation != null)
            hrelation = new Atoms(hrelation.stellen);
        if (addhrel != null)
            addhrel = new Atoms(addhrel.stellen);
    }

    public void ClearRuleAtom1() {
        // L�schen der Zwischenergebnisse der Evaluierung
        if (!neg)
            up = new Atoms(up.stellen);
        else
            up1 = new Atoms(up1.stellen);
        down = new Atoms(down.stellen);
        adddown = new Atoms(adddown.stellen);
        addup = new Atoms(addup.stellen);
        up = new Atoms(up.stellen);
        if (brelation != null)
            brelation = new Atoms(brelation.stellen);
        if (hrelation != null)
            hrelation = new Atoms(hrelation.stellen);
        if (addhrel != null)
            addhrel = new Atoms(addhrel.stellen);
    }

    public boolean Down(Atoms relation, int index[]) {
        int oldnum, newnum;
        // Downpropagierung ueber Rumpfatom
        oldnum = down.anztuples;
        down.Substitute(this, relation, index);
        newnum = down.anztuples;
        return oldnum != newnum;
    }

    public void internalize(PrintStream p) {
        if (neg) {
            p.print("-");
        }
        super.internalize(p);
    }

    public boolean isNegated() { // to to resort bodyatoms SDe
        return neg;
    }

    public boolean NaiveRight(Atoms brel, int index[]) {
        int oldnum, newnum;
        oldnum = brelation.anztuples;
        if (!neg)
            // Join mit positivem Rumpfliteral
            brelation.Join(brel, index, up, index1, brel.matchindex, dindex);
        else
            // Differenz mit negativem Rumpfliteral
            brelation.Negation(brel, index, up, index1);
        newnum = brelation.anztuples;
        return oldnum != newnum;
    }

    public void print(PrintStream p) {
        if (neg)
            p.print('-');
        super.print(p);
    }

    public boolean Switch() {
        // schaltet die Fakten der negativen Literale um beim alternierenden
        // Fixpunkt
        Atoms h;

        if (neg && !up1.Compare(up2)) {
            h = up2;
            up2 = up;
            up = up1;
            up1 = h;
            return true;
        }
        else
            return false;
    }

    public String toString() {
        if (neg)
            return "-" + super.toString();
        else
            return super.toString();
    }
}
