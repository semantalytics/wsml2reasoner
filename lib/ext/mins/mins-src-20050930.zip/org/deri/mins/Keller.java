/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*
 * this is a stack...
 */
class Keller {
    private int pg;

    private int size;

    private AVLnode k[];

    protected Keller(int max) {
        k = new AVLnode[max + 1];
        size = max;
        pg = -1;
    }

    protected void Clear() {
        pg = -1;
    }

    protected void Copy(Keller kel) {
        int i;
        for (i = 0; i <= kel.pg; i++)
            k[i] = kel.k[i];
        pg = kel.pg;
    }

    protected boolean Empty() {
        return pg < 0;
    }

    protected void Pop() {
        if (pg >= 0)
            pg--;
    }

    protected void print() {
        for (int i = 0; i <= pg; i++) {
            k[i].print();
        }
        System.out.println();
    }

    protected void Push(AVLnode a) {
        k[++pg] = a;
    }

    protected AVLnode Top() {
        if (pg >= 0)
            return k[pg];
        else
            return null;
    }
}
