/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: Rule.java

 Version: 1.1

 Purpose: contains the data structures and evaluation procedures for a rule

 History: TermEval reimplemented (jan)

 */

import java.io.PrintStream;

import org.deri.mins.terms.TermSet;
import org.deri.mins.terms.Variable;


public class Rule {
    private int debuglevel = 0;

    // repr�sentiert eine Regel
    int waitingtuples = 0; // tuples in addhrel, rules with waitingtuples have

    // to be evaluated again

    public Rule next1 = null; // Verkettungen innerhalb von RuleSet

    Rule last1 = null; // Doppeltverzeigerung innerhalb von RuleSet

    Rule next2 = null; // Verkettung der Regeln auf dem gleichen Stratum

    Rule last2 = null; // Doppeltverzeigerung der Straten

    Rule next3 = null; // Verkettung der Regeln auf dem gleichen Stratum zum

    // Evaluieren

    Rule next4 = null; // Verkettung von Fakten und Queries

    Rule last4 = null; // Doppeltverzeigerung

    public int anzheads = 0;

    public int anzbodies = 0; // Anzahl Kopf- und Rumpfatome

    int anzvars = 0; // Anzahl Variablen, Variablen sind von 0 ab nummeriert

    Atoms brelation = null; // Rumpfrelation

    public Atoms hrelation = null; // pos. Ergebnissubstitution bei dynamischer

    // Evaluierung

    Atoms addhrel = null; // inkrementelle Berechnung

    Atoms drelation = null; // Relation zum Verteilen auf Rumpfatome

    int bindex[]; // Variablen�berschriften f�r brelation

    public Body bodies[]; // Rumpfatome

    public Head heads[]; // Kopfatome

    int stratum = 0; // Stratum der Regel

    public boolean facts = false; // Regel repr�sentiert lediglich Fakten

    // (kein Rumpf, Kopf grund)

    boolean toeval = false; // befindet sich in der Evaluierungswarteschlange

    public boolean evaluating = false; // wird gerade evaluiert

    public boolean stoppedevaluating = false; // Evaluierung ist fertig

    public boolean builtin = false; // a builtin rule

    public int no = 0; // Nummerierung der Regeln

    int anzpos = 0; // Anzahl positiver Rumpfterme (muessen vorne stehen)

    int mark = 0;

    int cycle = 0;

    static Atoms brelleer = new Atoms(0);

    static int bindex0[] = { -1 };

    TermSet btermsets[] = null;

    boolean changebts[];

    public boolean external = false; // Regel soll (auch) auf anderem
                                        // Inferenzserver

    // ausgewertet werden

    public String host = ""; // host auf dem sich die Regel in einem anderen

    // Inferenzserver befindet

    public int port = 1000; // port des Inferenzservers

    String ruletext = null; // textuelle Repr�sentation der Regel

    static int anzrules = 0;

    static {
        // boolean inserted;
        GroundAtom leer;
        brelleer = new Atoms(0);
        leer = new GroundAtom(0);
        leer = brelleer.Insert(leer);
    }

    public Rule(Head h[], Body b[]) {
        int i, j, p, q, k, m;
        Body bd;
        // Head hd;
        Variable v;

        anzrules++;
        no = anzrules;

        if (h != null)
            anzheads = h.length;
        else
            anzheads = 0;
        if (b != null)
            anzbodies = b.length;
        else
            anzbodies = 0;

        anzvars = 0;
        bodies = b;
        heads = h;
        // Bestimmen des maximalen Variablensymbols
        for (i = 0; i < anzbodies; i++) {
            if (b[i].maxvarsym >= anzvars)
                anzvars = b[i].maxvarsym + 1;
            if (!b[i].neg)
                anzpos++;
        }
        for (i = 0; i < anzheads; i++)
            if (h[i].maxvarsym >= anzvars)
                anzvars = h[i].maxvarsym + 1;
        facts = false; // Angabe ob Regel nur fuer Fakten eingefuegt
        stratum = 0; // Stratum der Regel

        // Initialisierung der Rumpfatome
        for (i = 0; i < anzbodies; i++) {
            bd = bodies[i];
            bd.dindex = new int[bd.anzvars];
            bd.bindex = new int[anzvars + 1];
            if (i > 0)
                bodies[i - 1].index2 = new int[bd.anzvars + 1];
            bd.rule = this;
            for (j = 0; j < anzvars + 1; j++) {
                bd.bindex[j] = -1;
                // bd.hindex[j] = -1;
            }
            for (v = bd.variables, j = 0; v != null; v = v.next, j++) {
                bd.dindex[j] = -1;
                // bd.sdindex[j] = -1;
            }
            bd.termsets = new TermSet[anzvars];
            bd.btermsets = new TermSet[anzvars];
            bd.changets = new boolean[anzvars];
            bd.changebts = new boolean[anzvars];
        }
        q = 0;
        if (anzbodies > 0) {
            // brelation, bindex und dindex f�r 1. Rumpfatom
            for (q = 0; bodies[0].vars2[q] != -1; q++) {
                bodies[0].bindex[bodies[0].vars2[q]] = q;
                bodies[0].dindex[q] = q;
            }
            bodies[0].brelation = bodies[0].up;
        }

        // rule-Verweis f�r Kopfatome
        for (i = 0; i < anzheads; i++) {
            heads[i].rule = this;
        }

        // bindex, index1, index2, brelation f�r andere Rumpfatome
        for (i = 1; i < anzbodies; i++) {
            for (j = 0; j < anzvars; j++) {
                bodies[i].bindex[j] = bodies[i - 1].bindex[j];
            }
            p = 0;
            m = 0;
            k = 0;
            for (j = 0; bodies[i].vars2[j] != -1; j++) {
                if (bodies[i - 1].bindex[bodies[i].vars2[j]] != -1) {
                    bodies[i].index1[p] = j;
                    bodies[i - 1].index2[p] = bodies[i - 1].bindex[bodies[i].vars2[j]];
                    p++;
                }
                else {
                    if (!bodies[i].neg) {
                        bodies[i].dindex[j] = q;
                        bodies[i].bindex[bodies[i].vars2[j]] = q;
                        q++;
                    }
                }
            }
            bodies[i - 1].index2[p] = -1;
            bodies[i].index1[p] = -1;
            bodies[i].brelation = new Atoms(q);
        }
        if (anzbodies > 0) {
            // brelation und bindex der Regel entspricht der brelation des
            // letzten Rumpfatoms
            brelation = bodies[i - 1].brelation;
            bindex = bodies[i - 1].bindex;
        }

        // Initialisierungen fuer das dynamische Filtern
        for (i = 0; i < anzbodies; i++) {
            bodies[i].hrelation = new Atoms(anzvars); // Atome, die nach unten
            // propagiert werden
            bodies[i].addhrel = new Atoms(anzvars); // Atome, die nach unten
            // propagiert werden
        }
        hrelation = new Atoms(anzvars); // Ergebnisse der Evaluierung der
        // Rumpfatome
        addhrel = new Atoms(anzvars); // Zwischenergebnisse der Evaluierung
        // der Rumpfatome
        drelation = new Atoms(anzvars); // auf die Rumpfatome zu verteilende
        // Atome
        if (anzpos > 0) {
            btermsets = bodies[anzpos - 1].btermsets;
            changebts = bodies[anzpos - 1].changebts;
        }
        else {
            btermsets = new TermSet[anzvars];
            changebts = new boolean[anzvars];
        }

    }

    public void ClearRule() {
        // L�schen aller Evaluierungszwischenergebnisse
        int i;
        for (i = 0; i < anzheads; i++)
            heads[i].ClearRuleAtom();
        for (i = 0; i < anzbodies; i++)
            bodies[i].ClearRuleAtom();
        drelation = new Atoms(drelation.stellen);
        hrelation = new Atoms(hrelation.stellen);
        addhrel = new Atoms(addhrel.stellen);
        if (brelation != null)
            brelation = new Atoms(brelation.stellen);
    }

    public void ClearRule1() {
        // L�schen aller Evaluierungszwischenergebnisse
        int i;
        for (i = 0; i < anzheads; i++)
            heads[i].ClearRuleAtom();
        for (i = 0; i < anzbodies; i++)
            bodies[i].ClearRuleAtom1();
        hrelation = new Atoms(hrelation.stellen);
        addhrel = new Atoms(addhrel.stellen);
        if (brelation != null)
            brelation = new Atoms(brelation.stellen);
    }

    private boolean distribute(Atoms R) {
        // Verteilung der Atome in R auf die Rumpfatome
        int i, j;
        int b = -1; // betrachtetes Rumpfatom
        double anz, anz1;
        int ground;
        long lastvars = -1; // Anzahl uebereinstimmend belegter Terme bei der
        // letzten Auswahl
        long lastmarks = -1;
        // boolean inserted;
        boolean change = false;
        Atom t;
        // Verteilen auf Rumpfatome
        if (R.anztuples > 0) {
            R.enum1.R1 = R;
            for (t = (Atom) R.enum1.Enum(); t != null; t = (Atom) R.enum1
                    .EnumNext()) {
                // Auswahl des positiven Rumpfatoms
                if ((t.vars != lastvars) || (t.mark != lastmarks)) {
                    b = -1;
                    anz = -1;
                    for (i = 0; i < anzpos; i++) {
                        if (!(t.isMarked(i))) {
                            if (bodies[i].anzvars > 0) {
                                ground = 0;
                                for (j = 0; bodies[i].vars2[j] != -1; j++) {
                                    if (t.terms[bodies[i].vars2[j]].ground)
                                        ground++;
                                }
                                // Verh�ltnis von instantiierten Variablen zu
                                // nicht-instantiierten
                                anz1 = (double) ground
                                        / (double) bodies[i].anzvars;
                            }
                            else
                                anz1 = 0;
                            if (anz1 > anz) {
                                if (bodies[i].builtin) {
                                    if (((BuiltinBody) bodies[i]).Evaluable(t)) {
                                        anz = anz1;
                                        b = i;
                                    }
                                }
                                else {
                                    anz = anz1;
                                    b = i;
                                }
                            }
                        }
                    }
                    if (b == -1) { // negative Rumpfatome
                        for (i = anzpos; (i < anzbodies) && t.isMarked(i); i++)
                            ;
                        if (i < anzbodies)
                            b = i;
                    }
                }
                lastvars = t.vars;
                lastmarks = t.mark;
                if (b == -1) {
                    // alle Rumpfatome fuer das Atom abgearbeitet
                    // Einf�gen des Atoms in Ergebnisse
                    // inserted = hrelation.Insert(t);
                    if (t == hrelation.Insert(t)) {
                        t = (Atom) addhrel.Insert(t);
                    }
                }
                else {
                    // Downpropagierung ueber das Rumpfatom b
                    down(t, b);
                    change = true;
                }
            }
        }
        return change;
    }

    private boolean distributeWF(Atoms R) {
        // Verteilung der Atome in R auf die Rumpfatome
        int i, j;
        int b = -1; // betrachtetes Rumpfatom
        double anz, anz1;
        int oldanz, ground;
        long lastvars = -1; // Anzahl uebereinstimmend belegter Terme bei der
        // letzten Auswahl
        long lastmarks = -1;
        boolean change = false;
        Atom t;
        int builtinnotevaluated = -1;

        // Verteilen auf Rumpfatome
        if (R.anztuples > 0) {
            R.enum1.R1 = R;
            for (t = (Atom) R.enum1.Enum(); t != null; t = (Atom) R.enum1
                    .EnumNext()) {
                // Auswahl des positiven Rumpfatoms
                if ((t.vars != lastvars) || (t.mark != lastmarks)) {
                    b = -1;
                    anz = -1;
                    builtinnotevaluated = -1;
                    for (i = 0; i < anzpos; i++) {
                        if (!(t.isMarked(i))) {
                            if (bodies[i].anzvars > 0) {
                                ground = 0;
                                for (j = 0; bodies[i].vars2[j] != -1; j++) {
                                    if (t.terms[bodies[i].vars2[j]].ground)
                                        ground++;
                                }
                                // Verh�ltnis von instantiierten Variablen zu
                                // nicht-instantiierten
                                anz1 = ((double) ground / (double) bodies[i].anzvars);
                            }
                            else
                                anz1 = 1.0;
                            if (anz1 > anz) {
                                if (bodies[i] instanceof BuiltinBody) {
                                    if (((BuiltinBody) bodies[i]).Evaluable(t)) {
                                        anz = anz1;
                                        b = i;
                                    }
                                    else
                                        builtinnotevaluated = i;
                                }
                                else {
                                    anz = anz1;
                                    b = i;
                                }
                            }
                        }
                    }
                }
                lastvars = t.vars;
                lastmarks = t.mark;
                if (b == -1) {
                    if (builtinnotevaluated == -1) {
                        // alle positiven Rumpfatome fuer das Atom abgearbeitet
                        // Einf�gen des Atoms in Ergebnisse und bei den neg.
                        // Rumpftermen
                        // inserted = hrelation.Insert(t);
                        /*
                         * if (this.builtin) { System.out.print("Builtinregel:
                         * "); t.print(System.out); System.out.println(); }
                         */
                        if (t == hrelation.Insert(t)) {
                            t = (Atom) addhrel.Insert(t);
                        }
                        for (j = anzpos; j < anzbodies; j++) {
                            down(t, j);
                            change = true;
                        }
                    }
                    else {
                        if (!bodies[builtinnotevaluated].builtin) {
                            down(t, builtinnotevaluated);
                            change = true;
                        }
                    }
                }
                else {
                    // Downpropagierung ueber das Rumpfatom b
                    down(t, b);
                    change = true;
                }
            }
        }
        return change;
    }

    private void down(Atom t, int b) {
        Variable v;
        Atom f;
        Atom ins;
        int i;
        // boolean inserted;
        // Verteilen des Atoms auf das Rumpfatom b
        ins = (Atom) bodies[b].hrelation.Insert(t);
        if (t == ins) {
            ins = (Atom) bodies[b].addhrel.Insert(t);
            t.Mark(b); // Markieren, dass dieses Rumpfatom bearbeitet
            // Substitutieren der Variablen des Rumpfatoms
            for (v = bodies[b].variables; v != null; v = v.next)
                v.subsby = t.terms[v.symbol];
            f = new Atom(bodies[b].terms.length);
            for (i = 0; i < bodies[b].terms.length; i++) {
                f.terms[i] = bodies[b].terms[i].Substitute();
            }
            f.Variables();
            /* if (bodies[b].builtin instanceof BuiltinBody) */

            if (bodies[b].builtin) {
                // t.Supports(f);
                // this.print(System.out);
            }
            // Einfuegen in die Relation down und adddown des Rumpfatoms
            if (f == bodies[b].down.Insert(f)) {
                f = (Atom) bodies[b].adddown.Insert(f);
                if (bodies[b].neg && !bodies[b].builtin)
                    bodies[b].delayed = true;
            }
            bodies[b].ClearVariables();
            waitingtuples++;
        }
        else {
            ins.mark |= t.mark;
        }
    }

    public boolean DynamicFiltering() {
        // Dynamisches Filtern mit Sidewayspropagierung
        boolean stop = false, change = false;
        int i, j;
        // System.out.print("Eval Rule: "); System.out.println(this.no);
        // Einbringen der Konstanten der Kopfatome
        for (i = 0; i < anzheads; i++) {
            if (heads[i].adddown.anztuples > 0) {
                drelation.Extend(heads[i].adddown, heads[i].vars2);
                heads[i].adddown = new Atoms(heads[i].adddown.stellen);
            }
        }

        // Verteilen der Atome auf die Ruempfe
        if (drelation.anztuples > 0) {
            change = distribute(drelation);
            drelation = new Atoms(drelation.stellen);
        }

        // Weiterverteilen der nach oben gekommenen Rumpfatome, Auswertung von
        // Builtin-Atomen
        for (j = 0; j < anzbodies; j++) {
            if ((bodies[j].adddown.anztuples > 0) && (bodies[j].builtin)) {
                // Auswertung von Builtin-Atomen
                ((BuiltinBody) bodies[j]).Eval();
            }
            if (!bodies[j].neg) { // positives Rumpfatom
                if (bodies[j].addup.anztuples > 0) {
                    drelation.MatchJoin(bodies[j].hrelation, bodies[j].vars2,
                            bodies[j].addup, bodies[j].addup.matchindex,
                            bodies[j].vars2);
                    if (drelation.anztuples > 0) {
                        change = distribute(drelation) | change;
                        drelation = new Atoms(drelation.stellen);
                    }
                    bodies[j].addup = new Atoms(bodies[j].addup.stellen);
                }
                if (bodies[j].addhrel.anztuples > 0) {
                    drelation.MatchJoin(bodies[j].addhrel, bodies[j].vars2,
                            bodies[j].up, bodies[j].up.matchindex,
                            bodies[j].vars2);
                    if (drelation.anztuples > 0) {
                        change = distribute(drelation) | change;
                        drelation = new Atoms(drelation.stellen);
                    }
                    bodies[j].addhrel = new Atoms(bodies[j].addhrel.stellen);
                }

            }
            else { // negatives Rumpfatom
                if (bodies[j].up.anztuples > 0) {
                    // if (bodies[j].addup.anztuples > 0) {
                    // bodies[j].negrelation.MatchJoin(bodies[j].hrelation,bodies[j].vars2,
                    // bodies[j].addup,bodies[j].addup.matchindex,bodies[j].vars2);
                    // bodies[j].negrelation.MatchJoin(bodies[j].hrelation,bodies[j].vars2,
                    // bodies[j].up,bodies[j].up.matchindex,bodies[j].vars2);
                    // bodies[j].hrelation.Negation1(bodies[j].vars2,bodies[j].negrelation,bodies[j].vars2);
                    bodies[j].hrelation.Negation1(bodies[j].vars2,
                            bodies[j].up, bodies[j].up.matchindex);
                    // bodies[j].hrelation.Negation1(bodies[j].vars2,bodies[j].addup,bodies[j].addup.matchindex);
                    bodies[j].addup = new Atoms(bodies[j].addup.stellen);
                    bodies[j].addhrel = new Atoms(bodies[j].addhrel.stellen);
                }
                if ((!bodies[j].delayed) && (bodies[j].hrelation.anztuples > 0)) {
                    distribute(bodies[j].hrelation);
                    bodies[j].hrelation = new Atoms(bodies[j].hrelation.stellen);
                }
            }
        }

        // Einsetzen der Ergebnisrelation in Kopfatome
        if (addhrel.anztuples > 0) {
            for (i = 0; i < anzheads; i++) {
                heads[i].up.Substitute(heads[i], addhrel, addhrel.matchindex);
                heads[i].addup.UnionSelected(heads[i].up);
                // change = (heads[i].addup.anztuples > 0) || change;
            }
            if (heads != null)
                addhrel = new Atoms(addhrel.stellen);
        }
        return change;
    }

    public boolean DynamicFilteringWF() {
        // Dynamisches Filtern mit Sidewayspropagierung
        boolean stop = false, change = false;
        int i, j;
        java.util.Enumeration enm;
        GroundAtom t;

        // System.out.print("Regel: "); this.print(System.out);
        // System.out.println();
        // System.out.println("hrelation davor:");
        // hrelation.print();
        // if ((no == 4) || (no == 5)) hrelation.checkpaths();
        if (debuglevel >= 1) {
            System.out.print("Regel: ");
            System.out.println(this.toString());
        }

        // Einbringen der Konstanten der Kopfatome
        for (i = 0; i < anzheads; i++) {
            if (heads[i].adddown.anztuples > 0) {
                drelation.Extend(heads[i].adddown, heads[i].vars2);
                heads[i].adddown = new Atoms(heads[i].adddown.stellen);
            }
        }

        // Verteilen der Atome auf die Ruempfe

        if (drelation.anztuples > 0) {
            if (debuglevel >= 3) {
                System.out.println("Input: ");
                drelation.print(System.out);
                System.out.println();
            }

            change = distributeWF(drelation);
            drelation = new Atoms(drelation.stellen);
        }

        // Weiterverteilen der nach oben gekommenen Rumpfatome, Auswertung von
        // Builtin-Atomen
        for (j = 0; j < anzbodies; j++) {
            if ((bodies[j].adddown.anztuples > 0) && (bodies[j].builtin)) {
                // Auswertung von Builtin-Atomen
                // System.out.print("Builtin: ");
                // System.out.println(bodies[j].symbol);
                ((BuiltinBody) bodies[j]).Eval();
                // bodies[j].addup.print(System.out);
            }
            if (!bodies[j].neg) { // positives Rumpfatom
                if (bodies[j].addup.anztuples > 0) {
                    drelation.MatchJoin(bodies[j].hrelation, bodies[j].vars2,
                            bodies[j].addup, bodies[j].addup.matchindex,
                            bodies[j].vars2);
                    if (drelation.anztuples > 0) {
                        change = distributeWF(drelation) | change;
                        drelation = new Atoms(drelation.stellen);
                    }
                    bodies[j].addup = new Atoms(bodies[j].addup.stellen);
                }
                if (bodies[j].addhrel.anztuples > 0) {
                    drelation.MatchJoin(bodies[j].addhrel, bodies[j].vars2,
                            bodies[j].up, bodies[j].up.matchindex,
                            bodies[j].vars2);
                    if (drelation.anztuples > 0) {
                        change = distributeWF(drelation) | change;
                        drelation = new Atoms(drelation.stellen);
                    }
                    waitingtuples -= bodies[j].addhrel.anztuples;
                    bodies[j].addhrel = new Atoms(bodies[j].addhrel.stellen);
                }

            }
            else { // negatives Rumpfatom
                if (bodies[j].addup.anztuples > 0) {
                    bodies[j].hrelation.Negation2(bodies[j].vars2,
                            bodies[j].addup, bodies[j].addup.matchindex);
                    bodies[j].addup = new Atoms(bodies[j].addup.stellen);
                }
                if (bodies[j].addhrel.anztuples > 0) {
                    bodies[j].addhrel.Negation2(bodies[j].vars2, bodies[j].up,
                            bodies[j].up.matchindex);
                    waitingtuples -= bodies[j].addhrel.anztuples;
                    bodies[j].addhrel = new Atoms(bodies[j].addhrel.stellen);
                }
            }
        }

        // Einsetzen der Ergebnisrelation in Kopfatome
        if (addhrel.anztuples > 0) {
            for (i = 0; i < anzheads; i++) {
                heads[i].up.Substitute(heads[i], addhrel, addhrel.matchindex);
                heads[i].addup.UnionSelected(heads[i].up);
                // change = (heads[i].addup.anztuples > 0) || change;
                // heads[i].addup.print(); System.out.println();
                if (anzpos < anzbodies) {
                    enm = heads[i].addup.elements();
                    while (enm.hasMoreElements()) {
                        t = (GroundAtom) enm.nextElement();
                        t.sure = false;
                    }
                }
            }
            if (heads != null)
                addhrel = new Atoms(addhrel.stellen);
        }
        if (debuglevel >= 2) {
            System.out.println("Regelergebnis: ");
            addhrel.print(System.out);
            System.out.println();
        }
        return change;
    }

    /*
     * private boolean distributeWF(Atoms R) { // Verteilung der Atome in R auf
     * die Rumpfatome int i,j; int b = -1; // betrachtetes Rumpfatom double anz,
     * anz1; int oldanz,ground; long lastvars = -1; // Anzahl uebereinstimmend
     * belegter Terme bei der letzten Auswahl long lastmarks = -1; boolean
     * repeat = false; Atom t; // Verteilen auf Rumpfatome if (R.anztuples > 0) {
     * R.enum1.R1 = R; for (t = (Atom)R.enum1.Enum(); t != null; t =
     * (Atom)R.enum1.EnumNext()) { // Auswahl des positiven Rumpfatoms if
     * ((t.vars != lastvars) || (t.mark != lastmarks)) { b = -1; anz = -1; for(i =
     * 0; i < anzpos; i++) { if (!(t.isMarked(i))) { if (bodies[i].anzvars > 0) {
     * ground = 0; for(j = 0; bodies[i].vars2[j] != -1; j++) { if
     * (t.terms[bodies[i].vars2[j]].ground) ground++; } // Verh�ltnis von
     * instantiierten Variablen zu nicht-instantiierten anz1 =
     * (double)ground/(double)bodies[i].anzvars; } else anz1 = 0; if (anz1 >
     * anz) { if (bodies[i].builtin) { if
     * (((BuiltinBody)bodies[i]).Evaluable(t)) { anz = anz1; b = i; } } else {
     * anz = anz1; b = i; } } } } } lastvars = t.vars; lastmarks = t.mark; if (b ==
     * -1) { // alle positiven Rumpfatome fuer das Atom abgearbeitet // Einf�gen
     * des Atoms in Ergebnisse und bei den neg. Rumpftermen // inserted =
     * hrelation.Insert(t); if (t == hrelation.Insert(t)) { t =
     * (Atom)addhrel.Insert(t); } for (j = anzpos; j < anzbodies; j++)
     * down(t,j); } else { // Downpropagierung ueber das Rumpfatom b down(t,b);
     * if (bodies[b].builtin) repeat = true; } } } return repeat; }
     */

    private boolean inheads(int sym) {
        for (int i = 0; i < anzheads; i++)
            if (heads[i].symbol == sym)
                return true;
        return false;
    }

    public void internalize(PrintStream p) {
        Integer Anzheads = new Integer(anzheads);
        Integer Anzbodies = new Integer(anzbodies);
        int i;
        p.print("l" + Anzheads.toString() + "l" + Anzbodies.toString());

        for (i = 0; i < anzheads; i++) {
            heads[i].internalize(p);
        }
        for (i = 0; i < anzbodies; i++) {
            bodies[i].internalize(p);
        }
    }

    public static void main(String args[]) {
    }

    public boolean NaiveEval() {
        // Auswertung der Regel durch naive Evaluierung
        int i; // oldnum;
        boolean change = false;
        if (anzbodies > 0) {
            // Verkn�pfung der Rumpfrelationen
            if (bodies[0].builtin)
                change = bodies[0].NaiveRight(brelleer, bindex0) || change;
            for (i = 1; i < anzbodies; i++) {
                change = bodies[i].NaiveRight(bodies[i - 1].brelation,
                        bodies[i - 1].index2)
                        || change;
            }
            // Einsetzen in Kopfatome
            for (i = 0; i < anzheads; i++) {
                change = heads[i].Up(bodies[anzbodies - 1].brelation,
                        bodies[anzbodies - 1].bindex)
                        || change;
                // change = heads[i].Up(brelation,bindex) || change;
            }
        }
        return change;
    }

    private boolean occursfree(Body b, int varsym) {
        for (int i = 0; i < b.terms.length; i++)
            if ((b.terms[i] instanceof Variable)
                    && (((Variable) b.terms[i]).symbol == varsym))
                return true;
        return false;
    }

    public void printneg(PrintStream p) {
        int i;
        boolean switched = false;
        for (i = 0; i < anzbodies; i++)
            if (bodies[i].neg) {
                bodies[i].print(p);
                p.println("up");
                bodies[i].up.print(p);
                p.println("up1");
                bodies[i].up1.print(p);
                p.println("up2");
                bodies[i].up2.print(p);
            }
    }

    public boolean Switch() {
        // schaltet die negativen Rumpfliterale bei alternierendem Fixpunkt um
        int i;
        boolean switched = false;
        for (i = 0; i < anzbodies; i++)
            switched = bodies[i].Switch() || switched;
        return switched;
    }

    public boolean TermEval() {
        // Berechnung der an den einzelnen Stellen m�glichen Terme
        int i, j, k, oldanz;
        boolean change = false;
        boolean notpropable = false;
        int occurslast[] = new int[this.btermsets.length];
        for (i = 0; i < occurslast.length; i++) {
            occurslast[i] = -1;
        }

        if ((anzbodies > 0) && !facts && !external && !builtin) {
            // Verkn�pfung der Rumpfrelationen
            for (i = 0; i < anzpos; i++) {
                for (j = 0; j < bodies[i].terms.length; j++) {
                    if (bodies[i].terms[j] instanceof Variable) {
                        k = ((Variable) bodies[i].terms[j]).symbol;
                        if (occurslast[k] == -1) {
                            occurslast[k] = i;
                            if (bodies[i].termsets[k] != null) {
                                if (bodies[i].btermsets[k] == null)
                                    bodies[i].btermsets[k] = new TermSet();
                                oldanz = bodies[i].btermsets[k].anzterms;
                                bodies[i].btermsets[k]
                                        .Union(bodies[i].termsets[k]);
                                change = (oldanz != bodies[i].btermsets[k].anzterms)
                                        || change;
                            }
                        }
                        else if (i > occurslast[k]) {
                            occurslast[k] = i;
                            if ((bodies[i].termsets[k] != null)
                                    && (bodies[i - 1].btermsets[k] != null)) {
                                if (bodies[i].btermsets[k] == null)
                                    bodies[i].btermsets[k] = new TermSet();
                                oldanz = bodies[i].btermsets[k].anzterms;
                                bodies[i].btermsets[k].Intersect(
                                        bodies[i - 1].btermsets[k],
                                        bodies[i].termsets[k]);
                                change = (oldanz != bodies[i].btermsets[k].anzterms)
                                        || change;
                            }
                        }

                    }
                }
                for (j = 0; j < bodies[i].btermsets.length; j++) {
                    if ((occurslast[j] != -1) && (occurslast[j] < i))
                        bodies[i].btermsets[j] = bodies[occurslast[j]].btermsets[j];
                }
            }
        }
        return change;
    }

    public String toString() {
        int i;
        String s;
        if (ruletext == null) {
            s = Integer.toString(no) + ": ";
            for (i = 0; i < anzheads; i++) {
                s += heads[i].toString();
                if (i < anzheads - 1)
                    s += " & ";
            }
            s += " <- ";
            for (i = 0; i < anzbodies; i++) {
                s += bodies[i].toString();
                if (i < anzbodies - 1)
                    s += " & ";
            }
            s += ".";
            if (builtin)
                s += " (builtin rule)";
            if (facts)
                s += " (facts rule)";
        }
        else
            s = ruletext;
        return s;
    }
}
