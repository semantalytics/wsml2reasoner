/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: IndexInterface.java

 Version: 1.0

 Purpose: Interface for an index datastructure

 History:

 */

public interface IndexInterface {

    /**
     * Delete the element identical (not only equal in the sense of Compare) to
     * ele To delete an arbitrary element this element has to be searched by
     * Search before
     */
    public void Delete(Object ele);

    /** Returns an enumeration for the elements */
    public IndexEnumeration elements();

    /**
     * Insert a new element. Returns ele if ele has been inserted. Returns the
     * element equal to ele, if ele has not been inserted
     */
    public Object Insert(Object ele);

    /** Returns the number of elements stored in the index */
    public int NoElements();

    /** Searches for an element equal (in the sense of Compare) to ele */
    public Object Search(Object ele);
}
