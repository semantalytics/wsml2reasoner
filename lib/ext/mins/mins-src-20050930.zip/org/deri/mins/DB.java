/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: DB.java

 Version: 1.0

 Purpose: stores all facts

 History:

 */

import java.io.*;

import org.deri.mins.api.DBInterface;
import org.deri.mins.terms.TermSet;

// import com.ontoprise.parser.SParseError;
// import com.ontoprise.parser.SParser;

public class DB implements DBInterface {
    Atoms facts[] = null; // Feld von Faktenmengen der Regelmenge

    int increment = 200; // dynamische Erweiterung der Felder facts um incr

    int maxpreds = 0; // gr�sstes bisher aufgetretenes Pr�dikatsymbol

    public DB() {
        // Konstruktor
        maxpreds = increment - 1;
        facts = new Atoms[increment];
    }

    public void addFact(int sym, GroundAtom fact) {
        // F�gt ein einzelnes Faktum hinzu

        // boolean inserted;
        // int i;
        // if (sym == 6) {fact.print(System.out); System.out.println();}
        // falls noetig RuleSet erweitern
        checksym(sym);
        if (facts[sym] == null) {
            // noch kein Faktum dieses Pr�dikatsymbols vorhanden
            // Erzeugen einer neuen Faktenmenge dieses Symbols
            facts[sym] = new Atoms(fact.terms.length);
            // System.out.print(sym); System.out.print(":");
            // System.out.println(fact.terms.length);
        }
        // Einf�gen des Faktums in die Faktenmenge
        fact = facts[sym].Insert(fact);
    }

    private void checksym(int sym) {
        // neues Pr�dikatsymbol
        // falls noetig RuleSet erweitern
        if (sym > maxpreds)
            extend(sym);
    }

    public void deleteFact(int sym, GroundAtom fact) {
        // L�scht ein Faktum
        GroundAtom a;
        if (facts[sym] != null) {
            a = facts[sym].Search(fact);
            if (a != null) {
                // System.out.println("found");
                facts[sym].Delete(a);
            }
        }
    }

    public int evalRule(Rule r) {
        return 0;
    }

    private void extend(int index) {
        // erweitert das Feld facts so dass sie auch den Index 'index' enthalten
        int len, i;
        Atoms newfacts[];
        len = maxpreds + 1;
        if (maxpreds < index) {
            while (len < index + 1)
                len += increment;
            newfacts = new Atoms[len];
            for (i = 0; i <= maxpreds; i++) {
                newfacts[i] = facts[i];
            }
            facts = newfacts;
        }
        maxpreds = len - 1;
    }

    public Atoms getFacts(int praedikatsymbol, Atoms filterterme) {
        /*
         * Das ist die wesentliche Funktion zum Zugriff auf Fakten. Es werden
         * auf Fakten mit dem Pr�dikatsymbol praedikatsymbol zugegriffen. Der
         * Zugriff wird mit Hilfe einer Menge von Filtertermen filterterme
         * eingeschr�nkt. Ein Filterterm ist ein Tupel von Termen, die Variablen
         * enthalten k�nnen. Z.B. ist f(X,a),"hallo",X ein solcher Filterterm.
         * Das Ergebnis des Aufrufs ist eine Menge von Fakten, die zu diesen
         * Filtertermen "passen" (die mit einem der Filterterme matchen). Z.B.
         * enthalte die entsprechende Tabelle der DB die Zeilen: 5, "hallo",8
         * f(7,a), "hallo",7 f(ab,a), "hallo",ab f(7,a), "hallo",h f(ab,a),
         * "huhu",ab Die filterterme bestehen nur aus dem einen Filterterm:
         * f(X,a),"hallo",X. Dann ist das Ergebnis des Aufrufs die folgende
         * Menge von Fakten: f(7,a), "hallo",7 f(ab,a), "hallo",ab
         */

        /*
         * System.out.println("Filterterme:"); filterterme.print(System.out);
         * System.out.println("-------------------------------------");
         */

        Atoms res = null;
        if (filterterme == null) {
            res = facts[praedikatsymbol];
            System.out.println("DB: 1");
        }
        else if (facts[praedikatsymbol] != null) {
            /*
             * System.out.println("verf�gbar:");
             * facts[praedikatsymbol].print(System.out);
             * System.out.println("-------------------------------------");
             */
            res = new Atoms(facts[praedikatsymbol].stellen);
            res.Filtering1(filterterme, facts[praedikatsymbol]);
        }
        /*
         * System.out.print("Pr�dikatsymbol: ");
         * System.out.println(praedikatsymbol); System.out.println("Ergebnis:");
         * if (res != null) res.print(System.out);
         * System.out.println("===============================================");
         */
        return res;
    }

    public long GetNumber(int praedikatsymbol) {
        // liefert die Anzahl der Fakten
        if (facts[praedikatsymbol] != null)
            return facts[praedikatsymbol].anztuples;
        else
            return 0;
    }

    public TermSet getTerms(int praedikatsymbol, int i) {
        /*
         * Dies wird f�r Optimierungszwecke gebraucht. Liefert die Menge von
         * Termen, die am i-ten Argument aller Fakten des Pr�dikatsymbols
         * praedikatsymbol auftreten.
         */

        TermSet terms;

        if (facts[praedikatsymbol] != null) {
            terms = new TermSet();
            facts[praedikatsymbol].Terms(terms, i);
            // terms.print(System.out);
            return terms;
        }
        else
            return new TermSet();
    }

    public boolean isEvaluable(Rule r) {
        return false;
    }

    public void read(RandomAccessFile file) throws IOException {
        throw new UnsupportedOperationException("Due to Refactoring!");
        // String s = "";
        // SParser spars;
        //
        // spars = new SParser(null);
        // while ((s = file.readLine()) != null) {
        // try {
        // spars.decode(null, this, s + "\n");
        // } catch (SParseError p) {
        // System.out.println(p.getMessage());
        // }
        //
        // }
    }

    public void write(PrintStream p) throws IOException {
        /*
         * Schreibt die Faktenmenge im internen Format auf p heraus
         */
        int i;
        for (i = 0; i < facts.length; i++) {
            if (facts[i] != null)
                facts[i].internalize(p, i);
        }
    }
}
