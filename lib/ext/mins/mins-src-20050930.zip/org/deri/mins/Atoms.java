/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: Atoms.java

 Version: 2.0

 Purpose: a container for atoms with appropriate access data structures
 (AVL trees)

 History:

 */

import java.io.PrintStream;

import org.deri.mins.operations.*;
import org.deri.mins.terms.TermSet;
import org.deri.mins.terms.Variable;
import org.deri.mins.utils.Time;
import org.deri.mins.utils.Watch;

public class Atoms {
    public static int debuglevel = 0;

    public int anztuples = 0; // number of tuples

    public int suretuples = 0; // tuples which may not become unknown

    public GroundAtom tuples2 = null;

    public GroundAtom tuples3 = null;

    public int stellen = 0;

    public IndexNode indices = null;

    // private Print print = new Print();
    // private Index indx = new Index();
    public long lasttouched = 0;

    public long lastmodified = 0;

    public long checktime = 0; // Zeit auf die sich nachfolgende Zahlen bezieht

    public int added = 0; // seit checktime neu hinzugekommen

    public int deleted = 0; // seit checktime geloescht

    public int supported = 0; // seit checktime schon enthaltene versucht

    // einzufuegen

    public boolean modified = false; // Relation seit checktime veraendert

    public float groundness[];

    public int matchindex[]; // 1:1 Abbildung der Spalten

    public Enumeration enum1 = new Enumeration();

    public Enumeration enum2 = new Enumeration();

    public static Watch Unwatch = new Watch();

    public static int nounion = 0;

    public static Watch Swatch = new Watch();

    public static Watch Dwatch = new Watch();

    public static Watch Iwatch = new Watch();

    public static Watch Twatch = new Watch();

    public static Watch Selwatch = new Watch();

    public static Watch Ewatch = new Watch();

    public static Watch Nwatch = new Watch();

    public static Watch N1watch = new Watch();

    public static Watch N2watch = new Watch();

    public static Watch MJwatch = new Watch();

    public static Watch Jwatch = new Watch();

    public static Watch Mtwatch = new Watch();

    public static Watch Subwatch = new Watch();

    public static Watch Fwatch = new Watch();

    public static Watch F1watch = new Watch();

    public static Watch Uwatch = new Watch();

    public static Watch Mwatch = new Watch();

    public static Watch Substwatch = new Watch();

    public Atoms(int stelligkeit) {
        int i;
        stellen = stelligkeit;
        matchindex = new int[stelligkeit + 1];
        for (i = 0; i < stelligkeit; i++)
            matchindex[i] = i;
        matchindex[i] = -1;
        groundness = new float[stelligkeit];
        indices = new IndexNode(matchindex, false);
    }

    public boolean Compare(Atoms R) {
        if (debuglevel > 0)
            System.out.println("-> Compare");
        // true, falls jedes Tupel in this auch in R vorkommt und umgekehrt
        GroundAtom t1, t2;
        IndexEnumeration enm1 = (IndexEnumeration) this.indices.avl.elements();
        IndexEnumeration enm2 = (IndexEnumeration) R.indices.avl.elements();
        if (this.anztuples != R.anztuples)
            return false;
        while (enm1.hasMoreElements()) {
            t1 = (GroundAtom) enm1.nextElement();
            t2 = (GroundAtom) enm2.nextElement();
            if (/* !t2.deleted && !t1.deleted && */((t2).CompareAtoms(t1) != 0))
                return false;
        }
        if (debuglevel > 0)
            System.out.println("<- Compare");
        return true;
    }

    /** all edges in ATMS which lead to atoms marked with a mark > 0 */
    public void CutATMS() {
        GroundAtom t;
        IndexEnumeration enm;
        enm = this.indices.avl.elements();
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            t.CutATMS();
        }
    }

    synchronized public void Delete(GroundAtom t) {
        if (debuglevel > 0)
            System.out.println("-> Delete");
        IndexNode l;
        long d;
        Dwatch.press();
        l = indices;
        l.avl.Delete(t);
        anztuples = l.avl.NoElements();
        while (l != null) {
            l.avl.Delete(t);
            l = l.next;
        }
        if (debuglevel > 0)
            System.out.println("<- Delete");
        Dwatch.release();
    }

    synchronized public void DeleteSelected() {
        if (debuglevel > 0)
            System.out.println("-> DeleteSelected");
        // in der Relation this werden die Tuple gel�scht, die durch next2
        // verkettet sind
        // dabei wird die Selektion zerstoert
        GroundAtom t, t1;
        t = this.tuples2;
        while (t != null) {
            t1 = t.next2;
            Delete(t);
            t = t1;
        }
        if (debuglevel > 0)
            System.out.println("<- DeleteSelected");
    }

    public java.util.Enumeration elements() {
        return new AtomsEnumeration(this);
    }

    void Eval(Atom T, Atoms R, int vars3[], BuiltinFunc f) {
        GroundAtom t;
        IndexEnumeration enm;
        f.D = this;
        f.index = vars3;
        f.T = T;
        this.tuples2 = null;
        enm = R.indices.avl.elements();
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            f.eval((Atom) t);
        }
    }

    public void Extend(Atoms R, int index[]) {
        // Fertigt zu jedem Atom A in R eine Kopie A' an. Jeder Term an der
        // Stelle i in A wird an die
        // Stelle index[i] in A' kopiert.
        GroundAtom t;
        Atom tnew;
        Atom ins;
        // int i;
        long timestamp = Time.getTime();
        boolean del;
        IndexEnumeration enm;
        Ewatch.press();
        if (debuglevel > 0) {
            System.out.println("-> Extend");
            if (debuglevel > 1) {
                System.out.println("Source: ");
                R.print(System.out);
                System.out.println();
            }
        }
        enm = R.indices.avl.elements();
        this.tuples2 = null;
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            // neues GroundAtom
            tnew = ((Atom) t).Extend(index, this.stellen);
            ins = (Atom) Insert(tnew);
            del = ins.deleted;
            (t).Supports(ins);
            if (ins == tnew) {
                tnew.next2 = tuples2;
                tuples2 = tnew;
            }
            tnew = null;
        }
        if (debuglevel > 0) {
            if (debuglevel > 1) {
                System.out.println("Destination: ");
                this.print(System.out);
                System.out.println();
            }
            System.out.println("<- Extend");
        }
        Ewatch.release();
    }

    public void Filtering(Atom A, Atoms F, Atoms R2) {
        // This enth�lt nach der Operation alle Substitutionen s2 f�r die es
        // eine Substitution
        // s1 gibt, so dass es ein a aus R2 und ein f aus F gibt mit s1(f) = a
        // und s2(A) = a
        int index1[];
        int index2[];
        Filtering filter;
        Fwatch.press();
        if (debuglevel > 0) {
            System.out.println("-> Filtering");
            if (debuglevel > 1) {
                System.out.println("Atom:");
                System.out.println(A.toString());
            }
        }
        index1 = new int[F.matchindex.length];
        index2 = new int[R2.matchindex.length];
        sortindices(F.matchindex, R2.matchindex, index1, index2, F.groundness);
        filter = new Filtering(F, index1, R2, index2, this, A, Time.getTime());
        filter.Operate();
        if (debuglevel > 0)
            System.out.println("<- Filtering");
        Fwatch.release();
    }

    public void Filtering1(Atoms F, Atoms R2) {
        // This enth�lt nach der Operation alle Substitutionen s2 f�r die es
        // eine Substitution
        // s1 gibt, so dass es ein a aus R2 und ein f aus F gibt mit s1(f) = a
        int index1[];
        int index2[];
        Filtering1 filter1;
        F1watch.press();
        if (debuglevel > 0)
            System.out.println("-> Filtering1");
        index1 = new int[F.matchindex.length];
        index2 = new int[R2.matchindex.length];
        sortindices(F.matchindex, R2.matchindex, index1, index2, F.groundness);
        filter1 = new Filtering1(F, index1, R2, index2, this, Time.getTime());
        filter1.Operate();
        if (debuglevel < 0)
            System.out.println("<- Filtering1");
        F1watch.release();
    }

    public GroundAtom First() {
        // this.print();
        GroundAtom t;
        enum1.R1 = this;
        t = enum1.Enum();
        if ((t != null) && (t.deleted))
            return Next();
        else
            return t;
    }

    /**
     * Determines from an atom of R1 and an atom of R2 a generalized atom if
     * possible
     */
    public void Generalize(Atoms R1, Atoms R2) {
        // produziert jeweils aus einem GroundAtom von R1 und einem aus R2 eine
        // Generalisierung, falls m�glich
        Generalization gen;
        if (debuglevel > 0)
            System.out.println("-> Generalize");
        gen = new Generalization(R1, R1.matchindex, R2, R2.matchindex, this,
                Time.getTime());
        gen.Operate();
        if (debuglevel > 0)
            System.out.println("<- Generalize");
    }

    public IndexNode getindex(int s[]) {
        int i = 0;
        int set = 0;
        int anz;
        IndexNode l;
        IndexNode ix = null;
        IndexEnumeration enm;
        GroundAtom t;

        for (i = 0; s[i] != -1; i++)
            set |= (1 << s[i]);
        anz = i;
        l = indices;
        while ((l != null) && (ix == null)) {
            if (set == l.stellen) {
                i = 0;
                while ((s[i] != -1) && (s[i] == l.svec[i]))
                    i++;
                if (s[i] == l.svec[i])
                    ix = l;
            }
            l = l.next;
        }
        if (ix == null) {
            ix = new IndexNode(s, true);
            enm = this.indices.avl.elements();
            while (enm.hasMoreElements()) {
                t = (GroundAtom) enm.nextElement();
                ix.avl.Insert(t);
            }
            ix.next = indices.next;
            indices.next = ix;
        }
        return ix;
    }

    /** Inserts an atom into this */
    public GroundAtom insert(GroundAtom t) {
        // gibt Tupel t zur�ck, falls Einf�gen erfolgreich
        // gibt Tupel b zur�ck, falls t nicht eingef�gt wurde, weil b bereits
        // enthalten und b = t
        GroundAtom a, b;
        IndexNode l;
        long d;

        d = Time.getTime();
        b = (GroundAtom) indices.avl.Insert(t);
        anztuples = indices.avl.NoElements();
        if (b == t) {
            lastmodified = d;
            lasttouched = d;
            added++;
            modified = true;
            t.lasttouched = d;
            l = indices.next;
            while (l != null) {
                l.avl.Insert(t);
                l = l.next;
            }
            if (t.sure)
                suretuples++;
            return t;
        }
        else {
            lasttouched = d;
            return b;
        }

    }

    synchronized public GroundAtom Insert(GroundAtom a) {
        int i;
        GroundAtom t;
        Iwatch.press();
        if (debuglevel > 2) {
            System.out.println("-> Insert");
            if (debuglevel > 2) {
                System.out.println("Atom:");
                System.out.println(a.toString());
                System.out.println("Source:");
                this.print(System.out);
                System.out.println();
            }
        }
        t = insert(a);
        if (a == t) {
            for (i = 0; i < stellen; i++) {
                if ((a).terms[i].groundlevel == -1)
                    groundness[i] += 1.0;
                else
                    groundness[i] += (float) (1.0 - (1.0 / (float) (a).terms[i].groundlevel));
            }
        }
        if (debuglevel > 2) {
            if (debuglevel > 2) {
                System.out.println("Destination:");
                this.print(System.out);
                System.out.println();
            }
            System.out.println("<- Insert");
        }
        Iwatch.release();
        return t;
    }

    public void internalize(PrintStream p, int sym) {
        GroundAtom t;
        IndexEnumeration enm = (IndexEnumeration) this.indices.avl.elements();
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            t.internalize(p, sym);
            // t.write(f,sym);
            p.println();
        }
    }

    public void Join(Atoms R1, int index1[], Atoms R2, int index2[],
            int dix1[], int dix2[]) {
        // index1 = i1,..,in; index2 = j1,..,jn; dix1 = d1,..,dk; dix2 =
        // e1,..,ep
        // f�r Tupelpaare {<x1,..,xr>,<y1,..,ys> | <x1,..,xr> aus R1, <y1,..,ys>
        // aus R2 mit
        // xi1 = yj1 & .. & xin = yin}
        // entsteht ein Tupel <z1,..,zt> in this mit
        // zdi = xi, falls di != -1 und
        // zei = yi, falls ei != -1
        GroundAtom t1, t2;
        Join join;
        IndexEnumeration enm1, enm2;
        Jwatch.press();
        if (debuglevel > 0)
            System.out.println("-> Join");
        join = new Join(R1, index1, R2, index2, this, dix1, dix2, Time
                .getTime());
        if (index1[0] != -1) {
            join.Operate();
        }
        else {
            // keine gemeinsamen Variablen, Bildung des Kreuzprodukts
            enm1 = R1.indices.avl.elements();
            while (enm1.hasMoreElements()) {
                t1 = (GroundAtom) enm1.nextElement();
                enm2 = R2.indices.avl.elements();
                while (enm2.hasMoreElements()) {
                    t2 = (GroundAtom) enm2.nextElement();
                    join.op(t1, t2);
                }
            }
        }
        MJwatch.release();
        if (debuglevel > 0)
            System.out.println("<- Join");
    }

    /** Mark all atoms with mark m */
    public void Mark(int m) {
        GroundAtom t;
        IndexEnumeration enm;
        enm = this.indices.avl.elements();
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            t.mark = m;
        }
    }

    public void Match(Atom T, Atoms R1) {
        // this enth�lt danach alle Substitutionen s
        // mit s(T) = a, wobei a aus R1 ist
        Match match;
        Mwatch.press();
        if (debuglevel > 0)
            System.out.println("-> Match");
        match = new Match(R1, T, this, Time.getTime());
        match.Operate();
        if (debuglevel > 0)
            System.out.println("<- Match");
        Mwatch.release();
    }

    /**
     * Produces all variable substitutions for unifications of a ground atom
     * from R1 with an atom of R2 and stores them in this
     */
    public void Matching(Atoms R1, Atoms R2) {
        // produziert jede Variablensubstitution, die daraus entsteht, dass ein
        // GroundAtom
        // aus R1 mit einem GroundAtom aus R2 matcht
        if (debuglevel > 0)
            System.out.println("-> Matching");
        Matching matching;
        Mtwatch.press();
        matching = new Matching(R1, R1.matchindex, R2, R2.matchindex, this,
                Time.getTime());
        matching.Operate();
        if (debuglevel > 0)
            System.out.println("<- Matching");
        Mtwatch.release();
    }

    public void MatchJoin(Atoms hrel, int sindex1[], Atoms up, int sindex2[],
            int dindex[]) {
        int index1[];
        int index2[];
        MatchJoin matchjoin;
        MJwatch.press();
        if (debuglevel > 0)
            System.out.println("-> MatchJoin");
        if ((hrel.anztuples > 0) && (up.anztuples > 0)) {
            index1 = new int[sindex1.length];
            index2 = new int[sindex2.length];
            sortindices(sindex1, sindex2, index1, index2, hrel.groundness);
            matchjoin = new MatchJoin(hrel, index1, up, index2, this, dindex,
                    Time.getTime());
            matchjoin.Operate();
        }
        MJwatch.release();
        if (debuglevel > 0)
            System.out.println("<- MatchJoin");
    }

    public void Negation(Atoms R1, int index1[], Atoms R2, int index2[]) {
        // index1 = i1,..,ik, index2 = j1,..,jk
        // this enth�lt nach der Operation alle Tupel <x1,..,xn> aus R1 fuer die
        // es kein
        // Tupel <y1,..,ym> aus R2 gibt, mit xi1 = yj1 & xi2 = yi2 & .. & xik =
        // yik
        GroundAtom t, ins;
        IndexEnumeration enm;
        Mwatch.press();
        if (debuglevel > 0)
            System.out.println("-> Negation");
        Negation neg = new Negation(R1, index1, R2, index2, Time.getTime());
        neg.Operate();
        enm = R1.indices.avl.elements();
        // Kopiere alle nicht betroffenen GroundAtome
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            if (t.lasttouched < neg.timestamp)
                ins = Insert(t);
        }
        Nwatch.release();
        if (debuglevel > 0)
            System.out.println("<- Negation");
    }

    public void Negation1(int index1[], Atoms R2, int index2[]) {
        // index1 = i1,..,ik, index2 = j1,..,jk
        // In this werden alle Tupel <x1,..,xn> fuer die es ein
        // Tupel <y1,..,ym> aus R2 gibt, mit xi1 = yj1 & xi2 = yi2 & .. & xik =
        // yik
        // gel�scht
        GroundAtom t, t2;
        N1watch.press();
        if (debuglevel > 0)
            System.out.println("-> Negation1");
        Negation neg = new Negation(this, index1, R2, index2, Time.getTime());
        neg.Operate();
        // L�sche Tupel
        for (t = this.tuples2; t != null; t = t2) {
            t2 = t.next2;
            Delete(t);
        }
        N1watch.release();
        if (debuglevel > 0)
            System.out.println("<- Negation1");
    }

    public void Negation2(int index1[], Atoms R2, int index2[]) {
        // index1 = i1,..,ik, index2 = j1,..,jk
        // In this werden alle Tupel <x1,..,xn> fuer die es ein
        // Tupel <y1,..,ym> aus R2 gibt, mit xi1 = yj1 & xi2 = yi2 & .. & xik =
        // yik
        // als gel�scht markiert
        GroundAtom t;
        N2watch.press();
        if (debuglevel > 0)
            System.out.println("-> Negation2");
        Negation neg = new Negation(this, index1, R2, index2, Time.getTime());
        neg.Operate();
        for (t = R2.tuples2; t != null; t = t.next2) {
            (t).Disports(t);
        }
        if (debuglevel > 0) {
            System.out.println("Negate ...");
            System.out.println("Result:");
            this.print(System.out);
            System.out.println();
        }
        N2watch.release();
        if (debuglevel > 0)
            System.out.println("<- Negation2");
    }

    public GroundAtom Next() {
        GroundAtom t;
        t = enum1.EnumNext();
        while ((t != null) && (t.deleted)) {
            t = enum1.EnumNext();
        }
        return t;
    }

    public void notinTermSet(TermSet TS, int index) {
        // bestimmt alle GroundAtome, die an Index index einen Term haben, der
        // nicht
        // in TermSet TS enthalten ist
        GroundAtom t;
        IndexEnumeration enm;
        if (index < stellen) {
            this.tuples2 = null;
            enm = this.indices.avl.elements();
            while (enm.hasMoreElements()) {
                t = (GroundAtom) enm.nextElement();
                if (!TS.In((t).terms[index])) {
                    t.next2 = this.tuples2;
                    this.tuples2 = t;
                }
            }
        }
    }

    public void print() {
        IndexEnumeration enm;
        enm = this.indices.avl.elements();
        while (enm.hasMoreElements()) {
            System.out.println(((GroundAtom) enm.nextElement()).toString());
        }
    }

    public void print(PrintStream p) {
        GroundAtom t;
        IndexEnumeration enum1 = (IndexEnumeration) this.indices.avl.elements();
        while (enum1.hasMoreElements()) {
            t = (GroundAtom) enum1.nextElement();
            t.print(p);
            p.println();
        }
    }

    public void print(PrintStream p, String pr[], String f[], String st[]) {
        GroundAtom t;
        IndexEnumeration enm = (IndexEnumeration) this.indices.avl.elements();
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            t.print(p, pr, f, st);
            if (t.deleted)
                p.print(" :deleted");
            p.println();
        }
    }

    void printindices(Atoms R) {
        int i;
        IndexNode ix;
        for (i = 0, ix = R.indices; ix != null; ix = ix.next, i++)
            ;
        System.out.print("  Tuples: ");
        System.out.print(R.anztuples);
        System.out.print(" Indices: ");
        System.out.print(i);
    }

    public static void printTimes() {
        System.out.print("Union:        ");
        Unwatch.print();
        System.out.print("Delete:       ");
        Dwatch.print();
        System.out.print("Insert:       ");
        Iwatch.print();
        System.out.print("Search:       ");
        Swatch.print();
        System.out.print("MatchJoin:    ");
        MJwatch.print();
        System.out.print("Filtering:    ");
        Fwatch.print();
        System.out.print("Filtering1:   ");
        F1watch.print();
        System.out.print("Join:         ");
        Jwatch.print();
        System.out.print("Negation:     ");
        Nwatch.print();
        System.out.print("Negation1:    ");
        N1watch.print();
        System.out.print("Negation2:    ");
        N2watch.print();
        System.out.print("Subsumption:  ");
        Subwatch.print();
        System.out.print("Substitution: ");
        Substwatch.print();
        System.out.print("Unify:        ");
        Uwatch.print();
        System.out.print("Unions:       ");
        System.out.println(nounion);
    }

    /** Retract all atoms */
    public void Retract() {
        GroundAtom t;
        IndexEnumeration enm;
        enm = this.indices.avl.elements();
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            t.Retract();
        }
    }

    /**
     * Searches for an atom t. Return the found atom or null if this does not
     * contain t
     */
    public GroundAtom Search(GroundAtom t) {
        Swatch.press();
        if (debuglevel > 0)
            System.out.println("-> Search");
        GroundAtom b;
        b = (GroundAtom) indices.avl.Search(t);
        if (debuglevel > 0)
            System.out.println("<- Search");
        Swatch.release();
        if (b != null)
            return b;
        else
            return null;
    }

    public void Select(TermSet termsets[]) {
        // L�scht alle GroundAtome, deren Terme nicht an der entsprechenden
        // Stelle
        // in den termsets enthalten sind
        GroundAtom t;
        boolean delete;
        int i;
        IndexEnumeration enm;
        Selwatch.press();
        if (debuglevel > 0)
            System.out.println("-> Select");
        enm = this.indices.avl.elements();
        this.tuples2 = null;
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            delete = false;
            for (i = 0; (i < t.terms.length) && (!delete); i++)
                if ((t).terms[i].ground && (termsets[i] != null)
                        && (!termsets[i].In((t).terms[i])))
                    delete = true;
            if (delete) {
                t.next2 = this.tuples2;
                this.tuples2 = t;
            }
        }
        if (debuglevel > 0)
            System.out.println("<- Select");
    }

    public void SelectAll() {
        GroundAtom t;
        IndexEnumeration enm;
        if (debuglevel > 0)
            System.out.println("-> SelectAll");
        enm = this.indices.avl.elements();
        this.tuples2 = null;
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            t.next2 = this.tuples2;
            this.tuples2 = t;
        }
        if (debuglevel > 0)
            System.out.println("<- SelectAll");
    }

    public void SetCheckTime() {
        // setzt checktime auf die aktuelle Zeit und setzt added und deleted
        // zurueck
        checktime = Time.getTime();
        added = 0;
        deleted = 0;
        supported = 0;
        modified = false;
    }

    private void sortindices(int index1[], int index2[], int sindex1[],
            int sindex2[], float groundness[]) {
        int i, j, h, max;
        for (i = 0; i < index1.length; i++)
            sindex1[i] = index1[i];
        for (i = 0; i < index2.length; i++)
            sindex2[i] = index2[i];
        for (i = 0; sindex1[i] != -1; i++) {
            max = i;
            for (j = i + 1; sindex1[j] != -1; j++) {
                if (groundness[sindex1[j]] > groundness[sindex1[max]])
                    max = j;
            }
            h = sindex1[i];
            sindex1[i] = sindex1[max];
            sindex1[max] = h;
            h = sindex2[i];
            sindex2[i] = sindex2[max];
            sindex2[max] = h;
        }
    }

    public void Substitute(Atom T, Atoms R, int index1[]) {
        // produziert aus den Substitutionen s in R alle s(T).
        // index = i1,..,ik. ij gibt die Spalte der Variable mit Symbol j in R
        // an
        GroundAtom t;
        int i;
        GroundAtom f;
        GroundAtom ins;
        Variable v;
        boolean res = true;
        Substwatch.press();
        if (debuglevel > 0) {
            System.out.println("-> Substitute");
            if (debuglevel > 1) {
                System.out.println("Atom:");
                System.out.println(T.toString());
                System.out.println("Source:");
                R.print(System.out);
                System.out.println();
            }
        }
        IndexEnumeration enm = R.indices.avl.elements();
        this.tuples2 = null;
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            for (v = (T).variables; v != null; v = v.next)
                if ((v.symbol < index1.length) && (index1[v.symbol] != -1)
                        && (index1[v.symbol] < (t).terms.length))
                    v.subsby = (t).terms[index1[v.symbol]];
            f = new GroundAtom(this.stellen);
            for (i = 0; i < this.stellen; i++) {
                f.terms[i] = T.terms[i].Substitute();
            }
            // f.Variables();
            ins = this.Insert(f);
            t.Supports(ins);
            if (ins == f) {
                f.next2 = this.tuples2;
                this.tuples2 = f;
            }
            T.ClearVariables();
        }
        if (debuglevel > 0) {
            if (debuglevel > 1) {
                System.out.println("Ergebnis:");
                this.print(System.out);
                System.out.println();
            }
            System.out.println("<- Substitute");
        }
        Substwatch.release();
    }

    /** Determines all atoms subsumed by atoms in R */
    public void Subsumption(Atoms R) {
        // bestimmt alle GroundAtome in this, die von GroundAtomen in R
        // subsummiert werden
        int index1[], index2[];
        GroundAtom t, t1;
        Subsumption subsum;
        Subwatch.press();
        if (debuglevel > 0)
            System.out.println("-> Subsumption");
        index1 = new int[this.matchindex.length];
        index2 = new int[this.matchindex.length];
        sortindices(this.matchindex, this.matchindex, index1, index2,
                R.groundness);
        subsum = new Subsumption(this, index1, R, index2, Time.getTime());

        subsum.Operate();
        t = this.tuples2;
        while (t != null) {
            t1 = t.next2;
            this.Delete(t);
            t = t1;
        }
        this.tuples2 = null;
        if (debuglevel > 0)
            System.out.println("<- Subsumption");
        Subwatch.release();
    }

    public void Terms(TermSet TS, int index) {
        // f�gt alle Terme, die an Index index auftreten in den TermSet TS ein
        GroundAtom t;
        IndexEnumeration enm;
        Twatch.press();
        if (debuglevel > 0)
            System.out.println("-> Terms");
        if (index < stellen) {
            enm = this.indices.avl.elements();
            while (enm.hasMoreElements()) {
                t = (GroundAtom) enm.nextElement();
                if ((t).terms[index].ground)
                    TS.Insert((t).terms[index]);
            }
        }
        if (debuglevel > 0)
            System.out.println("<- Terms");
        Twatch.release();
    }

    public String toString(String p, String pr[], String f[], String st[]) {
        // Ausgabe aller GroundAtome mit Pr�dikatsymbol p und Symboltabelle ids
        GroundAtom t;
        String s = "";
        IndexEnumeration enm;
        enm = this.indices.avl.elements();
        while (enm.hasMoreElements()) {
            t = (GroundAtom) enm.nextElement();
            s = s.concat((t).toString(p, pr, f, st) + ".\n");
        }
        return s;
    }

    public void Unify(Atom T, Atoms R1) {
        // this enth�lt danach alle Substitutionen s1 f�r die es eine
        // Substitution s2
        // mit s1(T) = s2(a), wobei a aus R1 ist, s1,s2 sind die allgemeinsten
        // Unifikatoren
        Unify uni;
        Uwatch.press();
        if (debuglevel > 0)
            System.out.println("-> Unify");
        uni = new Unify(R1, T, this, Time.getTime());
        uni.Operate();
        if (debuglevel > 0)
            System.out.println("<- Unify");
        Uwatch.release();
    }

    synchronized public void Union(Atoms R) {
        nounion++;
        if (debuglevel > 0) {
            System.out.println("-> Union");
            if (debuglevel > 1) {
                System.out.println("Source1:");
                R.print(System.out);
                System.out.println();
                System.out.println("Source2:");
                this.print(System.out);
                System.out.println();
            }
        }
        Unwatch.press();
        // vereinige this und die Relation R
        GroundAtom t;
        /*
         * printindices(this); printindices(R);
         */
        IndexEnumeration enum1 = (IndexEnumeration) R.indices.avl.elements();
        // boolean inserted;
        this.tuples2 = null;
        while (enum1.hasMoreElements()) {
            t = (GroundAtom) enum1.nextElement();
            // System.out.println(t.toString());
            if (t == Insert(t)) {
                t.next2 = this.tuples2;
                this.tuples2 = t;
            }
        }
        if (debuglevel > 0) {
            if (debuglevel > 1) {
                System.out.println("Destination:");
                this.print(System.out);
                System.out.println();
            }
            System.out.println("<- Union");
        }
        Unwatch.release();
        /*
         * printindices(this); System.out.println();
         */

    }

    synchronized public void UnionAndSelected(Atoms B, Atoms C) {
        if (debuglevel > 0)
            System.out.println("-> UnionAndSelected");
        this.Union(B);
        C.UnionSelected(this);
        if (debuglevel > 0)
            System.out.println("<- UnionAndSelected");
    }

    synchronized public void UnionSelected(Atoms R) {
        // von der Relation R werden die Tuple in this eingefuegt, die durch
        // next2 verkettet sind
        // dabei wird die Selektion zerstoert
        GroundAtom t, t1;
        if (debuglevel > 0) {
            System.out.println("-> UnionSelected");
            if (debuglevel > 1) {
                System.out.println("Source1:");
                R.print(System.out);
                System.out.println();
                System.out.println("Source2:");
                this.print(System.out);
                System.out.println();
            }
        }

        this.tuples2 = null;
        t = R.tuples2;
        while (t != null) {
            t1 = t.next2;
            if (/* !t.deleted && */(t == Insert(t))) {
                t.next2 = this.tuples2;
                this.tuples2 = t;
            }
            t = t1;
        }
        if (debuglevel > 0) {
            if (debuglevel > 1) {
                System.out.println("Destination:");
                this.print(System.out);
                System.out.println();
            }
            System.out.println("<- UnionSelected");
        }
    }
}
