/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: AVLEnumeration.java

 Version: 1.1

 Purpose: Enumeration to access elements of an AVL tree

 History:

 */

import java.util.NoSuchElementException;

import org.deri.mins.operations.Comparison;


public class AVLEnumeration implements IndexEnumeration {
    private AVLTree avl;

    private Keller current;

    static int kellermax = 40;

    private AVLnodeDup cur = null;

    private Comparison compare;

    boolean firstaccess = true;

    /** Constructor */
    public AVLEnumeration(AVLTree a) {
        avl = a;
        compare = avl.comp;
        current = new Keller(kellermax);
    }

    public Object clone() {
        AVLEnumeration c;
        c = new AVLEnumeration(avl);
        c.current.Copy(this.current);
        c.cur = this.cur;
        c.compare = this.compare;
        c.firstaccess = this.firstaccess;
        return c;
    }

    /** Are there more elements available? */
    public boolean hasMoreElements() {
        if (firstaccess && avl.tree != null)
            return true;
        if (!current.Empty() || cur != null)
            return true;
        return false;
    }

    /**
     * Give the next element. Throws NoSuchElementException if no further
     * element is available
     */
    public Object nextElement() throws NoSuchElementException {
        AVLnode a, b;
        if (firstaccess) {
            firstaccess = false;
            b = avl.tree;
            while (b != null) {
                current.Push(b);
                b = b.links;
            }
        }
        if (cur != null) {
            a = cur;
            cur = cur.mitte;
            return a.data;
        }
        else if (!current.Empty()) {
            a = current.Top();
            current.Pop();
            if (a.rechts != null) {
                current.Push(a.rechts);
                b = a.rechts.links;
                while (b != null) {
                    current.Push(b);
                    b = b.links;
                }
            }
            if (a instanceof AVLnodeDup) {
                cur = ((AVLnodeDup) a).mitte;
            }
            // System.out.println(((GroundAtom)a.data).toString());
            return a.data;
        }
        return null;
    }

    /**
     * Give the first next element greater than o. Throws NoSuchElementException
     * if no further element is available at all. Returns null if no greater
     * element is available
     */
    public Object nextGreaterElement(Object o) throws NoSuchElementException {
        AVLnode b, last = null;
        boolean stop = false;
        int cmp;
        // System.out.println("1");
        if (current.Empty() || firstaccess)
            return null;
        b = current.Top();
        cmp = compare.Compare(b.data, o);
        if (cmp != -1)
            return nextElement();
        else {
            while (!current.Empty()
                    && (compare.Compare((current.Top()).data, o) == -1)) {
                b = current.Top();
                current.Pop();
            }
            if (b.rechts != null) {
                current.Push(b.rechts);
                while (!stop) {
                    // System.out.println("2");

                    b = current.Top();
                    cmp = compare.Compare(b.data, o);
                    switch (cmp) {
                    case 0:
                    case -2:
                    case 2:
                        if ((b.links != null) && (last != b)) {
                            current.Push(b.links);
                            last = b;
                        }
                        else
                            stop = true;
                        break;
                    case -1:
                        current.Pop();
                        if (b.rechts != null)
                            current.Push(b.rechts);
                        else
                            stop = true;
                        break;
                    case 1:
                        if (b.links != null)
                            current.Push(b.links);
                        else
                            stop = true;
                        break;
                    }
                }
            }
            cur = null;
            if (!current.Empty())
                return nextElement();
            else
                return null;
        }
    }

    /** position to element */
    public void positionToElement(Object o) {
        int cmp;
        AVLnode b, last = null;
        boolean stop = false;
        if (firstaccess) {
            firstaccess = false;
            current = new Keller(kellermax);
        }
        else
            current.Clear();
        if (avl.tree != null) {
            current.Push(avl.tree);
            while (!stop) {
                b = current.Top();
                cmp = compare.Compare(b.data, o);
                switch (cmp) {
                case 0:
                case -2:
                case 2:
                    if ((b.links != null) && (last != b)) {
                        current.Push(b.links);
                        last = b;
                    }
                    else
                        stop = true;
                    break;
                case -1:
                    current.Pop();
                    if (b.rechts != null)
                        current.Push(b.rechts);
                    else
                        stop = true;
                    break;
                case 1:
                    if (b.links != null)
                        current.Push(b.links);
                    else
                        stop = true;
                    break;
                }
            }
        }
    }

    public void print() {
        System.out.println("Stack:");
        current.print();
    }

    public void setComparisonMethod(Comparison c) {
        compare = c;
    }
}
