/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.api;

import org.deri.mins.*;
import org.deri.mins.terms.TermSet;

/*

 Name: DBInterface.java

 Version: 1.1

 Purpose: Interface for accessing a database or a ruleset
 EvaluateRule and isEvaluable integrated (jan)

 History:

 */

public interface DBInterface {

    // Gibt an, ob die Regel durch die Datenbank evaluierbar ist

    public void addFact(int sym, GroundAtom fact);

    // F�gt ein einzelnes Faktum hinzu

    public void deleteFact(int sym, GroundAtom fact);

    // Dies wird f�r Optimierungszwecke gebraucht. Liefert die Menge von Termen,
    // die am i-ten Argument aller Fakten des Pr�dikatsymbols praedikatsymbol
    // auftreten.

    public int evalRule(Rule r);

    // L�scht ein Faktum

    public Atoms getFacts(int praedikatsymbol, Atoms filterterme);

    // Das ist die wesentliche Funktion zum Zugriff auf Fakten.
    // Es werden auf Fakten mit dem Pr�dikatsymbol praedikatsymbol zugegriffen.
    // Der Zugriff wird mit Hilfe einer Menge von Filtertermen filterterme
    // eingeschr�nkt.
    // Ein Filterterm ist ein Tupel von Termen, die Variablen enthalten k�nnen.
    // Z.B. ist f(X,a),"hallo",X ein solcher Filterterm.
    // Das Ergebnis des Aufrufs ist eine Menge von Fakten,
    // die zu diesen Filtertermen "passen" (die mit einem der Filterterme
    // matchen).

    // Z.B. enthalte die entsprechende Tabelle der DB die Zeilen:
    // 5, "hallo",8
    // f(7,a), "hallo",7
    // f(ab,a), "hallo",ab
    // f(7,a), "hallo",h
    // f(ab,a), "huhu",ab

    // Die filterterme bestehen nur aus dem einen Filterterm: f(X,a),"hallo",X.
    // Dann ist das Ergebnis des Aufrufs die folgende Menge von Fakten:
    // f(7,a), "hallo", 7
    // f(ab,a), "hallo", ab

    public TermSet getTerms(int praedikatsymbol, int i);

    // Evaluiert die Regel r naiv und schreibt die Ergebnisse wieder in die
    // Datenbank
    // Die Evaluierung wird dabei direkt von der Datenbank ausgef�hrt

    public boolean isEvaluable(Rule r);
}
