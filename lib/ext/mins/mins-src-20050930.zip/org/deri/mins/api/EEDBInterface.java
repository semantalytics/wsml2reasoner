/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.api;

import org.deri.mins.*;
import org.deri.mins.terms.TermSet;

/**
 * Interface or class description
 *
 * <pre>
 * Created on Sep 29, 2005
 * Committed by $Author$
 * $Source$,
 * </pre>
 *
 * @author Holger Lausen
 *
 * @version $Revision$ $Date$
 */
public interface EEDBInterface {

    /**
     * Adds a fact. If rollback is enabled fact is added temporarily. Otherwise
     * the fact is added to the database.
     */
    public void addFact(int sym, GroundAtom fact);

    /**
     * Adds a set of facts. If rollback is enabled facts are added temporarily.
     * Otherwise the facts are added to the database.
     */
    public void addFacts(int sym, Atoms facts);

    /**
     * Adds a rule to the ruleset. To get correct evaluation results afterwards
     * intermediate results have to be deleted using method ClearRuleSet
     */
    public void addRule(Rule r);

    /**
     * Adds a rule to the ruleset. s is the String representation of the rule.
     * To get correct evaluation results afterwards intermediate results have to
     * be deleted using method ClearRuleSet
     */

    public void addRule(String s, Rule r);

    /** Deletes a fact from database */
    public void deleteFact(int sym, GroundAtom fact);

    /** Deletes a rule from the Ruleset */
    public void deleteRule(Rule r);

    /**
     * Evaluates all queries which have been added to the ruleset <br>
     * until answers have been derived in case of <br>
     * wellfounded and dynamic evaluation.<br>
     * Returns true if more answers are expected. Must be called until
     * evaluation is finished. <br>
     * The new answers are returned by "LastResult" or "LastSubstitution". All
     * answers up to now are returned by "Result" or "Substitution".
     */
    public boolean evalQueries();

    public int evalRule(Rule r);

    /**
     * Determines the evaluation method.<BR>
     * 0: Naive Evaluation (only stratifight prorgams)<BR>
     * 1: Dynamic Filtering Evaluation (only stratifight prorgams)<BR>
     * 2: Wellfounded Evaluation with alternating fixed point (juergen says
     * works)<BR>
     * 3: Wellfounded Evaluation (juergen says probably buggy!)
     */
    public void setEvaluationMethod(int method);

    /**
     * Delivers all those facts which fit to the filter terms<BR>
     * "praedikatsymbol" is the number of the predicate (predicates are
     * numbered). <br>
     * "filterterme" are the filter atoms.
     */
    public Atoms getFacts(int praedikatsymbol, Atoms filterterme);

    /** Delivers all terms of argument i of predicate */
    public TermSet getTerms(int praedikatsymbol, int i);

    /** Switches rules for inferencing off */
    public void inferOff();

    /** Switches rules for inferencing on */
    public void inferOn();

    /**
     * Returns subsequently all queries.<br>
     * If query==null first query is returned
     */
    public Rule nextQuery(Rule query);

    /**
     * Returns all the evaluation results of query q.<br>
     * The result is a set of variable substitutions of the variables<br>
     * in q.
     */
    public Substitution getSubstitution(Rule query);

}