/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

//import com.ontoprise.inference.SimpleEvaluator;
import org.deri.mins.terms.Variable;

/*

 Name: BuiltinFunc.java

 Version: 1.01

 Purpose:

 History:
 2.5.99 Added support for new builtin mechanism. SDe
 (Some Methods are declared public now)
 3.5.99 Deleted arity and symbol method again. SDe
 20.9.99 method retract added. JAn


 */

public class BuiltinFunc {
    // public SimpleEvaluator eval = null;

    public Atoms D;

    public Atoms B;

    int index[];

    Atom T;

    Atom ins;

    public BuiltinFunc() {
        // eval = null;
    }

    // public BuiltinFunc(SimpleEvaluator eval) {
    // this.eval = eval;
    // }

    public void eval(Atom t) {
    }

    public boolean evaluable(Atom t) {
        return true;
    }

    public void insert(Atom t1) {
        Atom t;
        boolean inserted, unified;
        Variable v;

        unified = T.Match(t1);
        t = new Atom(D.stellen);
        for (v = T.variables; v != null; v = v.next)
            t.terms[index[v.symbol]] = v.subsby;
        ins = (Atom) D.Insert(t);
        if (ins == t) {
            t.next2 = D.tuples2;
            D.tuples2 = t;
        }
        else {
            t = null;
        }
        t1.Supports(ins);
        t1.ClearVariables();
        T.ClearVariables();
    }

    boolean isevaluable(Atom T, Atom t) {
        Variable v;
        Atom f;
        int i;
        for (v = T.variables; v != null; v = v.next)
            v.subsby = t.terms[v.symbol];
        f = new Atom(T.terms.length);
        for (i = 0; i < T.terms.length; i++) {
            f.terms[i] = T.terms[i].Substitute();
        }
        f.Variables();
        T.ClearVariables();
        return evaluable(f);
    }

    public void retract(Atom t1) {
        t1.Retract();
    }
}
