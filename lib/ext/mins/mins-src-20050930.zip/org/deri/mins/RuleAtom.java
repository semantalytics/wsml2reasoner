/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: RuleAtom.java

 Version: 1.1

 Purpose: represents atoms in a rule

 History: attributes for detecting cycles in the system graph added (jan)

 */

import java.io.PrintStream;

import org.deri.mins.terms.Term;
import org.deri.mins.terms.Variable;


public class RuleAtom extends Atom {
    public Filter filter = null;

    public Atoms up = null; // Substitutionen f�r die Variablen des Atoms

    public Atoms down = null; // Substituierte Atome f�r Downpropagierung

    public Atoms adddown = null; // inkrementelle Berechnung

    public Atoms addup = null; // inkrementelle Berechnung

    public int symbol; // Pr�dikatsymbol

    public Rule rule = null; // Verweis auf Regel

    RuleAtom next = null; // Verzeigerung innerhalb von RuleSet

    RuleAtom last = null; // Doppeltverzeigerung innerhalb von RuleSet

    Variable vars1[]; // index to the variables of the atom

    int vars2[]; // index to the symbols of the variables of the atom

    int vars3[]; // index is the symbol of the variable, content indicates

    // column of the relation

    int index1[]; // indicates the join columns

    int index2[]; // indicates the join columns

    boolean visited = false; // f�r den algorithmus zur Bestimmung starker

    // Komponenten in RuleSet

    boolean stacked = false; // ""

    int dfbi = 0; // ""

    int q = 0; // ""

    public RuleAtom(int sym, Term terme[]) {
        // sym = Pr�dikatsymbols, anz = Stelligkeit, terme = Feld mit Referenzen
        // auf Terme
        super(terme);
        Variable v;
        symbol = sym;
        int j, i, max;
        vars1 = new Variable[anzvars + 1];
        vars2 = new int[anzvars + 1];
        index1 = new int[anzvars + 1];
        for (v = variables, j = 0; v != null; v = v.next, j++) {
            vars1[j] = v;
            vars2[j] = v.symbol;
            index1[j] = -1;
        }
        vars1[j] = null;
        vars2[j] = -1;
        index1[j] = -1;
        max = -1;
        for (i = 0; i < anzvars; i++)
            if (max < vars2[i])
                max = vars2[i];
        vars3 = new int[max + 1];
        for (i = 0; i <= max; i++)
            vars3[i] = -1;
        for (i = 0; i < anzvars; i++)
            vars3[vars2[i]] = i;

    }

    public void ClearRuleAtom() {
        // L�schen der aufgesammelten Zwischenergebnisse
        up = new Atoms(up.stellen);
        addup = new Atoms(addup.stellen);
        down = new Atoms(down.stellen);
        adddown = new Atoms(adddown.stellen);
    }

    public void internalize(PrintStream p) {
        p.print("p" + String.valueOf(symbol));
        super.internalize(p);
    }

    public void print(PrintStream p) {
        // int i;
        p.print("p");
        p.print(symbol);
        // System.out.print((char)((int)('p')+symbol));
        p.print('(');
        super.print(p);
        p.print(')');
    }

    public String toString() {
        // int i;
        String s;
        s = "p";
        s += Integer.toString(symbol);
        // System.out.print((char)((int)('p')+symbol));
        s += "(";
        s += super.toString();
        s += ')';
        if (cycle)
            s += " cycle";
        else
            s += " nocycle";
        return s;
    }
}
