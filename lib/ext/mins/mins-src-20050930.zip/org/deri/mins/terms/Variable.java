/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.terms;

/*

 Name: Variable.java

 Version: 1.2


 Purpose: realises Variables


 History: function internalize1 returning strings added (jan)
 interface simplified (jan)

 */

public class Variable extends Term {
    // type == 1
    public int symbol; // Variablensymbol

    public int hsymbol; // Feld zum Retten des Variablensymbols bei

    // Umbenennungen

    public Term subsby = null; // hier wird ein Term zur Substitution der

    // Variablen angeh�ngt

    public Variable next = null; // Verzeigerung der Variablen innerhalb

    // eines Atoms

    public Variable(int sym) {
        super(0, false);
        symbol = sym;
        ground = false;
        subsby = null;
        groundlevel = 1;
    }

    public void AttachSubs(Term t) {
        this.subsby = t;
    }

    public Term Clone() {
        // kloniert den Term
        Variable v;
        v = new Variable(this.symbol);
        if (subsby != null)
            v.subsby = subsby.Clone();
        return v;
    }

    public Term CloneFlat() {
        return new Variable(this.symbol);
    }

    public int compareFlat(Term t) {
        // vergleicht zwei Variablen aufgrund ihrer Symbole
        return symbol <= ((Variable) t).symbol ? (symbol < ((Variable) t).symbol ? -1
                : 0)
                : 1;
    }

    public Term getSubs() {
        return this.subsby;
    }

    public String InternalizeFlat() {
        return "X" + String.valueOf(symbol);
    }

    public boolean isVariable() {
        return true;
    }

    public boolean Match(Term t2) {
        if (this.subsby != null)
            // first is a variable and is already substituted
            return this.subsby.Match(t2);
        else if ((t2 instanceof Variable) && (((Variable) t2).subsby != null)) {
            this.subsby = ((Variable) t2).subsby;
            return true;
        }
        else {
            // Substitutiere Variable mit t2
            this.subsby = t2;
            return true;
        }
    }

    protected boolean occurs(Variable v) {
        // Occurence Check
        if (subsby != null)
            return subsby.occurs(v);
        else if (symbol == v.symbol)
            return true;
        else
            return false;
    }

    public Term Substitute() {
        // Durchf�hrung einer Substitution, d.h. die Variable wird durch ihren
        // Substituenden im Term ersetzt
        // Dabei werden alle oberen Terme (�berhalb von Variablen) neu generiert
        if (subsby != null)
            if (subsby.ground)
                return subsby;
            else
                return subsby.Substitute();
        else {
            return new Variable(symbol);
        }
    }

    public String toStringFlat() {
        return "X" + String.valueOf(symbol);
    }

    public String toStringFlat(String p[], String f[], String st[]) {
        // Ausgabe der Variablen mit dem Substitutenden als String,
        Character ch;
        String s;
        ch = new Character((char) ((int) (('X') + symbol)));
        s = ch.toString();
        if (subsby != null) {
            s = s.concat("/");
            s = subsby.toString(p, f, st);
        }
        return s;
    }

    public int Type() {
        return 1;
    }

    public boolean Unify(Term t2) {
        // Unifikation der Variable this mit Term t2
        if (this.subsby != null)
            // first is a variable and is already substituted
            return t2.Unify(this.subsby);
        else if (t2 instanceof Variable) {
            // second is also a variable
            if (((Variable) t2).subsby != null)
                // second is substituted
                return this.Unify(((Variable) t2).subsby);
            else
                // both are variables which are not substituted
                ((Variable) t2).symbol = symbol;
            return true;
        }
        else {
            // second is no variable
            if (!t2.occurs(this)) {
                this.subsby = t2;
                return true;
            }
            else
                // first variable occurs in second term
                return false;
        }
    }
}
