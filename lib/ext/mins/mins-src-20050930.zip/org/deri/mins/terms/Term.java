/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.terms;

/*

 Name: Term.java


 Version: 1.21

 Purpose: an abstract class for terms

 History: function internalize returning a string added (jan)
 interface simplified (jan)
 bug in Substitute corrected (jan)

 */

import java.io.PrintStream;

/*
 * Dieses Modul enthaelt alles, was mit einzelnen Termen zusammenhaengt
 */

public abstract class Term {
    protected static int anz = 0; // number of terms created up to now

    public boolean ground = true; // shows whether term contains variables or

    // not

    public int groundlevel = -1; // gives the level until term is ground

    public Term pars[] = null; // sub terms

    private Object attached = null; // attach any Java object

    /** Constructor. terms are the sub terms */
    public Term(Term terms[]) {
        // terms enthaelt die Parameter
        int i;
        ground = true;
        pars = new Term[terms.length];
        if (terms.length > 0)
            groundlevel = terms[0].groundlevel + 1;
        for (i = 0; i < terms.length; i++) {
            if (!terms[i].ground)
                ground = false;
            if (terms[i].groundlevel + 1 < groundlevel)
                groundlevel = terms[i].groundlevel + 1;
            pars[i] = terms[i];
        }
    }

    /**
     * Constructor. parsnum is the number of sub terms. grnd shows whether term
     * is ground
     */
    public Term(int parsnum, boolean grnd) {
        anz++;
        // creating terms
        ground = grnd;
        pars = new Term[parsnum];
    }

    /** Returns the number of sub terms */
    public int anzpars() {
        if (pars == null)
            return 0;
        else
            return pars.length;
    }

    /** Attach any Java object to the term */
    public void Attach(Object o) {
        attached = o;
    }

    public Term Clone() {
        // Klonen des Terms und seiner Unterterme
        int i;
        Term t;
        t = this.CloneFlat();
        for (i = 0; i < pars.length; i++)
            t.pars[i] = pars[i].Clone();
        return t;
    }

    public abstract Term CloneFlat(); // Duplizieren ohne Unterterme

    /**
     * Compare two terms. Delivers -1 if this < t 0 if this == t 1 if this > t
     */
    public int Compare(Term t) {
        // vergleicht zwei Terme mit Untertermen
        // liefert die Werte -1 falls this < t, 0 falls this = t, 1 falls this >
        // t
        int cmp, i;
        if ((Type() != t.Type()) || (pars.length != t.pars.length)) {
            return CompareTypes(t);
        }
        else {
            cmp = compareFlat(t);
            if (cmp == 0) {
                for (i = 0; i < pars.length; i++) {
                    cmp = pars[i].Compare(t.pars[i]);
                    if (cmp != 0)
                        return cmp;
                }
            }
            return cmp;
        }
    }

    protected int CompareEqual(Term t) {
        return Compare(t);
    }

    // public int anzpars = 0;

    public abstract int compareFlat(Term t); // compares two terms without

    // sub terms

    public int CompareTypes(Term t) {
        // vergleicht zwei einzelne Terme (ohne Unterterme) aufgrund deren Typen
        // und Stelligkeit
        // liefert die Werte -1 falls this < t, 0 falls this = t, 1 falls this >
        // t
        int res;
        res = (Type() <= t.Type()) ? (Type() < t.Type() ? -1 : 0) : 1;
        return (res != 0) ? res
                : ((pars.length <= t.pars.length) ? ((pars.length < t.pars.length) ? -1
                        : 0)
                        : 1);
    }

    /** Creates a term which unifies with this and t */
    public Term Generalize(Term t) {
        // erzeugt einen Term der sowohl mit this als auch mit t unifizierbar
        // ist
        // Dabei muss this und t unifizierbar sein
        Term t1 = null;
        int i;
        boolean ground = true;
        if (t instanceof Variable)
            t1 = t.CloneFlat();
        else
            t1 = this.CloneFlat();
        for (i = 0; i < pars.length; i++) {
            t1.pars[i] = this.pars[i].Generalize(t.pars[i]);
            if (!t1.pars[i].ground)
                ground = false;
        }
        t1.ground = t1.ground && ground;
        return t1;
    }

    /** give the attached Java object */
    public Object getAttached() {
        return attached;
    }

    /** Creates a flat format out of the term */
    public String internalize() {
        int i;
        String s;
        s = InternalizeFlat();
        if (pars.length > 0) {
            s = s + "l" + String.valueOf(pars.length);
            for (i = 0; i < pars.length; i++) {
                s = s + pars[i].internalize();
            }
        }
        return s;
    }

    /** Writes internal format to printstream */
    public void internalize(PrintStream p) {
        p.print(internalize());
    }

    // Ausgabe des Terms als String, p,f,s sind Symboltabellen f�r
    // Pr�dikate,Funktionssymbole,Strings
    protected abstract String InternalizeFlat();

    /** Is it a constant? */
    public boolean isConstTerm() {
        return false;
    }

    /** Is the term ground ? */
    public boolean isGround(long v) {
        // v hat an der Stelle Bit i gesetzt, wenn Variable i nicht substituiert
        // sein soll
        // isGround gibt an, ob der Term unter zus�tzlicher Substitution der
        // Variablen in v ground ist
        int i;
        if (ground)
            return true;
        else if (this instanceof Variable) {
            if (((1L << (((Variable) this).symbol)) & v) == 0)
                return true;
            else
                return false;
        }
        else {
            for (i = 0; i < pars.length; i++) {
                if (!pars[i].isGround(v))
                    return false;
            }
        }
        return true;
    }

    /** Is it a number? */
    public boolean isNumTerm() {
        return false;
    }

    /** Is it a string? */
    public boolean isStringTerm() {
        return false;
    }

    /** Is it a variable? */
    public boolean isVariable() {
        return false;
    }

    /**
     * Matches this with t. t must be a ground term. The substituting terms are
     * attached to the variables
     */
    public boolean Match(Term t) {
        // Matcht den Term this mit dem Grundterm t. Die Substitutionen f�r die
        // Variablen werden an das
        // Feld subsby der Variablen in this angeh�ngt
        int i;
        boolean res = true;
        // if (t.ground) {
        if ((CompareTypes(t) != 0) || (compareFlat(t) != 0))
            return false;
        else {
            for (i = 0; i < pars.length; i++) {
                res = pars[i].Match(t.pars[i]);
                if (!res)
                    return res;
            }
            return res;
        }
    }

    protected boolean occurs(Variable v) {
        // Occurence Check f�r Variablen: true, falls Variable v in this
        // auftritt. Dabei sind
        // die Variablensymbole ma�gebend
        int i;
        boolean res = false;
        if (!ground) {
            for (i = 0; i < pars.length; i++) {
                res = pars[i].occurs(v);
                if (res)
                    return res;
            }
        }
        return res;
    }

    /** Prints term to printstream */
    public void print(PrintStream p) {
        p.print(toString());
    }

    public void print(PrintStream pr, String p[], String f[], String st[]) {
        pr.print(toString(p, f, st));
    }

    /**
     * Substitutes a variable in the term by the term attached to the variable
     * as substitution
     */
    public Term Substitute() {
        // Durchf�hrung einer Substitution, d.h. die Variable wird durch ihren
        // Substituenden im Term ersetzt
        // Dabei werden alle oberen Terme (oberhalb von Variablen) neu generiert
        Term t;
        int i;
        if (ground)
            return this;
        else {
            t = this.CloneFlat();
            t.ground = true;
            for (i = 0; i < pars.length; i++) {
                t.pars[i] = pars[i].Substitute();
                if (!t.pars[i].ground)
                    t.ground = false;
            }
            return t;
        }
    }

    /** Creates another string representation */
    public String toString() {
        // Ausgabe eines Terms mit Untertermen als String
        int i;
        String s;
        s = toStringFlat();
        if (pars.length > 0) {
            s = s.concat("(");
            for (i = 0; i < pars.length; i++) {
                s = s.concat(pars[i].toString());
                if (i < pars.length - 1)
                    s = s.concat(",");
            }
            s = s.concat(")");
        }
        return s;
    }

    /**
     * Creates a string representation. p,f,st contain names for predicate,
     * function, string symbols
     */
    public String toString(String p[], String f[], String st[]) {
        // Ausgabe eines Terms mit Untertermen als String, p,f,s sind
        // Symboltabellen f�r
        // Pr�dikatsymbole, Funktionssymbole, Strings
        int i;
        String s;
        // System.out.println("Term.toString");
        s = toStringFlat(p, f, st);
        if (pars.length > 0) {
            s = s.concat("(");
            for (i = 0; i < pars.length; i++) {
                s = s.concat(pars[i].toString(p, f, st));
                if (i < pars.length - 1)
                    s = s.concat(",");
            }
            s = s.concat(")");
        }
        return s;
    }

    // -1 if this < t, 0 if this = t, 1 if this > t
    protected abstract String toStringFlat();

    // Ausgabe eines Terms als String
    protected abstract String toStringFlat(String p[], String f[], String s[]);

    public int type() {
        return Type();
    }

    public abstract int Type(); // each different term type is associated to a

    // number

    /** Unifies this with t. The substituting terms are attached to the variables */
    public boolean Unify(Term t) {
        // Unifiziert zwei Terme. Die Substitutionen f�r die Variablen werden an
        // das
        // Feld subsby der Variablen angeh�ngt
        int i;
        boolean res = true;
        if (t instanceof Variable)
            return t.Unify(this);
        else if ((CompareTypes(t) != 0) || (compareFlat(t) != 0))
            return false;
        else {
            for (i = 0; i < pars.length; i++) {
                res = pars[i].Unify(t.pars[i]);
                if (!res)
                    return res;
            }
            return res;
        }
    }
}
