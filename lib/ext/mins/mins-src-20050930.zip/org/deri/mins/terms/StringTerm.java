/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.terms;

/*

 Name: StringTerm.java


 Version: 1.2

 Purpose: realises String terms

 History: function internalize1 returning a string added (jan)
 interface simplified (jan)

 */

public class StringTerm extends Term {
    // type = 3
    public String s; // repr�sentiert die Zeichenkette

    public StringTerm(String st) {
        // Stringkonstante
        super(new Term[0]);
        s = st;
    }

    public StringTerm(String st, Term terms[]) {
        // Funktion mit String st als Funktionssymbol
        // terms enthaelt die Parameter
        super(terms);
        s = st;
    }

    public StringTerm(String st, int anzpars, boolean grnd) {
        // Stringkonstante
        super(anzpars, grnd);
        s = st;
    }

    public Term CloneFlat() {
        return new StringTerm(s, pars.length, ground);
    }

    public int compareFlat(Term t) {
        int res;
        // Vergleicht zwei Zeichenketten miteinander
        res = s.compareTo(((StringTerm) t).s);
        return res <= 0 ? (res < 0 ? -1 : 0) : 1;
    }

    public String InternalizeFlat() {
        return "\"" + s + "\"";
    }

    public boolean isStringTerm() {
        return true;
    }

    public String toStringFlat() {
        // Ausgabe des einzelnen StringTerms (ohne Unterterme) als Zeichenkette
        return "\"" + s + "\"";
    }

    public String toStringFlat(String p[], String f[], String st[]) {
        // Ausgabe des einzelnen StringTerms (ohne Unterterme) als Zeichenkette
        return "\"" + s + "\"";
    }

    public int Type() {
        return 3;
    }
}
