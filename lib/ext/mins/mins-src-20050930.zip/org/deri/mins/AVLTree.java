/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

import org.deri.mins.operations.Comparison;
import org.deri.mins.operations.comparetest;

/*

 Name: AVLTree.java

 Version: 1.1

 Purpose: AVL tree used as access data structures at different places

 History:

 */

// an AVL tree
public class AVLTree implements IndexInterface {
    // member data
    protected boolean duplicates = false; // indicates whether duplicates are

    // stored

    protected AVLnode tree = null; // the root of the tree

    protected int number = 0; // number of nodes

    protected boolean HoehenAenderung = false; // for balancing

    protected Object inserted; // the node which has been inserted

    protected AVLnode deleted; // the node which has been deleted

    protected Comparison comp = null; // the operation to compare

    /**
     * Constructor. The parameter dups must be true, if the tree should store
     * duplicates
     */
    public AVLTree(boolean dups, Comparison c) {
        // dups indicates whether duplicates are stored (in the middle
        // references)
        duplicates = dups;
        comp = c;
    }

    private AVLnode BalanceDL(AVLnode baum) {
        AVLnode baum1, baum2;
        int balance1, balance2;

        switch (baum.balance) {
        case -1:
            baum.balance = 0;
            break;
        case 0:
            baum.balance = 1;
            HoehenAenderung = false;
            break;
        case 1:
            baum1 = baum.rechts;
            balance1 = (int) baum1.balance;
            if (balance1 >= 0) { /* single RR rotation */
                baum.rechts = baum1.links;
                baum1.links = baum;
                if (balance1 == 0) {
                    baum.balance = 1;
                    baum1.balance = -1;
                    HoehenAenderung = false;
                }
                else {
                    baum.balance = 0;
                    baum1.balance = 0;
                }
                baum = baum1;
            }
            else { /* double RL rotation */
                baum2 = baum1.links;
                balance2 = baum2.balance;
                baum1.links = baum2.rechts;
                baum2.rechts = baum1;
                baum.rechts = baum2.links;
                baum2.links = baum;
                if (balance2 == 1)
                    baum.balance = -1;
                else
                    baum.balance = 0;
                if (balance2 == -1)
                    baum1.balance = 1;
                else
                    baum1.balance = 0;
                baum = baum2;
                baum2.balance = 0;
            }
        }
        return baum;
    }

    private AVLnode BalanceDR(AVLnode baum) {
        AVLnode baum1, baum2;
        int balance1, balance2;

        switch (baum.balance) {
        case 1:
            baum.balance = 0;
            break;
        case 0:
            baum.balance = -1;
            HoehenAenderung = false;
            break;
        case -1:
            baum1 = baum.links;
            balance1 = (int) baum1.balance;
            if (balance1 <= 0) { /* single LL rotation */
                baum.links = baum1.rechts;
                baum1.rechts = baum;
                if (balance1 == 0) {
                    baum.balance = -1;
                    baum1.balance = 1;
                    HoehenAenderung = false;
                }
                else {
                    baum.balance = 0;
                    baum1.balance = 0;
                }
                baum = baum1;
            }
            else { /* double LR rotation */
                baum2 = baum1.rechts;
                balance2 = (int) baum2.balance;
                baum1.rechts = baum2.links;
                baum2.links = baum1;
                baum.links = baum2.rechts;
                baum2.rechts = baum;
                if (balance2 == -1)
                    baum.balance = 1;
                else
                    baum.balance = 0;
                if (balance2 == 1)
                    baum1.balance = -1;
                else
                    baum1.balance = 0;
                baum = baum2;
                baum2.balance = 0;
            }
        }
        return baum;
    }

    private AVLnode BalanceL(AVLnode baum) {
        AVLnode baum1, baum2;

        if (HoehenAenderung) {
            switch (baum.balance) {
            case -1:
                baum.balance = 0;
                HoehenAenderung = false;
                break;
            case 0:
                baum.balance = 1;
                break;
            case 1:
                baum1 = baum.rechts;
                if (baum1.balance == 1) { /* single RR rotation */
                    baum.rechts = baum1.links;
                    baum1.links = baum;
                    baum.balance = 0;
                    baum = baum1;
                }
                else { /* double RL rotation */
                    baum2 = baum1.links;
                    baum1.links = baum2.rechts;
                    baum2.rechts = baum1;
                    baum.rechts = baum2.links;
                    baum2.links = baum;
                    if (baum2.balance == 1)
                        baum.balance = -1;
                    else
                        baum.balance = 0;
                    if (baum2.balance == -1)
                        baum1.balance = 1;
                    else
                        baum1.balance = 0;
                    baum = baum2;
                }
                baum.balance = 0;
                HoehenAenderung = false;
            }
        }
        return baum;
    }

    private AVLnode BalanceR(AVLnode baum) {
        AVLnode baum1, baum2;

        if (HoehenAenderung) {
            switch (baum.balance) {
            case 1:
                baum.balance = 0;
                HoehenAenderung = false;
                break;
            case 0:
                baum.balance = -1;
                break;
            case -1:
                baum1 = baum.links;
                if (baum1.balance == -1) { /* single LL rotation */
                    baum.links = baum1.rechts;
                    baum1.rechts = baum;
                    baum.balance = 0;
                    baum = baum1;
                }
                else { /* double LR rotation */
                    baum2 = baum1.rechts;
                    baum1.rechts = baum2.links;
                    baum2.links = baum1;
                    baum.links = baum2.rechts;
                    baum2.rechts = baum;
                    if (baum2.balance == -1)
                        baum.balance = 1;
                    else
                        baum.balance = 0;
                    if (baum2.balance == 1)
                        baum1.balance = -1;
                    else
                        baum1.balance = 0;
                    baum = baum2;
                }
                baum.balance = 0;
                HoehenAenderung = false;
            }
        }
        return baum;
    }

    AVLnode construct(AVLnode data[], int s, int e) {
        int m;
        if (s > e)
            return null;
        m = (s + e) / 2;
        AVLnode res = data[m];
        if ((e - m) > (m - s))
            res.balance = 1;
        else if ((e - m) < (m - s))
            res.balance = -1;
        else
            res.balance = 0;
        res.links = construct(data, s, m - 1);
        res.rechts = construct(data, m + 1, e);
        return res;
    }

    private AVLnode delete(AVLnode baum, Object element) {
        AVLnode h; // mitte;
        AVLnodeDup h1;
        int compare;
        if (baum != null) { /* adress not in AVLnode */
            compare = comp.Compare(baum.data, element);
            switch (compare) {
            case 1:
                baum.links = delete(baum.links, element);
                if (HoehenAenderung)
                    baum = BalanceDL(baum);
                break;
            case -1:
                baum.rechts = delete(baum.rechts, element);
                if (HoehenAenderung)
                    baum = BalanceDR(baum);
                break;
            case 0:
                if (baum.data == element) {
                    number--;
                    deleted = baum;
                    if ((baum instanceof AVLnodeDup)
                            && (((AVLnodeDup) baum).mitte != null)) {
                        ((AVLnodeDup) baum).mitte.links = baum.links;
                        ((AVLnodeDup) baum).mitte.rechts = baum.rechts;
                        ((AVLnodeDup) baum).mitte.balance = baum.balance;
                        baum = ((AVLnodeDup) baum).mitte;
                    }
                    else {
                        if (baum.rechts == null) {
                            deleted = baum;
                            baum = baum.links;
                            HoehenAenderung = true;
                        }
                        else if (baum.links == null) {
                            deleted = baum;
                            baum = baum.rechts;
                            HoehenAenderung = true;
                        }
                        else if (baum.balance == 1) {
                            if (baum.rechts.links == null) {
                                deleted = baum;
                                baum.rechts.links = baum.links;
                                baum.rechts.balance = baum.balance;
                                baum = baum.rechts;
                                HoehenAenderung = true;
                                baum = BalanceDR(baum);
                            }
                            else {
                                baum.rechts = next(baum.rechts);
                                deleted.links = baum.links;
                                deleted.rechts = baum.rechts;
                                deleted.balance = baum.balance;
                                h = baum;
                                baum = deleted;
                                deleted = h;
                                /* treeoutput(baum.rechts,out,0); */
                                if (HoehenAenderung)
                                    baum = BalanceDR(baum);
                            }
                        }
                        else {
                            if (baum.links.rechts == null) {
                                deleted = baum;
                                baum.links.rechts = baum.rechts;
                                baum.links.balance = baum.balance;
                                baum = baum.links;
                                HoehenAenderung = true;
                                baum = BalanceDL(baum);
                            }
                            else {
                                baum.links = last(baum.links);
                                deleted.links = baum.links;
                                deleted.rechts = baum.rechts;
                                deleted.balance = baum.balance;
                                h = baum;
                                baum = deleted;
                                deleted = h;
                                if (HoehenAenderung)
                                    baum = BalanceDL(baum);
                            }
                        }
                    }
                }
                else if ((baum instanceof AVLnodeDup)
                        && (((AVLnodeDup) baum).mitte != null)) {
                    h1 = (AVLnodeDup) baum;
                    while ((h1.mitte != null) && (h1.mitte.data != element))
                        h1 = h1.mitte;
                    if (h1.mitte != null) {
                        number--;
                        deleted = h1.mitte;
                        h1.mitte = h1.mitte.mitte;
                    }
                }
            }
        }
        return baum;
    }

    /**
     * Delete the element identical (not only equal in the sense of Compare) to
     * ele To delete an arbitrary element this element has to be searched by
     * Search before
     */
    public void Delete(Object ele) {
        // returns the deleted element
        HoehenAenderung = false;
        // System.out.println(ele.toString());
        // print();
        tree = delete(tree, ele);
    }

    /** Returns the depth of the tree */
    public int Depth() {
        return depth(tree, 0);
    }

    // private methods to print the tree, balance the tree, insert and delete an
    // element

    // maximal depth of the tree
    private int depth(AVLnode t, int level) {
        int d1, d2;
        if (t == null)
            return level;
        else {
            d1 = depth(t.links, level + 1);
            d2 = depth(t.rechts, level + 1);
            if (d1 < d2)
                return d2;
            else
                return d1;
        }
    }

    /** Returns an enumeration for the elements */
    public IndexEnumeration elements() {
        return new AVLEnumeration(this);
    }

    private AVLnode insert(AVLnode baum, Object element) {
        AVLnodeDup n;
        int compare;

        if (baum == null) { /* insert */
            baum = new AVLnode(element);
            HoehenAenderung = true;
            baum.links = null;
            baum.rechts = null;
            // baum.mitte = null;
            baum.balance = 0;
            inserted = baum.data;
            number++;
        }
        else {
            compare = comp.Compare(baum.data, element);
            if (compare == 1) {
                baum.links = insert(baum.links, element);
                if (HoehenAenderung)
                    baum = BalanceR(baum);
            }
            else if (compare == -1) {
                baum.rechts = insert(baum.rechts, element);
                if (HoehenAenderung)
                    baum = BalanceL(baum);
            }
            else {
                /* ELSIF Baum^.compareikat(baum, element) = 0 THEN */
                HoehenAenderung = false;
                if (duplicates) {
                    if (!(baum instanceof AVLnodeDup)) {
                        n = new AVLnodeDup(baum.data);
                        n.links = baum.links;
                        n.rechts = baum.rechts;
                        n.balance = baum.balance;
                        n.mitte = null;
                        baum = n;
                    }
                    n = new AVLnodeDup(element);
                    n.mitte = ((AVLnodeDup) baum).mitte;
                    ((AVLnodeDup) baum).mitte = n;
                    number++;
                    inserted = n.data;
                }
                else
                    inserted = baum.data;
            }
        }
        return baum;
    }

    /**
     * Insert a new element. Returns ele if ele has been inserted. Returns the
     * element of the avl tree, equal to ele, if ele has not been inserted
     */
    public Object Insert(Object ele) {
        // return whether the element has inserted
        int oldnumber;
        HoehenAenderung = false;
        oldnumber = number;
        // if ((!duplicates && search(tree,ele) == null) || duplicates)
        tree = insert(tree, ele);
        return inserted;
    }

    private AVLnode last(AVLnode r) {
        if (r.rechts != null) {
            r.rechts = last(r.rechts);
            if (HoehenAenderung)
                r = BalanceDR(r);
        }
        else {
            deleted = r;
            r = r.links;
            HoehenAenderung = true;
        }
        return r;
    }

    public static void main(String args[]) throws Exception {
        AVLEnumeration enm;
        AVLTree avl1, avl2;
        Integer it;
        /*
         * avl1 = new AVLTree(false,new comparetest()); for(int i = 0; i <
         * 500000; i+= 2) avl1.Insert(new Integer(i)); avl2 = new
         * AVLTree(false,new comparetest()); for(int i = 1; i < 500000; i+= 2)
         * avl2.Insert(new Integer(i)); watch w = new watch(); w.press();
         * avl1.Union(avl2); w.release(); w.print();
         */
        avl1 = new AVLTree(false, new comparetest());
        for (int i = 0; i < 500000; i += 2)
            avl1.Insert(new Integer(i));
        avl2 = new AVLTree(false, new comparetest());
        for (int i = 1; i < 500000; i += 2)
            avl2.Insert(new Integer(i));
        // w = new watch();
        // w.press();
        avl1.Union1(avl2);
        // w.release();
        // w.print();

    }

    private AVLnode next(AVLnode r) {
        if (r.links != null) {
            r.links = next(r.links);
            if (HoehenAenderung)
                r = BalanceDL(r);
        }
        else {
            deleted = r;
            r = r.rechts;
            HoehenAenderung = true;
        }
        return r;
    }

    /** Returns the number of elements stored in the tree */
    public int NoElements() {
        return number;
    }

    /** Print tree for debugging purposes */
    public void print() {
        int i, d;
        d = depth(tree, 0);
        for (i = 0; i < d; i++) {
            printlevel(tree, i, 0, "");
            System.out.println();
        }
    }

    // print tree for debugging purposes
    private void printlevel(AVLnode t, int level, int actlevel, String pos) {
        if (t != null) {
            if (actlevel < level) {
                // System.out.print("l");
                printlevel(t.links, level, actlevel + 1, pos + "l");
                // System.out.print("r");
                printlevel(t.rechts, level, actlevel + 1, pos + "r");
            }
            else if (actlevel == level) {
                AVLnodeDup t1;
                System.out.print(pos);
                System.out.print(":  ");
                System.out.print(t.toString());
                if (t instanceof AVLnodeDup) {
                    for (t1 = ((AVLnodeDup) t).mitte; t1 != null; t1 = t1.mitte) {
                        System.out.print(",  ");
                        System.out.print(t1.toString());
                    }
                }
                System.out.println();
            }
        }
    }

    private AVLnode search(AVLnode baum, Object element) {
        while (baum != null) {
            switch (comp.Compare(baum.data, element)) {
            case 1:
                baum = baum.links;
                break;
            case -1:
                baum = baum.rechts;
                break;
            case 0:
                return (baum);
            // case -2 : if ((baum.links != null) &&
            // (comp.Compare(baum.links,element)==-2))
            // baum = baum.links;
            }
        }
        return null;
    }

    /**
     * Searches for an element. of the avl tree equal (in the sense of Compare)
     * to ele
     */
    public Object Search(Object ele) {
        AVLnode a;
        a = search(tree, ele);
        if (a != null)
            return a.data;
        else
            return null;
    }

    public void Union(AVLTree T) {
        AVLlenum enm1, enm2;
        AVLnode data[], a, b;
        int cmp, pgl = 0;
        enm1 = new AVLlenum(this);
        enm2 = new AVLlenum(T);
        data = new AVLnode[T.number + this.number];
        a = enm1.nextElement();
        b = enm2.nextElement();
        while (enm1.hasMoreElements() && enm2.hasMoreElements()) {
            cmp = comp.Compare(a.data, b.data);
            if (cmp == -1) {
                data[pgl++] = a;
                a = enm1.nextElement();
            }
            else if (cmp == 1) {
                data[pgl++] = b;
                b = enm2.nextElement();
            }
            else if (cmp == 0) {
                data[pgl++] = a;
                a = enm1.nextElement();
                b = enm2.nextElement();
            }
        }
        cmp = comp.Compare(a.data, b.data);
        if (cmp == -1) {
            data[pgl++] = a;
            data[pgl++] = b;
        }
        else if (cmp == 1) {
            data[pgl++] = b;
            data[pgl++] = a;
        }
        else if (cmp == 0) {
            data[pgl++] = a;
        }
        while (enm1.hasMoreElements())
            data[pgl++] = enm1.nextElement();
        while (enm2.hasMoreElements())
            data[pgl++] = enm2.nextElement();
        this.tree = construct(data, 0, data.length - 1);
        this.number = data.length;
    }

    public void Union1(AVLTree T) {
        AVLlenum enm;
        enm = new AVLlenum(T);
        while (enm.hasMoreElements())
            Insert((enm.nextElement()).data);
    }
}
