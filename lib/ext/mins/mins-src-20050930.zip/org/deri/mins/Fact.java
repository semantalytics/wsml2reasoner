/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

//Seems not importend (only in deserilizing?
/*

 Name: Fact.java

 Version: 1.0

 Purpose:

 History:

 */

import java.io.PrintStream;

import org.deri.mins.terms.Term;


public class Fact {
    public int symbol;

    public Term terms[];

    public Fact(int sym, Term ts[]) {
        terms = ts;
        symbol = sym;
    }

    public void print(PrintStream p) {
        int i;
        p.print("p");
        p.print(symbol);
        p.print("(");
        for (i = 0; i < terms.length; i++) {
            terms[i].print(p);
            if (i < terms.length - 1)
                p.print(",");
        }
        p.print(").");
    }

    public String toString() {
        String s;
        int i;
        s = "p" + Integer.toString(symbol) + "(";
        for (i = 0; i < terms.length; i++) {
            s += terms[i].toString();
            if (i < terms.length - 1)
                s += ",";
        }
        s += ").";
        return s;
    }
}
