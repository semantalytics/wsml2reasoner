/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins;

/*

 Name: AVLTree.java

 Version: 1.1

 Purpose: AVL tree used as access data structures at different places

 History:

 */

import java.util.NoSuchElementException;

import org.deri.mins.operations.Comparison;


/*
 * class watch { long start,ende; long timeused = 0; public void press() { start =
 * (new Date()).getTime(); } public void release() { ende = (new
 * Date()).getTime(); timeused += ende - start; } public void print() {
 * System.out.println(timeused); } public void reset() { timeused =0; } }
 */

class AVLlenum {
    private AVLTree avl;

    private Keller current;

    static int kellermax = 40;

    private AVLnodeDup cur = null;

    private Comparison compare;

    boolean firstaccess = true;

    /** Constructor */
    public AVLlenum(AVLTree a) {
        avl = a;
        compare = avl.comp;
        current = new Keller(kellermax);
    }

    /** Are there more elements available? */
    public boolean hasMoreElements() {
        if (firstaccess && avl.tree != null)
            return true;
        if (!current.Empty() || cur != null)
            return true;
        return false;
    }

    /**
     * Give the next element. Throws NoSuchElementException if no further
     * element is available
     */
    public AVLnode nextElement() throws NoSuchElementException {
        AVLnode a, b;
        if (firstaccess) {
            firstaccess = false;
            b = avl.tree;
            while (b != null) {
                current.Push(b);
                b = b.links;
            }
        }
        if (cur != null) {
            a = cur;
            cur = cur.mitte;
            return a;
        }
        else if (!current.Empty()) {
            a = current.Top();
            current.Pop();
            if (a.rechts != null) {
                current.Push(a.rechts);
                b = a.rechts.links;
                while (b != null) {
                    current.Push(b);
                    b = b.links;
                }
            }
            if (a instanceof AVLnodeDup) {
                cur = ((AVLnodeDup) a).mitte;
            }
            // System.out.println(((GroundAtom)a.data).toString());
            return a;
        }
        return null;
    }

    public void print() {
        System.out.println("Stack:");
        current.print();
    }
}
