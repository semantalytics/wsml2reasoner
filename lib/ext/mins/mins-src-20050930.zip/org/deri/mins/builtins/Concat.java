/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.builtins;

/*

 Name: Concat.java

 Version: 1.1

 Purpose:

 History: adapted to new builtin mechanism (jan)

 */

//import com.ontoprise.inference.SimpleEvaluator;
import org.deri.mins.*;
import org.deri.mins.terms.ConstTerm;
import org.deri.mins.terms.StringTerm;

public class Concat extends BuiltinFunc {
    public Concat() {
        super();
    }

    // public Concat(SimpleEvaluator eval) {
    // super(eval);
    // }

    public void eval(Atom t) {
        int i, len;
        String args[];
        String result = "";
        String result1 = "";
        boolean stringterm = false;
        args = new String[3];
        // System.out.println("-> Concat");
        if (evaluable(t)) {
            for (i = 0; i < 3; i++) {
                if (t.terms[i].ground) {
                    if (t.terms[i] instanceof StringTerm) {
                        args[i] = ((StringTerm) t.terms[i]).s;
                        stringterm = true;
                    }
                    else
                        throw new UnsupportedOperationException(
                                "due to refactoring");
                    // args[i] = eval
                    // .getString(((ConstTerm) t.terms[i]).symbol);
                }
            }
            if (t.terms[0].ground && t.terms[1].ground && t.terms[2].ground) {
                if (0 == args[0].compareTo(args[1] + args[2]))
                    insert(t);
            }
            else if (t.terms[0].ground && t.terms[1].ground) {
                result = args[0] + args[1];
                subs(t, result, 2, stringterm);
                insert(t);
            }
            else if (t.terms[0].ground && t.terms[2].ground) {
                if (args[2].startsWith(args[0])) {
                    result = args[2].substring(args[0].length());
                    subs(t, result, 1, stringterm);
                    insert(t);
                }
            }
            else if (t.terms[1].ground && t.terms[2].ground) {
                if (args[2].endsWith(args[1])) {
                    try {
                        result = args[2].substring(0, args[2].length()
                                - args[1].length());
                    } catch (StringIndexOutOfBoundsException e) {
                    }
                    subs(t, result, 0, stringterm);
                    insert(t);
                }
            }
            else if (t.terms[2].ground) {
                len = args[2].length();
                subs(t, "", 0, stringterm);
                subs(t, args[2], 1, stringterm);
                insert(t);
                subs(t, "", 1, stringterm);
                subs(t, args[2], 0, stringterm);
                insert(t);
                for (i = 1; i < len; i++) {
                    result1 = args[2].substring(i);
                    try {
                        result = args[2].substring(0, i);
                    } catch (StringIndexOutOfBoundsException e) {
                    }
                    subs(t, result, 0, stringterm);
                    subs(t, result1, 1, stringterm);
                    insert(t);
                }
            }
        }
    }

    public boolean evaluable(Atom t) {
        int i, anzbound = 0;
        boolean ok = true;
        // System.out.println("-> Concat evaluable");

        for (i = 0; i < 3; i++) {
            if (t.terms[i].ground) {
                anzbound++;
                if (!(t.terms[i] instanceof StringTerm)
                        && !(t.terms[i] instanceof ConstTerm && (((ConstTerm) t.terms[i]).symbol >= RuleSet.STRINGSTART)))
                    return false;
            }
        }
        if ((anzbound < 2) && !t.terms[2].ground)
            return false;
        return true;
    }

    private void subs(Atom t, String s, int index, boolean stringterm) {
        if (stringterm) {
            t.terms[index] = new StringTerm(s, 0, true);
        }
        else {
            throw new UnsupportedOperationException("due to refactoring");
            // t.terms[index] = new ConstTerm(eval.setString(s));

        }
    }
}
