/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.builtins;

/*

 Name: greaterorequal.java

 Version: 1.0

 Purpose: greater builtin predicate

 History: 
 */

import org.deri.mins.Atom;
import org.deri.mins.BuiltinFunc;
import org.deri.mins.terms.NumTerm;


public class Greaterorequal extends BuiltinFunc {

    public void eval(Atom t) {
        if ((t.terms[0] instanceof NumTerm) && (t.terms[1] instanceof NumTerm)
                && (((NumTerm) t.terms[0]).zahl >= ((NumTerm) t.terms[1]).zahl))
            insert(t);
    }

    public boolean evaluable(Atom t) {
        return (t.terms[0] instanceof NumTerm)
                && (t.terms[1] instanceof NumTerm);
    }
}
