/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.builtins;

/*

 Name: starts.java

 Version: 1.0

 Purpose:

 History:

 */

import java.util.Hashtable;
import java.util.Vector;

import org.deri.mins.Atom;
import org.deri.mins.BuiltinFunc;
import org.deri.mins.terms.NumTerm;
import org.deri.mins.terms.Term;


public class Lives extends BuiltinFunc {
    static Hashtable Ht = new Hashtable();

    static Lives instance = null;

    public Lives() {
        instance = this;
    }

    public void add(Atom t) {
        Vector v;
        v = (Vector) Ht.get(t.terms[0].toString());
        if (v == null) {
            v = new Vector();
            Ht.put(t.terms[0].toString(), v);
        }
        v.addElement(t);
    }

    public boolean available(Atom t) {
        Atom st, et;
        st = (Atom) Starts.Ht.get(t.terms[0].toString());
        et = (Atom) Ends.Ht.get(t.terms[0].toString());
        if ((st != null) && (et != null))
            return true;
        else
            return false;
    }

    public void eval(Atom t) {
        instance = this;
        if (!available(t) || ok(t)) {
            add(t);
            insert(t);
        }
    }

    public boolean evaluable(Atom t) {
        if (t.terms[0].ground && (t.terms[1] instanceof NumTerm))
            return true;
        else
            return false;
    }

    public boolean ok(Atom t) {
        Atom st, et;
        st = (Atom) Starts.Ht.get(t.terms[0].toString());
        et = (Atom) Ends.Ht.get(t.terms[0].toString());
        if ((st != null) && (et != null)) {
            if ((((NumTerm) st.terms[1]).zahl <= ((NumTerm) t.terms[1]).zahl)
                    && (((NumTerm) t.terms[1]).zahl <= ((NumTerm) et.terms[1]).zahl)) {
                return true;
            }
        }
        return false;
    }

    public void reeval(Term T) {

        // System.out.println("Reeval"); T.print(System.out);
        // System.out.println();
        java.util.Enumeration enm;
        Atom t;
        Vector v = (Vector) Ht.get(T.toString());
        if (v != null) {
            for (enm = v.elements(); enm.hasMoreElements();) {
                t = (Atom) enm.nextElement();
                // System.out.println("examine"); t.print(System.out);
                // System.out.println();
                if (available(t) && !ok(t)) {
                    retract(t);
                    // System.out.println("retract");
                }
            }
        }

    }
}
