/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.builtins;

/*

 Name: Evaluable.java

 Version: 1.01

 Purpose:

 History:
 7.5. corrected import and package declaration SDe 

 */

import org.deri.mins.Atom;
import org.deri.mins.BuiltinFunc;
import org.deri.mins.terms.*;

public class Evaluable extends BuiltinFunc {

    double compute(Term t) {
        if (t instanceof ConstTerm) {
            ConstTerm t1 = (ConstTerm) t;
            if (t1.symbol == 0 && t1.anzpars() == 2) // 0 = PLUS
            { // System.out.println("PLUS!");

                return compute(t1.pars[0]) + compute(t.pars[1]);
            }

            if (t1.symbol == 1 && t1.anzpars() == 2) // 1 = MINUS
            {
                return compute(t1.pars[0]) - compute(t.pars[1]);
            }

            if (t1.symbol == 0 && t1.anzpars() == 1) // 0 = unary PLUS
            {
                return compute(t1.pars[0]);
            }

            if (t1.symbol == 1 && t1.anzpars() == 1) // 1 = aunary MINUS
            {
                return -1 * compute(t.pars[0]);
            }

            if (t1.symbol == 2 && t1.anzpars() == 2) // *= mul
            {
                return compute(t.pars[0]) * compute(t.pars[1]);
            }

            if (t1.symbol == 3 && t1.anzpars() == 2) // *= mul
            {
                return compute(t.pars[0]) / compute(t.pars[1]);
            }

            if (t1.symbol == 4 && t1.anzpars() == 2) // *= div
            {
                return compute(t.pars[0]) % compute(t.pars[1]);
            }

            if (t1.symbol == 5 && t1.anzpars() == 0) // *= E
            {
                return Math.E;
            }

            if (t1.symbol == 6 && t1.anzpars() == 0) // *= PI
            {
                return Math.PI;
            }

            if (t1.symbol == 7 && t1.anzpars() == 0) // *= RANDOM
            {
                return Math.random();
            }

            // System.out.println("Anz " + t1.anzpars() + " Symbol" +
            // t1.symbol);
            if (t1.symbol == 8 && t1.anzpars() == 1) // *= abs
            {
                return Math.abs(compute(t1.pars[0]));
            }

            if (t1.symbol == 9 && t1.anzpars() == 1) // *= sin
            {
                return Math.sin(compute(t1.pars[0]));
            }

            if (t1.symbol == 10 && t1.anzpars() == 1) // *= cos
            {
                return Math.cos(compute(t.pars[0]));
            }

            if (t1.symbol == 11 && t1.anzpars() == 1) // *= tan
            {
                return Math.tan(compute(t.pars[0]));
            }

            if (t1.symbol == 12 && t1.anzpars() == 1) // *= asin
            {
                return Math.asin(compute(t.pars[0]));
            }

            if (t1.symbol == 13 && t1.anzpars() == 1) {
                return Math.acos(compute(t.pars[0]));
            }

            if (t1.symbol == 14 && t1.anzpars() == 1) {
                return Math.ceil(compute(t.pars[0]));
            }

            if (t1.symbol == 15 && t1.anzpars() == 1) {
                return Math.floor(compute(t.pars[0]));
            }

            if (t1.symbol == 16 && t1.anzpars() == 1) {
                return Math.exp(compute(t.pars[0]));
            }

            if (t1.symbol == 17 && t1.anzpars() == 1) {
                return Math.exp(compute(t.pars[0]));
            }

            if (t1.symbol == 18 && t1.anzpars() == 1) { /*
                                                         * return
                                                         * Math.rint(compute(t.pars[0]));
                                                         */
            }

            if (t1.symbol == 19 && t1.anzpars() == 1) {
                return Math.sqrt(compute(t.pars[0]));
            }

            if (t1.symbol == 20 && t1.anzpars() == 1) {
                return Math.round(compute(t.pars[0]));
            }

            if (t1.symbol == 21 && t1.anzpars() == 2) // max
            {
                return Math.max(compute(t.pars[0]), compute(t.pars[1]));
            }

            if (t1.symbol == 22 && t1.anzpars() == 2) // min
            {
                return Math.min(compute(t.pars[0]), compute(t.pars[1]));
            }

            if (t1.symbol == 23 && t1.anzpars() == 2) // pow
            {
                return Math.pow(compute(t.pars[0]), compute(t.pars[1]));
            }

        }

        if (t instanceof NumTerm) {
            return ((NumTerm) t).zahl;
        }

        if (t instanceof Variable) {
            return 0.0;
        }

        return 0.0; // this is a difficult thing for debugging - we should tink
        // about it
    }

    ConstTerm compute1(Term t) {
        ConstTerm t1 = null, t2 = null;
        if (t instanceof ConstTerm)
            t1 = (ConstTerm) t;
        if (t1.pars[1] instanceof ConstTerm)
            t2 = (ConstTerm) t1.pars[1];
        if (t1.symbol == 24 && t1.anzpars() == 2 && t1.pars[0].ground
                && (t1.pars[1] instanceof ConstTerm) && t2.symbol == 25
                && t2.anzpars() == 2) { // starttime and endtime
            TimeInterval T = new TimeInterval(compute(t2.pars[0]),
                    compute(t2.pars[1]));
            t1.pars[0].Attach(T);
            System.out.print(T.starttime);
            System.out.print(" : ");
            System.out.println(T.endtime);
        }
        return t1;
    }

    public void eval(Atom t) {
        int i;
        int anzbound = 0;
        boolean ok = true;

        double old, newd;
        if (t.terms[1].ground) {
            newd = compute(t.terms[1]);
            if (t.terms[0].ground) {
                if (t.terms[0] instanceof NumTerm) {
                    old = ((NumTerm) t.terms[0]).zahl;
                    if (Math.abs(old - newd) < 0.0001)
                        ok = true;
                    else
                        ok = false;
                }
                else
                    ok = false;
            }
            else {
                if (t.terms[0] instanceof Variable)
                    ((Variable) t.terms[0]).subsby = new NumTerm(newd, 0, true);
            }

            if (ok) {
                insert(t);
            }

        }
    }

    public boolean evaluable(Atom t) {

        return (t.terms[1].ground)
                && ((t.terms[0] instanceof NumTerm) || (t.terms[0] instanceof Variable));
    }

    public void w(String X) {
        System.out.println(X);
    }
}
