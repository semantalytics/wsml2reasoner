/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.builtins;

/*

 Name: BuiltinConfig.java

 Version: 1.01

 Purpose:
 Configures Builtins. Builtins are introduced into the system
 by adding them to the list builtinList. New entries must(!) be added
 to the end of the list to keep old programs saved in the internal
 format running.

 History:

 7.5.99 Added support for new builtin mechanism. SDe

 */

//import com.ontoprise.inference.SimpleEvaluator;
import org.deri.mins.BuiltinFunc;


public class BuiltinConfig {
    Builtin[] builtinList;

    // public BuiltinConfig(SimpleEvaluator eval) {
    // builtinList = eval.getSimpleEvaluatorConfig().getBuiltinList(eval);
    // }

    public BuiltinConfig(Builtin[] builtinList) {
        this.builtinList = builtinList;
    }

    public int getBuiltinNumber() {
        return builtinList.length;
    }

    public BuiltinFunc newInstance(int symbol) {
        return builtinList[symbol].newInstance();
    }
}
