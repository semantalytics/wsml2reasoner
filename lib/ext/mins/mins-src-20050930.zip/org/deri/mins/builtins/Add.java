/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.builtins;

/*

 Name: Add.java

 Version: 1.0

 Purpose:

 History:

 */

import org.deri.mins.Atom;
import org.deri.mins.BuiltinFunc;
import org.deri.mins.terms.NumTerm;
import org.deri.mins.terms.Variable;


public class Add extends BuiltinFunc {

    public void eval(Atom t) {
        int i;
        boolean ok = true;
        if (evaluable(t)) {
            ok = false;
            if (t.terms[0].ground && t.terms[1].ground && t.terms[2].ground) {
                if (((NumTerm) t.terms[0]).zahl + ((NumTerm) t.terms[1]).zahl == ((NumTerm) t.terms[2]).zahl)
                    ok = true;
            }
            else if (t.terms[0].ground && t.terms[1].ground) {
                ((Variable) t.terms[2]).subsby = new NumTerm(
                        ((NumTerm) t.terms[0]).zahl
                                + ((NumTerm) t.terms[1]).zahl, 0, true);
                ok = true;
            }
            else if (t.terms[0].ground && t.terms[2].ground) {
                ((Variable) t.terms[1]).subsby = new NumTerm(
                        ((NumTerm) t.terms[2]).zahl
                                - ((NumTerm) t.terms[0]).zahl, 0, true);
                ok = true;
            }
            else if (t.terms[1].ground && t.terms[2].ground) {
                ((Variable) t.terms[0]).subsby = new NumTerm(
                        ((NumTerm) t.terms[2]).zahl
                                - ((NumTerm) t.terms[1]).zahl, 0, true);
                ok = true;
            }
            if (ok) {
                insert(t);
            }
        }
    }

    public boolean evaluable(Atom t) {
        int i;
        int anzbound = 0;
        boolean ok = true;
        for (i = 0; i < 3; i++)
            if (t.terms[i].ground) {
                anzbound++;
                if (!(t.terms[i] instanceof NumTerm))
                    ok = false;
            }
            else if (!(t.terms[i] instanceof Variable))
                ok = false;
        if (anzbound < 2)
            ok = false;
        return ok;
    }
}
