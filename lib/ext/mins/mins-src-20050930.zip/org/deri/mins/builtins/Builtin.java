/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.builtins;

/*

 Name: Builtin.java

 Version: 1.01

 Purpose:

 History:
 7.5. Added additional constructor and commented out class generation from String SDe
 */

import org.deri.mins.BuiltinFunc;

public class Builtin {
    String classid = null;

    public BuiltinFunc builtinobject = null;

    public String symbol;

    public int arity;

    private Class c = null;

    Builtin(String symbol, int arity) {
        this.symbol = symbol;
        this.arity = arity;
    }

    public Builtin(String symbol, int arity, BuiltinFunc builtinobject) {
        this.builtinobject = builtinobject;
        this.symbol = symbol;
        this.arity = arity;
    }

    public Builtin(String symbol, int arity, String classid) {
        this.classid = classid;
        this.symbol = symbol;
        this.arity = arity;
    }

    public int getArity() {
        return arity;
    }

    public String getSymbol() {
        return symbol;
    }

    public BuiltinFunc newInstance() {
        if (builtinobject != null)
            return builtinobject;
        /*
         * uncomment when a new object should be generated if(c==null) try{ c =
         * Class.forName(classid); } catch(Exception
         * e){System.out.println("Wrong classID "+classid);} try{ return
         * (BuiltinFunc) c.newInstance(); } catch(Exception e) {
         * System.out.println("Can't instantiate " + c.toString()); return
         * null;}
         */
        return null;
    }

    public String toString() {
        if (c != null)
            return c.toString() + "/" + new Integer(arity);
        else
            return symbol + "/" + new Integer(arity);
    }
}
