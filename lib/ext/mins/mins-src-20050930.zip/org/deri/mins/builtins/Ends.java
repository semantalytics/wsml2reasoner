/*
 * MINS (Mins Is Not Silri) A Prolog Egine based on the Silri  
 * 
 * Copyright (C) 1999-2005  Juergen Angele and Stefan Decker
 *                          University of Innsbruck, Austria  
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package org.deri.mins.builtins;

/*

 Name: starts.java

 Version: 1.0

 Purpose:

 History:

 */

import java.util.Hashtable;

import org.deri.mins.Atom;
import org.deri.mins.BuiltinFunc;
import org.deri.mins.terms.*;

public class Ends extends BuiltinFunc {
    static Hashtable Ht = new Hashtable();

    public void eval(Atom t) {
        Atom t1;
        Term trms[];
        t1 = (Atom) Ht.get(t.terms[0].toString());
        if (t.terms[1] instanceof NumTerm) {
            if (t1 == null) {
                insert(t);
                Ht.put(t.terms[0].toString(), t);
                Lives.instance.reeval(t.terms[0]);
            }
            else if (((NumTerm) t1.terms[1]).zahl == ((NumTerm) t.terms[1]).zahl) {
                insert(t1);
            }
            else if (((NumTerm) t1.terms[1]).zahl > ((NumTerm) t.terms[1]).zahl) {
                retract(t1);
                if (!t.deleted) {
                    insert(t);
                    Ht.put(t.terms[0].toString(), t);
                    Lives.instance.reeval(t.terms[0]);
                }
            }
        }
        else if ((t.terms[1] instanceof Variable) && (t1 != null)) {
            insert(t1);
        }
    }

    public boolean evaluable(Atom t) {
        if (t.terms[0].ground
                && ((t.terms[1] instanceof NumTerm) || (t.terms[1] instanceof Variable)))
            return true;
        else
            return false;
    }
}
